
INSERT INTO `webtoffee_urls` VALUES
("3001","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_5.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3002","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_6.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3003","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_with_default_inf_value.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3004","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_with_style.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3005","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_with_style_array.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3006","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_1.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3007","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_2.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3008","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/command_1.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3009","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/command_2.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3010","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_argument_1.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3011","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_argument_2.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3012","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_argument_3.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3013","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_argument_4.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3014","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_argument_with_default_inf_value.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3015","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_argument_with_style.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3016","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_definition_1.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3017","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_definition_2.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3018","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_definition_3.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3019","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_definition_4.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3020","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_1.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3021","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_2.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3022","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_3.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3023","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_4.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3024","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_5.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3025","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_6.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3026","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_with_default_inf_value.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3027","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_with_style.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3028","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_with_style_array.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3029","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/finder/Tests/Fixtures/with space/foo.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:33","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3030","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/finder/Tests/Fixtures/dolor.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:33","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3031","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/finder/Tests/Fixtures/ipsum.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:33","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3032","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/finder/Tests/Fixtures/lorem.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:33","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3033","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/translation/Tests/fixtures/resourcebundle/dat/en.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:26","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3034","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/translation/Tests/fixtures/resourcebundle/dat/fr.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:26","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3035","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/translation/Tests/fixtures/resourcebundle/dat/packagelist.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:26","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3036","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/vlucas/phpdotenv/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-06-11 01:13:26","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3037","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/phpunit.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:43","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3038","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_accounts.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3039","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_accounts_row.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3040","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_config.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3041","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_config_row.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3042","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_files.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3043","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_files_edit.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3044","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_files_rename.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3045","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_files_row.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3046","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_home.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3047","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_login.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3048","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_logs.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3049","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_nav_complete_access.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3050","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_nav_logs_access_only.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3051","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_quarantine.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3052","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_quarantine_row.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3053","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_statistics.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3054","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_updates.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3055","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_updates_row.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3056","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/_upload_test.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3057","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/frontend.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3058","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/fe_assets/frontend.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3059","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/template_custom.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:45","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3060","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/template_default.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3061","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/scan_kills.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3062","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/scan_log.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3063","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/phpMussel/vault/scan_log_serialized.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:44","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3064","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:43","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3065","static_file","/wp-content/plugins/getastra/astra/libraries/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:18","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3066","static_file","/wp-content/plugins/getastra/astra/czar-0C1FF565BD3CE4EE8A051622C5973D54.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3067","static_file","/wp-content/plugins/getastra/astra/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:18","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3068","static_file","/wp-content/plugins/getastra/css/fonts/fa-brands-400.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3069","static_file","/wp-content/plugins/getastra/css/fonts/fa-solid-900.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3070","static_file","/wp-content/plugins/getastra/css/fonts/Mark Simonson - Proxima Nova Alt Regular-webfont.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:45","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3071","static_file","/wp-content/plugins/getastra/css/fonts/fa-brands-400.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3072","static_file","/wp-content/plugins/getastra/css/fonts/fa-solid-900.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:45","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3073","static_file","/wp-content/plugins/getastra/css/fonts/eicons.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3074","static_file","/wp-content/plugins/getastra/css/fonts/fa-brands-400.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3075","static_file","/wp-content/plugins/getastra/css/fonts/fa-solid-900.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3076","static_file","/wp-content/plugins/getastra/css/fonts/fontawesome-webfont.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3077","static_file","/wp-content/plugins/getastra/css/all.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:45","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3078","static_file","/wp-content/plugins/getastra/css/bootstrap.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3079","static_file","/wp-content/plugins/getastra/css/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3080","static_file","/wp-content/plugins/getastra/img/Astra-dashboard1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:45","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3081","static_file","/wp-content/plugins/getastra/img/Ingrid_bw.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:45","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3082","static_file","/wp-content/plugins/getastra/img/astra-s-white-logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:45","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3083","static_file","/wp-content/plugins/getastra/img/jamiefeldman.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:45","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3084","static_file","/wp-content/plugins/getastra/img/download.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:45","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3085","static_file","/wp-content/plugins/getastra/js/bootstrap.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3086","static_file","/wp-content/plugins/getastra/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-06-11 01:13:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3087","static_file","/wp-content/plugins/https-redirection/css/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-13 09:53:53","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3088","static_file","/wp-content/plugins/https-redirection/images/px.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-13 09:53:54","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3089","static_file","/wp-content/plugins/https-redirection/images/status-icons.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-13 09:53:54","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3090","static_file","/wp-content/plugins/https-redirection/js/script.js","","","0","1","1","","0000-00-00 00:00:00","","2023-06-13 09:53:54","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3091","static_file","/wp-content/plugins/https-redirection/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-06-13 09:53:54","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3092","static_file","/wp-content/plugins/https-redirection/screenshot-1.png","","","0","1","0","","0000-00-00 00:00:00","","2023-06-13 09:53:54","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3093","static_file","/wp-content/plugins/query-monitor/assets/icons/admin-generic.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3094","static_file","/wp-content/plugins/query-monitor/assets/icons/arrow-down.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3095","static_file","/wp-content/plugins/query-monitor/assets/icons/edit.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3096","static_file","/wp-content/plugins/query-monitor/assets/icons/external.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3097","static_file","/wp-content/plugins/query-monitor/assets/icons/filter.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3098","static_file","/wp-content/plugins/query-monitor/assets/icons/image-rotate-left.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3099","static_file","/wp-content/plugins/query-monitor/assets/icons/image-rotate-right.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3100","static_file","/wp-content/plugins/query-monitor/assets/icons/info.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3101","static_file","/wp-content/plugins/query-monitor/assets/icons/no-alt.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3102","static_file","/wp-content/plugins/query-monitor/assets/icons/warning.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3103","static_file","/wp-content/plugins/query-monitor/assets/icons/yes-alt.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3104","static_file","/wp-content/plugins/query-monitor/assets/query-monitor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3105","static_file","/wp-content/plugins/query-monitor/assets/query-monitor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3106","static_file","/wp-content/plugins/query-monitor/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-07-18 02:06:05","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3107","static_file","/wp-content/plugins/really-simple-ssl/assets/css/rtl/admin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3108","static_file","/wp-content/plugins/really-simple-ssl/assets/css/rtl/plugin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3109","static_file","/wp-content/plugins/really-simple-ssl/assets/css/rtl/rsssl-plugin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3110","static_file","/wp-content/plugins/really-simple-ssl/assets/css/admin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3111","static_file","/wp-content/plugins/really-simple-ssl/assets/css/admin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3112","static_file","/wp-content/plugins/really-simple-ssl/assets/css/rsssl-plugin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3113","static_file","/wp-content/plugins/really-simple-ssl/assets/css/rsssl-plugin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3114","static_file","/wp-content/plugins/really-simple-ssl/assets/img/icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3115","static_file","/wp-content/plugins/really-simple-ssl/assets/img/really-simple-plugins.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3116","static_file","/wp-content/plugins/really-simple-ssl/assets/img/really-simple-ssl-intro.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3117","static_file","/wp-content/plugins/really-simple-ssl/assets/img/really-simple-ssl-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3118","static_file","/wp-content/plugins/really-simple-ssl/mailer/templates/block.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3119","static_file","/wp-content/plugins/really-simple-ssl/mailer/templates/email.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3120","static_file","/wp-content/plugins/really-simple-ssl/settings/build/187.85766b52ba67b360ae7e.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3121","static_file","/wp-content/plugins/really-simple-ssl/settings/build/516.a6e059892a1f3edb6ebf.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3122","static_file","/wp-content/plugins/really-simple-ssl/settings/build/688.ea69dfea12bc73015951.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3123","static_file","/wp-content/plugins/really-simple-ssl/settings/build/771.361e7456a09a4173bb8e.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3124","static_file","/wp-content/plugins/really-simple-ssl/settings/build/772.ffad42a4aac072147b00.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3125","static_file","/wp-content/plugins/really-simple-ssl/settings/build/812.0b1f030ad8c83309c467.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3126","static_file","/wp-content/plugins/really-simple-ssl/settings/build/829.50b272772b06f5fd2fdf.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3127","static_file","/wp-content/plugins/really-simple-ssl/settings/build/885.b0c364cdc2feaab6b194.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3128","static_file","/wp-content/plugins/really-simple-ssl/settings/build/964.5a8aa698c24f25953583.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3129","static_file","/wp-content/plugins/really-simple-ssl/settings/build/967.60c930b6e473f21beb92.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3130","static_file","/wp-content/plugins/really-simple-ssl/settings/build/index.85c54ae03e93504a4ac9.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3131","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/OtherPlugins/OtherPlugins.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3132","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/OtherPlugins/OtherPluginsData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3133","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/OtherPlugins/OtherPluginsHeader.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3134","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/Progress/ProgressBlock.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3135","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/Progress/ProgressBlockHeader.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3136","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/Progress/ProgressData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3137","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/Progress/ProgressFooter.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3138","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/SslLabs/SslLabs.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3139","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/SslLabs/SslLabsData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3140","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/SslLabs/SslLabsFooter.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3141","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/SslLabs/SslLabsHeader.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3142","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/TipsTricks/TipsTricks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3143","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/TipsTricks/TipsTricksFooter.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3144","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/Vulnerabilities/Vulnerabilities.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3145","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/Vulnerabilities/VulnerabilitiesFooter.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3146","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/Vulnerabilities/VulnerabilitiesHeader.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3147","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/DashboardPage.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3148","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/GridBlock.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3149","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Dashboard/TaskElement.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3150","static_file","/wp-content/plugins/really-simple-ssl/settings/src/LetsEncrypt/Activate.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3151","static_file","/wp-content/plugins/really-simple-ssl/settings/src/LetsEncrypt/Directories.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3152","static_file","/wp-content/plugins/really-simple-ssl/settings/src/LetsEncrypt/DnsVerification.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3153","static_file","/wp-content/plugins/really-simple-ssl/settings/src/LetsEncrypt/Generation.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3154","static_file","/wp-content/plugins/really-simple-ssl/settings/src/LetsEncrypt/Installation.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3155","static_file","/wp-content/plugins/really-simple-ssl/settings/src/LetsEncrypt/LetsEncrypt.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3156","static_file","/wp-content/plugins/really-simple-ssl/settings/src/LetsEncrypt/letsEncryptData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3157","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Menu/Menu.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3158","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Menu/MenuData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3159","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Menu/MenuItem.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3160","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Modal/Modal.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3161","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Modal/ModalControl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3162","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Modal/ModalData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3163","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Onboarding/Onboarding.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3164","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Onboarding/OnboardingData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3165","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Onboarding/OnboardingModal.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3166","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Placeholder/DashboardPlaceholder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3167","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Placeholder/DatatablePlaceholder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3168","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Placeholder/MenuPlaceholder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3169","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Placeholder/PagePlaceholder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3170","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Placeholder/Placeholder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3171","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Placeholder/SettingsPlaceholder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3172","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/LearningMode/ChangeStatus.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3173","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/LearningMode/Delete.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3174","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/LearningMode/LearningMode.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3175","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/LearningMode/LearningModeData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3176","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/License/License.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3177","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/License/LicenseData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3178","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/MixedContentScan/MixedContentData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3179","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/MixedContentScan/MixedContentScan.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3180","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/RiskConfiguration/NotificationTester.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3181","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/RiskConfiguration/RiskComponent.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3182","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/RiskConfiguration/RiskData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3183","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/RiskConfiguration/Runner.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3184","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/RiskConfiguration/RunnerData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3185","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/RiskConfiguration/VulnerabilitiesIntro.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3186","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/RiskConfiguration/VulnerabilitiesOverview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3187","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/Button.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3188","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/CheckboxControl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3189","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/Field.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3190","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/FieldsData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3191","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/Help.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3192","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/Host.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3193","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/Notices.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3194","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/Password.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3195","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/PermissionsPolicy.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3196","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/PostDropDown.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3197","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/SelectControl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3198","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/Settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3199","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/SettingsGroup.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3200","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Settings/Support.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3201","static_file","/wp-content/plugins/really-simple-ssl/settings/src/utils/Error.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3202","static_file","/wp-content/plugins/really-simple-ssl/settings/src/utils/Hyperlink.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3203","static_file","/wp-content/plugins/really-simple-ssl/settings/src/utils/Icon.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3204","static_file","/wp-content/plugins/really-simple-ssl/settings/src/utils/api.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3205","static_file","/wp-content/plugins/really-simple-ssl/settings/src/utils/formatting.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3206","static_file","/wp-content/plugins/really-simple-ssl/settings/src/utils/getAnchor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3207","static_file","/wp-content/plugins/really-simple-ssl/settings/src/utils/lib.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3208","static_file","/wp-content/plugins/really-simple-ssl/settings/src/utils/sleeper.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3209","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Header.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3210","static_file","/wp-content/plugins/really-simple-ssl/settings/src/Page.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3211","static_file","/wp-content/plugins/really-simple-ssl/settings/src/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3212","static_file","/wp-content/plugins/really-simple-ssl/settings/webpack.config.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3213","static_file","/wp-content/plugins/really-simple-ssl/testssl/cloudflare/ssl-test-page.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3214","static_file","/wp-content/plugins/really-simple-ssl/testssl/cloudfront/ssl-test-page.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3215","static_file","/wp-content/plugins/really-simple-ssl/testssl/envhttps/ssl-test-page.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3216","static_file","/wp-content/plugins/really-simple-ssl/testssl/loadbalancer/ssl-test-page.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3217","static_file","/wp-content/plugins/really-simple-ssl/testssl/serverhttps1/ssl-test-page.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3218","static_file","/wp-content/plugins/really-simple-ssl/testssl/serverhttpson/ssl-test-page.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3219","static_file","/wp-content/plugins/really-simple-ssl/testssl/serverhttpxforwardedssl1/ssl-test-page.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3220","static_file","/wp-content/plugins/really-simple-ssl/testssl/serverhttpxforwardedsslon/ssl-test-page.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3221","static_file","/wp-content/plugins/really-simple-ssl/testssl/serverhttpxproto/ssl-test-page.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3222","static_file","/wp-content/plugins/really-simple-ssl/testssl/serverport443/ssl-test-page.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3223","static_file","/wp-content/plugins/really-simple-ssl/upgrade/img/burst.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:07","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3224","static_file","/wp-content/plugins/really-simple-ssl/upgrade/img/complianz-gdpr.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:07","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3225","static_file","/wp-content/plugins/really-simple-ssl/upgrade/img/really-simple-ssl.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:07","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3226","static_file","/wp-content/plugins/really-simple-ssl/upgrade/upgrade-to-pro.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:07","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3227","static_file","/wp-content/plugins/really-simple-ssl/upgrade/upgrade-to-pro.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:07","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3228","static_file","/wp-content/plugins/really-simple-ssl/upgrade/ajax.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:07","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3229","static_file","/wp-content/plugins/really-simple-ssl/upgrade/ajax.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:07","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3230","static_file","/wp-content/plugins/really-simple-ssl/upgrade/upgrade-to-pro.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:07","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3231","static_file","/wp-content/plugins/really-simple-ssl/upgrade/upgrade-to-pro.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:07","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3232","static_file","/wp-content/plugins/really-simple-ssl/vendor/wp-cli/i18n-command/phpunit.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:07","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3233","static_file","/wp-content/plugins/really-simple-ssl/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3234","static_file","/wp-content/plugins/really-simple-ssl/force-deactivate.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3235","static_file","/wp-content/plugins/really-simple-ssl/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3236","static_file","/wp-content/plugins/really-simple-ssl/gulpfile.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:33:06","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3237","static_file","/wp-content/plugins/simply-static/assets/simply-static-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 02:15:53","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3238","static_file","/wp-content/plugins/simply-static/assets/simply-static-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 02:15:53","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3239","static_file","/wp-content/plugins/simply-static/src/admin/build/index.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 02:15:53","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3240","static_file","/wp-content/plugins/simply-static/src/admin/build/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 02:15:53","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3241","static_file","/wp-content/plugins/simply-static/src/integrations/simply-cdn/assets/ssh-form-webhook.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 02:15:53","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3242","static_file","/wp-content/plugins/simply-static/vendor/a5hleyrich/wp-background-processing/license.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-09-02 02:15:53","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3243","static_file","/wp-content/plugins/simply-static/vendor/a5hleyrich/wp-background-processing/phpunit.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 02:15:53","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3244","static_file","/wp-content/plugins/simply-static/vendor/voku/portable-ascii/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-09-02 02:15:54","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3245","static_file","/wp-content/plugins/simply-static/license.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-09-02 02:15:53","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3246","static_file","/wp-content/plugins/simply-static/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-09-02 02:15:53","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3247","static_file","/wp-content/plugins/staticpress/images/ajax-loader.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:53:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3248","static_file","/wp-content/plugins/staticpress/images/menuicon-splite.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:53:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3249","static_file","/wp-content/plugins/staticpress/images/options32.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:53:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3250","static_file","/wp-content/plugins/staticpress/images/rebuild32.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:53:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3251","static_file","/wp-content/plugins/staticpress/images/staticpress.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:53:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3252","static_file","/wp-content/plugins/staticpress/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-09-07 12:53:46","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3253","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/bootstrap/css/bootstrap-grid.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:28","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3254","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/bootstrap/css/bootstrap-grid.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:28","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3255","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/bootstrap/css/bootstrap-reboot.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:29","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3256","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/bootstrap/css/bootstrap-reboot.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:29","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3257","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/bootstrap/css/bootstrap.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:28","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3258","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/bootstrap/css/bootstrap.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:28","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3259","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/bootstrap/js/bootstrap.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:29","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3260","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/bootstrap/js/bootstrap.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:30","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3261","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/bootstrap/js/bootstrap.js","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:30","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3262","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/bootstrap/js/bootstrap.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:31","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3263","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/css/admin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:31","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3264","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/img/spinner-svg.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:31","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3265","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/img/bfu-logo-sm.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:31","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3266","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/img/scan-preview.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:31","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3267","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/img/iu-logo-blue.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:31","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3268","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/img/iu-logo-words.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:31","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3269","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/img/wave-bg.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:31","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3270","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/js/Chart.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:31","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3271","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/js/admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:31","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3272","static_file","/wp-content/plugins/tuxedo-big-file-uploads/assets/js/block-notice.js","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:31:31","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3273","static_file","/wp-content/plugins/tuxedo-big-file-uploads/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-06-10 06:31:31","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3274","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/css/checkout.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3275","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/css/jquery-confirm.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3276","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/css/payment.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3277","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/css/selectize.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3278","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/icon/logo.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3279","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/icon/payment.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3280","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/icon/logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3281","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/icon/bhim.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3282","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/icon/googlepay.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3283","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/icon/paytm.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3284","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/icon/phonepe.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3285","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/js/easy.qrcode.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3286","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/js/jquery-confirm.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3287","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/js/payment.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3288","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/includes/js/selectize.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3289","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/license.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3290","static_file","/wp-content/plugins/upi-qr-code-payment-for-woocommerce/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-07-24 09:34:27","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3291","static_file","/wp-content/plugins/variation-swatches-woo/admin-core/assets/build/images/logo.46bd2419.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3292","static_file","/wp-content/plugins/variation-swatches-woo/admin-core/assets/build/settings-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3293","static_file","/wp-content/plugins/variation-swatches-woo/admin-core/assets/build/settings.css","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3294","static_file","/wp-content/plugins/variation-swatches-woo/admin-core/assets/build/settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3295","static_file","/wp-content/plugins/variation-swatches-woo/admin-core/assets/css/extra.css","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3296","static_file","/wp-content/plugins/variation-swatches-woo/admin-core/assets/images/cfl-gray.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3297","static_file","/wp-content/plugins/variation-swatches-woo/admin-core/assets/images/logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3298","static_file","/wp-content/plugins/variation-swatches-woo/admin/assets/css/product-config.css","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3299","static_file","/wp-content/plugins/variation-swatches-woo/admin/assets/css/term-meta.css","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3300","static_file","/wp-content/plugins/variation-swatches-woo/admin/assets/img/wc-placeholder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3301","static_file","/wp-content/plugins/variation-swatches-woo/admin/assets/js/product-attribute.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3302","static_file","/wp-content/plugins/variation-swatches-woo/admin/assets/js/product-config.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3303","static_file","/wp-content/plugins/variation-swatches-woo/admin/assets/js/term-meta-type.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3304","static_file","/wp-content/plugins/variation-swatches-woo/assets/css/swatches.css","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3305","static_file","/wp-content/plugins/variation-swatches-woo/assets/js/swatches.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3306","static_file","/wp-content/plugins/variation-swatches-woo/changelog.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3307","static_file","/wp-content/plugins/variation-swatches-woo/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3308","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/css/admin-cart-abandonment-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3309","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/css/admin-cart-abandonment.css","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3310","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/images/cartflows-email-logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3311","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/images/facebook2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3312","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/images/image-placeholder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3313","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/images/twitter2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3314","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/images/wcar-icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3315","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/images/youtube2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3316","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/images/cartflows-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3317","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/images/cartflows-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3318","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/js/admin-email-templates.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3319","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/js/admin-mce.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3320","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/js/admin-notices.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3321","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/js/admin-settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3322","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/min-css/admin-cart-abandonment-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3323","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/min-css/admin-cart-abandonment.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3324","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/min-js/admin-email-templates.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3325","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/min-js/admin-mce.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3326","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/min-js/admin-notices.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3327","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/assets/min-js/admin-settings.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3328","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/bsf-analytics/assets/css/minified/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3329","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/bsf-analytics/assets/css/minified/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3330","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/bsf-analytics/assets/css/unminified/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3331","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/admin/bsf-analytics/assets/css/unminified/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3332","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/lib/astra-notices/notices.css","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3333","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/lib/astra-notices/notices.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3334","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/modules/cart-abandonment/assets/js/cart-abandonment-tracking.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3335","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/changelog.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3336","static_file","/wp-content/plugins/woo-cart-abandonment-recovery/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-05-22 02:47:15","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3337","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/thwcfd-admin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3338","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/delete.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3339","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/display-section.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3340","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/fields.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3341","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/help.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3342","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/popup-flyers.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3343","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/review-left.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3344","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/review-tab.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3345","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/reviewquotes.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3346","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/rocket.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3347","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/tick.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3348","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/upgrade-banner.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3349","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/upgrade-btn.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3350","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/accordion-open.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3351","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/accordion.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3352","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/close-popup.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3353","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/close.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3354","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/crown.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3355","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/done.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3356","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/guarantee.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3357","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3358","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/popup-flyers.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3359","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/pro.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3360","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/quotes.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3361","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/reminder.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3362","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/star.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3363","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/support.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3364","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/themehigh.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3365","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/css/tick.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3366","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/images/wp-plugins/order-delivery.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3367","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/images/wp-plugins/advanced-faq-manager.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3368","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/images/wp-plugins/checkout-field-editor.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3369","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/images/wp-plugins/discount-and-dynamic-pricing.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3370","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/images/wp-plugins/email-customizer.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3371","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/images/wp-plugins/extra-product-options.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3372","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/images/wp-plugins/job-manager.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3373","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/images/wp-plugins/multiple-addresses.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3374","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/images/wp-plugins/multistep-checkout.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3375","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/images/wp-plugins/product-feature-request.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3376","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/images/wp-plugins/variation-swatches.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3377","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/images/wp-plugins/wishlist-compare.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3378","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/js/thwcfd-admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3379","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/admin/assets/js/thwcfd-admin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3380","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/public/assets/css/thwcfd-public.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3381","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/public/assets/js/thwcfd-public.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3382","static_file","/wp-content/plugins/woo-checkout-field-editor-pro/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:26:10","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3383","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/css/stripe-link.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3384","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/css/stripe-styles.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3385","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/alipay.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3386","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/amex.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3387","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/bancontact.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3388","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/boleto.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3389","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/credit-card.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3390","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/diners.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3391","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/discover.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3392","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/eps.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3393","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/giropay.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3394","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/ideal.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3395","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/jcb.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3396","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/link.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3397","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/maestro.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3398","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/mastercard.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3399","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/multibanco.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3400","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/oxxo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3401","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/p24.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3402","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/sepa.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3403","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/sofort.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3404","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/visa.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3405","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/images/wechat.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3406","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/js/jquery.mask.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3407","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/js/jquery.mask.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3408","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/js/stripe-payment-request.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3409","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/js/stripe-payment-request.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3410","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/js/stripe.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3411","static_file","/wp-content/plugins/woocommerce-gateway-stripe/assets/js/stripe.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3412","static_file","/wp-content/plugins/woocommerce-gateway-stripe/build/payment_gateways.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3413","static_file","/wp-content/plugins/woocommerce-gateway-stripe/build/payment_requests_settings.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3414","static_file","/wp-content/plugins/woocommerce-gateway-stripe/build/upe_blocks.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3415","static_file","/wp-content/plugins/woocommerce-gateway-stripe/build/upe_classic.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3416","static_file","/wp-content/plugins/woocommerce-gateway-stripe/build/upe_settings.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3417","static_file","/wp-content/plugins/woocommerce-gateway-stripe/build/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3418","static_file","/wp-content/plugins/woocommerce-gateway-stripe/build/old_settings_upe_toggle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3419","static_file","/wp-content/plugins/woocommerce-gateway-stripe/build/payment_gateways.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3420","static_file","/wp-content/plugins/woocommerce-gateway-stripe/build/payment_requests_settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3421","static_file","/wp-content/plugins/woocommerce-gateway-stripe/build/upe_blocks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3422","static_file","/wp-content/plugins/woocommerce-gateway-stripe/build/upe_classic.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3423","static_file","/wp-content/plugins/woocommerce-gateway-stripe/build/upe_settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3424","static_file","/wp-content/plugins/woocommerce-gateway-stripe/changelog.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:32:51","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3425","static_file","/wp-content/plugins/woocommerce-gateway-stripe/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:32:52","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3426","static_file","/wp-content/plugins/woocommerce/assets/client/admin/activity-panels-help/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3427","static_file","/wp-content/plugins/woocommerce/assets/client/admin/activity-panels-inbox/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3428","static_file","/wp-content/plugins/woocommerce/assets/client/admin/admin-layout/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3429","static_file","/wp-content/plugins/woocommerce/assets/client/admin/admin-layout/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3430","static_file","/wp-content/plugins/woocommerce/assets/client/admin/admin-layout/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3431","static_file","/wp-content/plugins/woocommerce/assets/client/admin/analytics-report-categories/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3432","static_file","/wp-content/plugins/woocommerce/assets/client/admin/analytics-report-coupons/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3433","static_file","/wp-content/plugins/woocommerce/assets/client/admin/analytics-report-customers/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3434","static_file","/wp-content/plugins/woocommerce/assets/client/admin/analytics-report-downloads/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3435","static_file","/wp-content/plugins/woocommerce/assets/client/admin/analytics-report-orders/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3436","static_file","/wp-content/plugins/woocommerce/assets/client/admin/analytics-report-products/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3437","static_file","/wp-content/plugins/woocommerce/assets/client/admin/analytics-report-revenue/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3438","static_file","/wp-content/plugins/woocommerce/assets/client/admin/analytics-report-stock/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3439","static_file","/wp-content/plugins/woocommerce/assets/client/admin/analytics-report-taxes/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3440","static_file","/wp-content/plugins/woocommerce/assets/client/admin/analytics-report-variations/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3441","static_file","/wp-content/plugins/woocommerce/assets/client/admin/analytics-report/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3442","static_file","/wp-content/plugins/woocommerce/assets/client/admin/analytics-settings/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3443","static_file","/wp-content/plugins/woocommerce/assets/client/admin/app/index.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3444","static_file","/wp-content/plugins/woocommerce/assets/client/admin/app/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3445","static_file","/wp-content/plugins/woocommerce/assets/client/admin/app/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3446","static_file","/wp-content/plugins/woocommerce/assets/client/admin/app/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3447","static_file","/wp-content/plugins/woocommerce/assets/client/admin/beta-features-tracking-modal/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3448","static_file","/wp-content/plugins/woocommerce/assets/client/admin/beta-features-tracking-modal/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3449","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/2784.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3450","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/6412.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3451","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/1828.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3452","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/185.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3453","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/2397.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3454","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/2502.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3455","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/2624.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3456","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/2953.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3457","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/3307.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3458","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/3576.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3459","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/3700.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3460","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/3994.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3461","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/4011.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3462","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/4854.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3463","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/4882.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3464","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/4891.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3465","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/5009.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3466","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/5502.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3467","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/5792.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3468","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/6125.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3469","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/6732.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3470","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/6824.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3471","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/727.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3472","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/7387.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3473","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/7708.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3474","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/8544.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3475","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/8597.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3476","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/8851.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3477","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/9360.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3478","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/9456.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3479","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/9792.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3480","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/9966.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3481","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/2784.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3482","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/4891.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3483","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/5792.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3484","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/5838.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3485","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/6195.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3486","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/6412.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3487","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/7846.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3488","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/8758.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3489","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/8994.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3490","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/9529.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3491","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/9616.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3492","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/activity-panels-help.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3493","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/activity-panels-inbox.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3494","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/activity-panels-setup.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3495","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/analytics-report-categories.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3496","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/analytics-report-coupons.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3497","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/analytics-report-customers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3498","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/analytics-report-downloads.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3499","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/analytics-report-orders.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3500","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/analytics-report-products.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3501","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/analytics-report-revenue.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3502","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/analytics-report-stock.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3503","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/analytics-report-taxes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3504","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/analytics-report-variations.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3505","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/analytics-report.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3506","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/analytics-settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3507","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/category-metabox.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3508","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/core-profiler.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3509","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/customizable-dashboard.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3510","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/dashboard-charts.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3511","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/dashboard.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3512","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/edit-product-page.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3513","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/homescreen.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3514","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/leaderboards.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3515","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/multichannel-marketing.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3516","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/payment-recommendations.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3517","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/product-page.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3518","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/profile-wizard.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3519","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/shipping-recommendations.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3520","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/store-alerts.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3521","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/store-performance.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3522","static_file","/wp-content/plugins/woocommerce/assets/client/admin/chunks/wcpay-payment-welcome-page.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3523","static_file","/wp-content/plugins/woocommerce/assets/client/admin/components/index.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3524","static_file","/wp-content/plugins/woocommerce/assets/client/admin/components/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3525","static_file","/wp-content/plugins/woocommerce/assets/client/admin/components/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3526","static_file","/wp-content/plugins/woocommerce/assets/client/admin/components/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3527","static_file","/wp-content/plugins/woocommerce/assets/client/admin/core-profiler/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3528","static_file","/wp-content/plugins/woocommerce/assets/client/admin/csv-export/index.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3529","static_file","/wp-content/plugins/woocommerce/assets/client/admin/csv-export/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3530","static_file","/wp-content/plugins/woocommerce/assets/client/admin/currency/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3531","static_file","/wp-content/plugins/woocommerce/assets/client/admin/customer-effort-score/index.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3532","static_file","/wp-content/plugins/woocommerce/assets/client/admin/customer-effort-score/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3533","static_file","/wp-content/plugins/woocommerce/assets/client/admin/customer-effort-score/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3534","static_file","/wp-content/plugins/woocommerce/assets/client/admin/customer-effort-score/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3535","static_file","/wp-content/plugins/woocommerce/assets/client/admin/dashboard-charts/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3536","static_file","/wp-content/plugins/woocommerce/assets/client/admin/dashboard/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3537","static_file","/wp-content/plugins/woocommerce/assets/client/admin/data/index.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3538","static_file","/wp-content/plugins/woocommerce/assets/client/admin/data/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3539","static_file","/wp-content/plugins/woocommerce/assets/client/admin/date/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3540","static_file","/wp-content/plugins/woocommerce/assets/client/admin/edit-product-page/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3541","static_file","/wp-content/plugins/woocommerce/assets/client/admin/experimental/index.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3542","static_file","/wp-content/plugins/woocommerce/assets/client/admin/experimental/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3543","static_file","/wp-content/plugins/woocommerce/assets/client/admin/experimental/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3544","static_file","/wp-content/plugins/woocommerce/assets/client/admin/experimental/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3545","static_file","/wp-content/plugins/woocommerce/assets/client/admin/explat/index.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3546","static_file","/wp-content/plugins/woocommerce/assets/client/admin/explat/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3547","static_file","/wp-content/plugins/woocommerce/assets/client/admin/homescreen/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3548","static_file","/wp-content/plugins/woocommerce/assets/client/admin/leaderboards/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3549","static_file","/wp-content/plugins/woocommerce/assets/client/admin/marketing-coupons/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3550","static_file","/wp-content/plugins/woocommerce/assets/client/admin/marketing-coupons/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3551","static_file","/wp-content/plugins/woocommerce/assets/client/admin/multichannel-marketing/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3552","static_file","/wp-content/plugins/woocommerce/assets/client/admin/navigation-opt-out/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3553","static_file","/wp-content/plugins/woocommerce/assets/client/admin/navigation-opt-out/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3554","static_file","/wp-content/plugins/woocommerce/assets/client/admin/navigation/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3555","static_file","/wp-content/plugins/woocommerce/assets/client/admin/notices/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3556","static_file","/wp-content/plugins/woocommerce/assets/client/admin/null/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3557","static_file","/wp-content/plugins/woocommerce/assets/client/admin/number/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3558","static_file","/wp-content/plugins/woocommerce/assets/client/admin/onboarding/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3559","static_file","/wp-content/plugins/woocommerce/assets/client/admin/onboarding/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3560","static_file","/wp-content/plugins/woocommerce/assets/client/admin/onboarding/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3561","static_file","/wp-content/plugins/woocommerce/assets/client/admin/payment-method-promotions/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3562","static_file","/wp-content/plugins/woocommerce/assets/client/admin/payment-method-promotions/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3563","static_file","/wp-content/plugins/woocommerce/assets/client/admin/print-shipping-label-banner/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3564","static_file","/wp-content/plugins/woocommerce/assets/client/admin/print-shipping-label-banner/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3565","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-category-metabox/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3566","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-category-metabox/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3567","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/attributes/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3568","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/attributes/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3569","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-attributes-field/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3570","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-attributes-field/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3571","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-category-field/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3572","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-category-field/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3573","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-checkbox-field/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3574","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-checkbox-field/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3575","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-images-field/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3576","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-images-field/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3577","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-inventory-email-field/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3578","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-inventory-email-field/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3579","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-name-field/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3580","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-name-field/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3581","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-pricing-field/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3582","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-pricing-field/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3583","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-regular-price-field/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3584","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-regular-price-field/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3585","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-sale-price-field/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3586","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-sale-price-field/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3587","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-schedule-sale-fields/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3588","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-schedule-sale-fields/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3589","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-section/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3590","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-section/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3591","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-shipping-dimensions-fields/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3592","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-shipping-dimensions-fields/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3593","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-sku-field/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3594","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-sku-field/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3595","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-summary-field/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3596","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-summary-field/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3597","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-tab/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3598","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-tab/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3599","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-variations-fields/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3600","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/blocks/product-variations-fields/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3601","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/category/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3602","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/category/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3603","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/checkbox/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3604","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/checkbox/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3605","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/collapsible/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3606","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/collapsible/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3607","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/conditional/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3608","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/conditional/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3609","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/description/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3610","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/description/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3611","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/images/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3612","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/images/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3613","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/inventory-email/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3614","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/inventory-email/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3615","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/inventory-email/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3616","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/inventory-quantity/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3617","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/inventory-quantity/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3618","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/inventory-quantity/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3619","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/inventory-sku/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3620","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/inventory-sku/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3621","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/name/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3622","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/name/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3623","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/name/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3624","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/pricing/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3625","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/pricing/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3626","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/pricing/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3627","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/radio/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3628","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/radio/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3629","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/radio/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3630","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/regular-price/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3631","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/regular-price/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3632","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/regular-price/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3633","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/sale-price/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3634","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/sale-price/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3635","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/sale-price/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3636","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/schedule-sale/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3637","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/schedule-sale/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3638","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/schedule-sale/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3639","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/section/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3640","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/section/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3641","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/section/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3642","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/shipping-class/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3643","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/shipping-class/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3644","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/shipping-class/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3645","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/shipping-dimensions/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3646","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/shipping-dimensions/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3647","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/shipping-dimensions/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3648","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/summary/paragraph-rtl-control/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3649","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/summary/paragraph-rtl-control/paragraph-rtl-control.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3650","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/summary/paragraph-rtl-control/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3651","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/summary/constants.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3652","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/summary/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3653","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/summary/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3654","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/summary/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3655","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/tab/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3656","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/tab/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3657","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/tab/tab-button.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3658","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/toggle/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3659","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/toggle/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3660","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/toggle/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3661","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/variations/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3662","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/variations/empty-variations-image.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3663","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/variations/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3664","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/variations/types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3665","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/blocks/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3666","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/index.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3667","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3668","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3669","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-editor/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3670","static_file","/wp-content/plugins/woocommerce/assets/client/admin/product-page/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3671","static_file","/wp-content/plugins/woocommerce/assets/client/admin/profile-wizard/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3672","static_file","/wp-content/plugins/woocommerce/assets/client/admin/shipping-recommendations/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3673","static_file","/wp-content/plugins/woocommerce/assets/client/admin/store-alerts/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3674","static_file","/wp-content/plugins/woocommerce/assets/client/admin/store-performance/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3675","static_file","/wp-content/plugins/woocommerce/assets/client/admin/tracks/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3676","static_file","/wp-content/plugins/woocommerce/assets/client/admin/undefined/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3677","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wcpay-payment-welcome-page/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3678","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/marketing-coupons.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3679","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/payment-method-promotions.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3680","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/add-term-tracking.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3681","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/attributes-tracking.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3682","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/beta-features-tracking-modal.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3683","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/category-tracking.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3684","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/marketing-coupons.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3685","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/navigation-opt-out.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3686","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/onboarding-homepage-notice.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3687","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/onboarding-load-sample-products-notice.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3688","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/onboarding-product-import-notice.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3689","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/onboarding-product-notice.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3690","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/onboarding-tax-notice.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3691","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/order-tracking.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3692","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/payment-method-promotions.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3693","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/print-shipping-label-banner.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3694","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/product-category-metabox.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3695","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/product-import-tracking.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3696","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/product-tour.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3697","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/product-tracking.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3698","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/settings-tracking.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3699","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/tags-tracking.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3700","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/variable-product-tour.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3701","static_file","/wp-content/plugins/woocommerce/assets/client/admin/wp-admin-scripts/wc-addons-tour.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3702","static_file","/wp-content/plugins/woocommerce/assets/client/admin/0e8ec0e45d8a1d55b30c.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3703","static_file","/wp-content/plugins/woocommerce/assets/client/admin/46f3be5272a3932c5a1a.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3704","static_file","/wp-content/plugins/woocommerce/assets/client/admin/7a66c49439f3a365c211.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3705","static_file","/wp-content/plugins/woocommerce/assets/client/admin/838cedcc9d9dfff18d8a.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3706","static_file","/wp-content/plugins/woocommerce/assets/client/admin/93973815f7cd64d5f512.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3707","static_file","/wp-content/plugins/woocommerce/assets/client/admin/cc33bd6b007cb731bcc3.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3708","static_file","/wp-content/plugins/woocommerce/assets/client/admin/d11c9a0dc859f1236a96.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3709","static_file","/wp-content/plugins/woocommerce/assets/client/admin/df4b3b75be51b9e11f96.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3710","static_file","/wp-content/plugins/woocommerce/assets/client/admin/f574e970a917e4dff5ec.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3711","static_file","/wp-content/plugins/woocommerce/assets/client/admin/67a480dd787ddfb504af.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3712","static_file","/wp-content/plugins/woocommerce/assets/client/admin/bfec8d1574ef61285fc9.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:39","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3713","static_file","/wp-content/plugins/woocommerce/assets/client/admin/d070003c8575faa9f2fc.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:40","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3714","static_file","/wp-content/plugins/woocommerce/assets/client/admin/dbfe730286a89feb7ce0.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3715","static_file","/wp-content/plugins/woocommerce/assets/client/admin/e6774bfd47e76d1fdbb5.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:41","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3716","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-bg_flat_0_aaaaaa_40x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3717","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-bg_flat_75_ffffff_40x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3718","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-bg_glass_55_fbf9ee_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3719","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-bg_glass_65_ffffff_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3720","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-bg_glass_75_dadada_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3721","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-bg_glass_75_e6e6e6_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3722","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-bg_glass_95_fef1ec_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3723","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-bg_highlight-soft_75_cccccc_1x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3724","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-icons_222222_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3725","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-icons_2e83ff_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3726","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-icons_454545_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3727","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-icons_888888_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3728","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/images/ui-icons_cd0a0a_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3729","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/jquery-ui-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3730","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/jquery-ui.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3731","static_file","/wp-content/plugins/woocommerce/assets/css/jquery-ui/jquery-ui.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3732","static_file","/wp-content/plugins/woocommerce/assets/css/photoswipe/default-skin/default-skin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3733","static_file","/wp-content/plugins/woocommerce/assets/css/photoswipe/default-skin/default-skin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3734","static_file","/wp-content/plugins/woocommerce/assets/css/photoswipe/default-skin/preloader.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3735","static_file","/wp-content/plugins/woocommerce/assets/css/photoswipe/default-skin/default-skin.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3736","static_file","/wp-content/plugins/woocommerce/assets/css/photoswipe/default-skin/default-skin.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3737","static_file","/wp-content/plugins/woocommerce/assets/css/photoswipe/photoswipe.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3738","static_file","/wp-content/plugins/woocommerce/assets/css/photoswipe/photoswipe.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3739","static_file","/wp-content/plugins/woocommerce/assets/css/activation-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3740","static_file","/wp-content/plugins/woocommerce/assets/css/activation.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3741","static_file","/wp-content/plugins/woocommerce/assets/css/admin-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3742","static_file","/wp-content/plugins/woocommerce/assets/css/admin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3743","static_file","/wp-content/plugins/woocommerce/assets/css/auth-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3744","static_file","/wp-content/plugins/woocommerce/assets/css/auth.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3745","static_file","/wp-content/plugins/woocommerce/assets/css/dashboard-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3746","static_file","/wp-content/plugins/woocommerce/assets/css/dashboard-setup-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3747","static_file","/wp-content/plugins/woocommerce/assets/css/dashboard-setup.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3748","static_file","/wp-content/plugins/woocommerce/assets/css/dashboard.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3749","static_file","/wp-content/plugins/woocommerce/assets/css/helper-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3750","static_file","/wp-content/plugins/woocommerce/assets/css/helper.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:42","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3751","static_file","/wp-content/plugins/woocommerce/assets/css/marketplace-suggestions-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3752","static_file","/wp-content/plugins/woocommerce/assets/css/marketplace-suggestions.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3753","static_file","/wp-content/plugins/woocommerce/assets/css/menu-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3754","static_file","/wp-content/plugins/woocommerce/assets/css/menu.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3755","static_file","/wp-content/plugins/woocommerce/assets/css/network-order-widget-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3756","static_file","/wp-content/plugins/woocommerce/assets/css/network-order-widget.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3757","static_file","/wp-content/plugins/woocommerce/assets/css/prettyPhoto-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3758","static_file","/wp-content/plugins/woocommerce/assets/css/prettyPhoto.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3759","static_file","/wp-content/plugins/woocommerce/assets/css/privacy-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3760","static_file","/wp-content/plugins/woocommerce/assets/css/privacy.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3761","static_file","/wp-content/plugins/woocommerce/assets/css/reports-print-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3762","static_file","/wp-content/plugins/woocommerce/assets/css/reports-print.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3763","static_file","/wp-content/plugins/woocommerce/assets/css/select2.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3764","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-nineteen-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3765","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-nineteen.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3766","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-seventeen-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3767","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-seventeen.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3768","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-twenty-one-admin-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3769","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-twenty-one-admin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3770","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-twenty-one-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3771","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-twenty-one.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3772","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-twenty-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3773","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-twenty-three-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3774","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-twenty-three.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3775","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-twenty-two-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3776","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-twenty-two.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3777","static_file","/wp-content/plugins/woocommerce/assets/css/twenty-twenty.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3778","static_file","/wp-content/plugins/woocommerce/assets/css/wc-setup-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3779","static_file","/wp-content/plugins/woocommerce/assets/css/wc-setup.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3780","static_file","/wp-content/plugins/woocommerce/assets/css/woocommerce-blocktheme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3781","static_file","/wp-content/plugins/woocommerce/assets/css/woocommerce-blocktheme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3782","static_file","/wp-content/plugins/woocommerce/assets/css/woocommerce-layout-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3783","static_file","/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3784","static_file","/wp-content/plugins/woocommerce/assets/css/woocommerce-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3785","static_file","/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3786","static_file","/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3787","static_file","/wp-content/plugins/woocommerce/assets/css/woocommerce.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3788","static_file","/wp-content/plugins/woocommerce/assets/fonts/WooCommerce.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3789","static_file","/wp-content/plugins/woocommerce/assets/fonts/star.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3790","static_file","/wp-content/plugins/woocommerce/assets/fonts/WooCommerce.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3791","static_file","/wp-content/plugins/woocommerce/assets/fonts/star.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3792","static_file","/wp-content/plugins/woocommerce/assets/fonts/WooCommerce.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3793","static_file","/wp-content/plugins/woocommerce/assets/fonts/star.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3794","static_file","/wp-content/plugins/woocommerce/assets/fonts/WooCommerce.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3795","static_file","/wp-content/plugins/woocommerce/assets/fonts/star.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3796","static_file","/wp-content/plugins/woocommerce/assets/images/admin_notes/dashboard-widget-setup.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3797","static_file","/wp-content/plugins/woocommerce/assets/images/admin_notes/marketing-jetpack-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3798","static_file","/wp-content/plugins/woocommerce/assets/images/admin_notes/filter-by-product-variations-note.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3799","static_file","/wp-content/plugins/woocommerce/assets/images/core-profiler/logo-google.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3800","static_file","/wp-content/plugins/woocommerce/assets/images/core-profiler/logo-jetpack.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3801","static_file","/wp-content/plugins/woocommerce/assets/images/core-profiler/logo-mailpoet.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3802","static_file","/wp-content/plugins/woocommerce/assets/images/core-profiler/logo-pinterest.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3803","static_file","/wp-content/plugins/woocommerce/assets/images/core-profiler/logo-tiktok.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3804","static_file","/wp-content/plugins/woocommerce/assets/images/core-profiler/logo-woo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3805","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/amex.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3806","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/diners.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3807","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/discover.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3808","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/jcb.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3809","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/laser.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3810","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/maestro.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3811","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/mastercard.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3812","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/visa.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3813","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/amex.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3814","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/diners.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3815","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/discover.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3816","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/jcb.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3817","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/laser.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3818","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/maestro.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3819","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/mastercard.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3820","static_file","/wp-content/plugins/woocommerce/assets/images/icons/credit-cards/visa.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3821","static_file","/wp-content/plugins/woocommerce/assets/images/icons/edit.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3822","static_file","/wp-content/plugins/woocommerce/assets/images/icons/external-link.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3823","static_file","/wp-content/plugins/woocommerce/assets/images/icons/global-attributes-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3824","static_file","/wp-content/plugins/woocommerce/assets/images/icons/gridicons-checkmark.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3825","static_file","/wp-content/plugins/woocommerce/assets/images/icons/gridicons-chevron-down.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3826","static_file","/wp-content/plugins/woocommerce/assets/images/icons/info.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3827","static_file","/wp-content/plugins/woocommerce/assets/images/icons/loader.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3828","static_file","/wp-content/plugins/woocommerce/assets/images/icons/star-golden.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3829","static_file","/wp-content/plugins/woocommerce/assets/images/icons/star-gray.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3830","static_file","/wp-content/plugins/woocommerce/assets/images/icons/star-half-filled.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3831","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/creative-mail-by-constant-contact.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3832","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/klaviyo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3833","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/trustpilot.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3834","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/vimeo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3835","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/zapier.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3836","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/salesforce.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3837","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/tiktok.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3838","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/amazon-ebay.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3839","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/automatewoo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3840","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/facebook.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3841","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/google.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3842","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/hubspot.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3843","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/jetpack-crm.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3844","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/mailchimp.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3845","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/mailpoet.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3846","static_file","/wp-content/plugins/woocommerce/assets/images/marketing/pinterest.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3847","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/codistoconnect.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3848","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/creative-mail-by-constant-contact.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3849","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/creativemail.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3850","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/eway.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3851","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/facebook.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3852","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/fb-woocommerce.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3853","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/g-shopping.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3854","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/klaviyo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3855","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/mailchimp-for-woocommerce.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3856","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/mailchimp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3857","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/mailpoet.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3858","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/mercadopago.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3859","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/payoneer.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3860","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/paystack.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3861","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/pinterest.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3862","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/zipco.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3863","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/other-small.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3864","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/bacs.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3865","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/cod.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3866","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/google.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3867","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/jetpack.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3868","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/mollie.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3869","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/payu.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3870","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/razorpay.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3871","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/tiktok.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3872","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/wcpay.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3873","static_file","/wp-content/plugins/woocommerce/assets/images/onboarding/woo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3874","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/affirm.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3875","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/afterpay.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3876","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/amazonpay.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3877","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/bacs.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3878","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/cod.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3879","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/eway.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3880","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/klarna.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3881","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/mercadopago.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3882","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/mollie.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3883","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/payfast.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3884","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/payoneer.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3885","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/paypal.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3886","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/paystack.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3887","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/payu.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3888","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/razorpay.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3889","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/square.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3890","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/stripe.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3891","static_file","/wp-content/plugins/woocommerce/assets/images/payment_methods/72x72/zipco.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3892","static_file","/wp-content/plugins/woocommerce/assets/images/product_data/no-variation-arrow.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3893","static_file","/wp-content/plugins/woocommerce/assets/images/product_data/no-variation-background-image.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3894","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/check.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3895","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/discount.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3896","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/envia-column.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3897","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/packlink-column.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3898","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/packlink-row.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3899","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/paper.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3900","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/printer.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3901","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/sendcloud-column.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3902","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/sendcloud-row.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3903","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/shipstation-column.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3904","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/shipstation-row.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3905","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/skydropx-column.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3906","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/star.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3907","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/timer.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3908","static_file","/wp-content/plugins/woocommerce/assets/images/shipping_partners/wcs-column.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3909","static_file","/wp-content/plugins/woocommerce/assets/images/task_list/basics-section-illustration.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3910","static_file","/wp-content/plugins/woocommerce/assets/images/task_list/expand-section-illustration.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3911","static_file","/wp-content/plugins/woocommerce/assets/images/task_list/payment-illustration.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3912","static_file","/wp-content/plugins/woocommerce/assets/images/task_list/purchase-illustration.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3913","static_file","/wp-content/plugins/woocommerce/assets/images/task_list/sales-illustration.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3914","static_file","/wp-content/plugins/woocommerce/assets/images/task_list/sales-section-illustration.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3915","static_file","/wp-content/plugins/woocommerce/assets/images/task_list/shipping-illustration.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3916","static_file","/wp-content/plugins/woocommerce/assets/images/task_list/store-details-illustration.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3917","static_file","/wp-content/plugins/woocommerce/assets/images/task_list/tax-illustration.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3918","static_file","/wp-content/plugins/woocommerce/assets/images/select2-spinner.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3919","static_file","/wp-content/plugins/woocommerce/assets/images/wpspin-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3920","static_file","/wp-content/plugins/woocommerce/assets/images/wpspin.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3921","static_file","/wp-content/plugins/woocommerce/assets/images/calendar.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3922","static_file","/wp-content/plugins/woocommerce/assets/images/dashboard-widget-setup.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3923","static_file","/wp-content/plugins/woocommerce/assets/images/help.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3924","static_file","/wp-content/plugins/woocommerce/assets/images/klarna-black.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3925","static_file","/wp-content/plugins/woocommerce/assets/images/marketplace-header-bg@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3926","static_file","/wp-content/plugins/woocommerce/assets/images/mercadopago.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3927","static_file","/wp-content/plugins/woocommerce/assets/images/payfast.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3928","static_file","/wp-content/plugins/woocommerce/assets/images/paypal-braintree.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3929","static_file","/wp-content/plugins/woocommerce/assets/images/paypal.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3930","static_file","/wp-content/plugins/woocommerce/assets/images/placeholder-attachment.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3931","static_file","/wp-content/plugins/woocommerce/assets/images/placeholder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3932","static_file","/wp-content/plugins/woocommerce/assets/images/select2.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3933","static_file","/wp-content/plugins/woocommerce/assets/images/select2x2.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3934","static_file","/wp-content/plugins/woocommerce/assets/images/square-black.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3935","static_file","/wp-content/plugins/woocommerce/assets/images/stripe.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3936","static_file","/wp-content/plugins/woocommerce/assets/images/wcpayments-icon-secure.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3937","static_file","/wp-content/plugins/woocommerce/assets/images/woocommerce_logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3938","static_file","/wp-content/plugins/woocommerce/assets/images/eway-logo.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3939","static_file","/wp-content/plugins/woocommerce/assets/images/empty-content.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:43","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3940","static_file","/wp-content/plugins/woocommerce/assets/images/shippingillustration.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3941","static_file","/wp-content/plugins/woocommerce/assets/images/woocommerce_logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3942","static_file","/wp-content/plugins/woocommerce/assets/js/accounting/accounting.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3943","static_file","/wp-content/plugins/woocommerce/assets/js/accounting/accounting.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3944","static_file","/wp-content/plugins/woocommerce/assets/js/admin/api-keys.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3945","static_file","/wp-content/plugins/woocommerce/assets/js/admin/api-keys.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3946","static_file","/wp-content/plugins/woocommerce/assets/js/admin/backbone-modal.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3947","static_file","/wp-content/plugins/woocommerce/assets/js/admin/backbone-modal.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3948","static_file","/wp-content/plugins/woocommerce/assets/js/admin/marketplace-suggestions.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3949","static_file","/wp-content/plugins/woocommerce/assets/js/admin/marketplace-suggestions.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3950","static_file","/wp-content/plugins/woocommerce/assets/js/admin/meta-boxes-coupon.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3951","static_file","/wp-content/plugins/woocommerce/assets/js/admin/meta-boxes-coupon.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3952","static_file","/wp-content/plugins/woocommerce/assets/js/admin/meta-boxes-order.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3953","static_file","/wp-content/plugins/woocommerce/assets/js/admin/meta-boxes-order.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3954","static_file","/wp-content/plugins/woocommerce/assets/js/admin/meta-boxes-product-variation.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3955","static_file","/wp-content/plugins/woocommerce/assets/js/admin/meta-boxes-product-variation.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3956","static_file","/wp-content/plugins/woocommerce/assets/js/admin/meta-boxes-product.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3957","static_file","/wp-content/plugins/woocommerce/assets/js/admin/meta-boxes-product.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3958","static_file","/wp-content/plugins/woocommerce/assets/js/admin/meta-boxes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3959","static_file","/wp-content/plugins/woocommerce/assets/js/admin/meta-boxes.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3960","static_file","/wp-content/plugins/woocommerce/assets/js/admin/network-orders.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3961","static_file","/wp-content/plugins/woocommerce/assets/js/admin/network-orders.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3962","static_file","/wp-content/plugins/woocommerce/assets/js/admin/product-editor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3963","static_file","/wp-content/plugins/woocommerce/assets/js/admin/product-editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3964","static_file","/wp-content/plugins/woocommerce/assets/js/admin/product-ordering.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3965","static_file","/wp-content/plugins/woocommerce/assets/js/admin/product-ordering.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3966","static_file","/wp-content/plugins/woocommerce/assets/js/admin/quick-edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3967","static_file","/wp-content/plugins/woocommerce/assets/js/admin/quick-edit.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3968","static_file","/wp-content/plugins/woocommerce/assets/js/admin/reports.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3969","static_file","/wp-content/plugins/woocommerce/assets/js/admin/reports.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3970","static_file","/wp-content/plugins/woocommerce/assets/js/admin/settings-views-html-settings-tax.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:36");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3971","static_file","/wp-content/plugins/woocommerce/assets/js/admin/settings-views-html-settings-tax.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3972","static_file","/wp-content/plugins/woocommerce/assets/js/admin/settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3973","static_file","/wp-content/plugins/woocommerce/assets/js/admin/settings.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3974","static_file","/wp-content/plugins/woocommerce/assets/js/admin/system-status.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3975","static_file","/wp-content/plugins/woocommerce/assets/js/admin/system-status.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3976","static_file","/wp-content/plugins/woocommerce/assets/js/admin/term-ordering.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3977","static_file","/wp-content/plugins/woocommerce/assets/js/admin/term-ordering.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3978","static_file","/wp-content/plugins/woocommerce/assets/js/admin/users.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3979","static_file","/wp-content/plugins/woocommerce/assets/js/admin/users.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3980","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-clipboard.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3981","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-clipboard.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3982","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-enhanced-select.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3983","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-enhanced-select.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:44","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3984","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-orders.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3985","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-orders.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3986","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-product-export.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3987","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-product-export.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3988","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-product-import.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3989","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-product-import.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3990","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-setup.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3991","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-setup.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3992","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-shipping-classes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3993","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-shipping-classes.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3994","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-shipping-zone-methods.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3995","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-shipping-zone-methods.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3996","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-shipping-zones.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3997","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-shipping-zones.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3998","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-status-widget.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3999","static_file","/wp-content/plugins/woocommerce/assets/js/admin/wc-status-widget.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4000","static_file","/wp-content/plugins/woocommerce/assets/js/admin/woocommerce_admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/