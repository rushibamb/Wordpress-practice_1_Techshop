

DROP TABLE IF EXISTS `webtoffee_actionscheduler_logs` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=MyISAM AUTO_INCREMENT=2193 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1572","484","action created","2023-07-01 06:43:18","2023-07-01 06:43:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1718","512","action started via WP Cron","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1703","504","action started via WP Cron","2023-07-21 15:43:13","2023-07-21 15:43:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1704","504","action complete via WP Cron","2023-07-21 15:43:14","2023-07-21 15:43:14");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2115","657","action started via Admin List Table","2023-10-02 13:57:56","2023-10-02 13:57:56");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2189","725","action created","2023-10-19 22:07:16","2023-10-19 22:07:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2053","648","action created","2023-09-07 12:00:24","2023-09-07 12:00:24");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2054","648","action started via Admin List Table","2023-09-07 12:00:34","2023-09-07 12:00:34");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2055","648","action complete via Admin List Table","2023-09-07 12:00:34","2023-09-07 12:00:34");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2101","671","action complete via Admin List Table","2023-10-02 13:56:49","2023-10-02 13:56:49");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2057","619","action started via Admin List Table","2023-09-07 12:00:45","2023-09-07 12:00:45");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2058","619","action complete via Admin List Table","2023-09-07 12:00:45","2023-09-07 12:00:45");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2071","660","action created","2023-09-07 12:01:12","2023-09-07 12:01:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2049","646","action complete via Admin List Table","2023-09-07 12:00:12","2023-09-07 12:00:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2051","626","action started via Admin List Table","2023-09-07 12:00:24","2023-09-07 12:00:24");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1658","513","action created","2023-07-18 14:04:04","2023-07-18 14:04:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2037","642","action complete via Admin List Table","2023-09-07 11:59:23","2023-09-07 11:59:23");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2038","643","action created","2023-09-07 11:59:23","2023-09-07 11:59:23");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2039","643","action started via Admin List Table","2023-09-07 11:59:39","2023-09-07 11:59:39");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2040","643","action complete via Admin List Table","2023-09-07 11:59:39","2023-09-07 11:59:39");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2041","644","action created","2023-09-07 11:59:39","2023-09-07 11:59:39");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2042","644","action started via Admin List Table","2023-09-07 11:59:48","2023-09-07 11:59:48");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1676","518","action started via WP Cron","2023-07-18 14:09:37","2023-07-18 14:09:37");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1677","518","action complete via WP Cron","2023-07-18 14:09:37","2023-07-18 14:09:37");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2045","645","action started via Admin List Table","2023-09-07 11:59:58","2023-09-07 11:59:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2046","645","action complete via Admin List Table","2023-09-07 11:59:58","2023-09-07 11:59:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2047","646","action created","2023-09-07 11:59:58","2023-09-07 11:59:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2048","646","action started via Admin List Table","2023-09-07 12:00:12","2023-09-07 12:00:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1672","518","action created","2023-07-18 14:09:34","2023-07-18 14:09:34");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1673","519","action created","2023-07-18 14:09:34","2023-07-18 14:09:34");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1674","519","action started via WP Cron","2023-07-18 14:09:37","2023-07-18 14:09:37");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1675","519","action complete via WP Cron","2023-07-18 14:09:37","2023-07-18 14:09:37");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1719","512","action complete via WP Cron","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1720","534","action created","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1717","533","action created","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1700","503","action started via WP Cron","2023-07-21 15:43:12","2023-07-21 15:43:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1699","527","action created","2023-07-21 15:43:12","2023-07-21 15:43:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1918","568","action started via Admin List Table","2023-09-02 14:26:41","2023-09-02 14:26:41");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1705","529","action created","2023-07-21 15:43:14","2023-07-21 15:43:14");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2025","639","action created","2023-09-07 11:58:49","2023-09-07 11:58:49");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1712","510","action started via WP Cron","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1713","510","action complete via WP Cron","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1694","501","action started via WP Cron","2023-07-21 15:43:10","2023-07-21 15:43:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1679","520","action created","2023-07-20 11:55:54","2023-07-20 11:55:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2019","637","action created","2023-09-07 11:58:28","2023-09-07 11:58:28");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1691","522","action started via WP Cron","2023-07-21 15:43:10","2023-07-21 15:43:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2035","641","action ignored via Admin List Table","2023-09-07 11:59:16","2023-09-07 11:59:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1711","531","action created","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1710","509","action complete via WP Cron","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1690","524","action created","2023-07-21 15:43:10","2023-07-21 15:43:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2033","641","action complete via Admin List Table","2023-09-07 11:59:13","2023-09-07 11:59:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1569","483","action created","2023-07-01 03:33:05","2023-07-01 03:33:05");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1882","582","action complete via Admin List Table","2023-09-02 14:20:24","2023-09-02 14:20:24");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1779","551","action complete via WP Cron","2023-07-31 18:18:20","2023-07-31 18:18:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1825","568","action created","2023-08-05 08:36:56","2023-08-05 08:36:56");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1826","558","action started via WP Cron","2023-08-05 08:36:56","2023-08-05 08:36:56");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1818","547","action complete via WP Cron","2023-08-05 08:36:55","2023-08-05 08:36:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1819","566","action created","2023-08-05 08:36:55","2023-08-05 08:36:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1820","548","action started via WP Cron","2023-08-05 08:36:55","2023-08-05 08:36:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1821","548","action complete via WP Cron","2023-08-05 08:36:55","2023-08-05 08:36:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1822","567","action created","2023-08-05 08:36:55","2023-08-05 08:36:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1823","549","action started via WP Cron","2023-08-05 08:36:55","2023-08-05 08:36:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1824","549","action complete via WP Cron","2023-08-05 08:36:56","2023-08-05 08:36:56");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1956","615","action complete via Admin List Table","2023-09-07 11:53:44","2023-09-07 11:53:44");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1955","615","action started via Admin List Table","2023-09-07 11:53:43","2023-09-07 11:53:43");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1938","602","action complete via Admin List Table","2023-09-04 15:53:43","2023-09-04 15:53:43");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1937","602","action started via Admin List Table","2023-09-04 15:53:43","2023-09-04 15:53:43");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1940","603","action complete via Admin List Table","2023-09-04 15:53:51","2023-09-04 15:53:51");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1941","604","action started via Admin List Table","2023-09-04 15:54:26","2023-09-04 15:54:26");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1942","604","action complete via Admin List Table","2023-09-04 15:54:26","2023-09-04 15:54:26");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1953","614","action complete via Admin List Table","2023-09-07 11:53:34","2023-09-07 11:53:34");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1936","600","action ignored via Admin List Table","2023-09-04 15:53:35","2023-09-04 15:53:35");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1951","615","action created","2023-09-07 11:51:38","2023-09-07 11:51:38");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1933","600","action started via Admin List Table","2023-09-04 15:53:34","2023-09-04 15:53:34");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1952","614","action started via Admin List Table","2023-09-07 11:53:33","2023-09-07 11:53:33");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1923","580","action started via Admin List Table","2023-09-02 14:27:50","2023-09-02 14:27:50");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1924","580","action complete via Admin List Table","2023-09-02 14:27:50","2023-09-02 14:27:50");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1925","602","action created","2023-09-04 15:44:04","2023-09-04 15:44:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1926","589","action started via Admin List Table","2023-09-04 15:53:09","2023-09-04 15:53:09");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1927","603","action created","2023-09-04 15:53:09","2023-09-04 15:53:09");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1928","589","action complete via Admin List Table","2023-09-04 15:53:09","2023-09-04 15:53:09");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2067","656","action created","2023-09-07 12:01:12","2023-09-07 12:01:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1739","538","action started via WP Cron","2023-07-28 12:05:16","2023-07-28 12:05:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1735","539","action created","2023-07-28 12:05:16","2023-07-28 12:05:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1736","537","action started via WP Cron","2023-07-28 12:05:16","2023-07-28 12:05:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1737","537","action complete via WP Cron","2023-07-28 12:05:16","2023-07-28 12:05:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1732","536","action started via WP Cron","2023-07-28 12:05:16","2023-07-28 12:05:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1733","538","action created","2023-07-28 12:05:16","2023-07-28 12:05:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1734","536","action complete via WP Cron","2023-07-28 12:05:16","2023-07-28 12:05:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2052","626","action complete via Admin List Table","2023-09-07 12:00:24","2023-09-07 12:00:24");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1701","503","action complete via WP Cron","2023-07-21 15:43:13","2023-07-21 15:43:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1702","528","action created","2023-07-21 15:43:13","2023-07-21 15:43:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1697","502","action started via WP Cron","2023-07-21 15:43:12","2023-07-21 15:43:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1698","502","action complete via WP Cron","2023-07-21 15:43:12","2023-07-21 15:43:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2105","674","action complete via Admin List Table","2023-10-02 13:57:39","2023-10-02 13:57:39");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2102","673","action started via Admin List Table","2023-10-02 13:57:04","2023-10-02 13:57:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2060","635","action started via Admin List Table","2023-09-07 12:00:53","2023-09-07 12:00:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2036","642","action started via Admin List Table","2023-09-07 11:59:23","2023-09-07 11:59:23");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2027","639","action complete via Admin List Table","2023-09-07 11:58:58","2023-09-07 11:58:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2028","640","action created","2023-09-07 11:58:58","2023-09-07 11:58:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2029","640","action started via Admin List Table","2023-09-07 11:59:05","2023-09-07 11:59:05");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2030","640","action complete via Admin List Table","2023-09-07 11:59:05","2023-09-07 11:59:05");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2031","641","action created","2023-09-07 11:59:05","2023-09-07 11:59:05");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2032","641","action started via Admin List Table","2023-09-07 11:59:13","2023-09-07 11:59:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1692","522","action complete via WP Cron","2023-07-21 15:43:10","2023-07-21 15:43:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1693","525","action created","2023-07-21 15:43:10","2023-07-21 15:43:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2020","637","action started via Admin List Table","2023-09-07 11:58:41","2023-09-07 11:58:41");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1696","526","action created","2023-07-21 15:43:12","2023-07-21 15:43:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2034","642","action created","2023-09-07 11:59:13","2023-09-07 11:59:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1958","612","action complete via Admin List Table","2023-09-07 11:53:53","2023-09-07 11:53:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1915","597","action started via Admin List Table","2023-09-02 14:25:40","2023-09-02 14:25:40");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1738","540","action created","2023-07-28 12:05:16","2023-07-28 12:05:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1957","612","action started via Admin List Table","2023-09-07 11:53:53","2023-09-07 11:53:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1934","600","action complete via Admin List Table","2023-09-04 15:53:34","2023-09-04 15:53:34");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1929","604","action created","2023-09-04 15:53:09","2023-09-04 15:53:09");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1930","590","action started via Admin List Table","2023-09-04 15:53:24","2023-09-04 15:53:24");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1931","590","action complete via Admin List Table","2023-09-04 15:53:24","2023-09-04 15:53:24");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1922","578","action complete via Admin List Table","2023-09-02 14:27:16","2023-09-02 14:27:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1916","597","action complete via Admin List Table","2023-09-02 14:25:40","2023-09-02 14:25:40");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1917","600","action created","2023-09-02 14:25:40","2023-09-02 14:25:40");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2103","673","action complete via Admin List Table","2023-10-02 13:57:04","2023-10-02 13:57:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1948","612","action created","2023-09-04 15:54:50","2023-09-04 15:54:50");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1921","578","action started via Admin List Table","2023-09-02 14:27:16","2023-09-02 14:27:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2068","657","action created","2023-09-07 12:01:12","2023-09-07 12:01:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1919","568","action complete via Admin List Table","2023-09-02 14:26:41","2023-09-02 14:26:41");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1814","546","action started via WP Cron","2023-08-05 08:36:55","2023-08-05 08:36:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1835","572","action created","2023-08-05 08:48:11","2023-08-05 08:48:11");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1836","573","action created","2023-08-05 08:48:24","2023-08-05 08:48:24");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1837","571","action started via WP Cron","2023-08-05 08:48:25","2023-08-05 08:48:25");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1838","571","action complete via WP Cron","2023-08-05 08:48:25","2023-08-05 08:48:25");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1839","572","action started via WP Cron","2023-08-05 08:48:25","2023-08-05 08:48:25");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1816","565","action created","2023-08-05 08:36:55","2023-08-05 08:36:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1817","547","action started via WP Cron","2023-08-05 08:36:55","2023-08-05 08:36:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1881","582","action started via Admin List Table","2023-09-02 14:20:24","2023-09-02 14:20:24");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1654","512","action created","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1815","546","action complete via WP Cron","2023-08-05 08:36:55","2023-08-05 08:36:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1778","551","action started via WP Cron","2023-07-31 18:18:20","2023-07-31 18:18:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1652","490","action started via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1880","583","action complete via Admin List Table","2023-09-02 14:20:10","2023-09-02 14:20:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1777","553","action created","2023-07-31 18:18:20","2023-07-31 18:18:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1650","489","action complete via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1832","570","action started via WP Cron","2023-08-05 08:47:29","2023-08-05 08:47:29");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1833","570","action complete via WP Cron","2023-08-05 08:47:29","2023-08-05 08:47:29");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1834","571","action created","2023-08-05 08:48:11","2023-08-05 08:48:11");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1828","569","action created","2023-08-05 08:39:25","2023-08-05 08:39:25");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1829","569","action started via Async Request","2023-08-05 08:40:13","2023-08-05 08:40:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1830","569","action complete via Async Request","2023-08-05 08:40:13","2023-08-05 08:40:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1831","570","action created","2023-08-05 08:43:52","2023-08-05 08:43:52");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1879","583","action started via Admin List Table","2023-09-02 14:20:09","2023-09-02 14:20:09");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1876","579","action complete via Admin List Table","2023-09-02 14:19:39","2023-09-02 14:19:39");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1877","581","action started via Admin List Table","2023-09-02 14:19:49","2023-09-02 14:19:49");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1878","581","action complete via Admin List Table","2023-09-02 14:19:49","2023-09-02 14:19:49");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1860","583","action created","2023-08-15 17:33:24","2023-08-15 17:33:24");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1857","580","action created","2023-08-15 11:53:07","2023-08-15 11:53:07");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1858","581","action created","2023-08-15 11:54:32","2023-08-15 11:54:32");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1859","582","action created","2023-08-15 17:33:24","2023-08-15 17:33:24");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1646","488","action started via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1647","488","action complete via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1643","487","action started via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1865","588","action created","2023-09-02 09:38:46","2023-09-02 09:38:46");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1861","584","action created","2023-08-15 17:36:10","2023-08-15 17:36:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1862","585","action created","2023-08-16 06:33:42","2023-08-16 06:33:42");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1863","586","action created","2023-08-17 03:20:24","2023-08-17 03:20:24");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1864","587","action created","2023-08-26 10:39:46","2023-08-26 10:39:46");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1854","575","action complete via WP Cron","2023-08-06 09:02:36","2023-08-06 09:02:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1855","578","action created","2023-08-15 11:51:27","2023-08-15 11:51:27");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1856","579","action created","2023-08-15 11:53:07","2023-08-15 11:53:07");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1853","575","action started via WP Cron","2023-08-06 09:02:36","2023-08-06 09:02:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1852","577","action created","2023-08-06 09:02:36","2023-08-06 09:02:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1606","496","action created","2023-07-05 11:31:53","2023-07-05 11:31:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1847","575","action created","2023-08-06 09:02:36","2023-08-06 09:02:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1848","559","action complete via WP Cron","2023-08-06 09:02:36","2023-08-06 09:02:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1603","495","action created","2023-07-05 11:31:53","2023-07-05 11:31:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1638","495","action complete via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1639","507","action created","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1637","506","action created","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1851","560","action complete via WP Cron","2023-08-06 09:02:36","2023-08-06 09:02:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1850","560","action started via WP Cron","2023-08-06 09:02:36","2023-08-06 09:02:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1649","489","action started via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1648","510","action created","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1670","517","action started via Async Request","2023-07-18 14:06:00","2023-07-18 14:06:00");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1653","490","action complete via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1651","511","action created","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1668","516","action started via Async Request","2023-07-18 14:06:00","2023-07-18 14:06:00");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1656","506","action complete via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1655","506","action started via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1664","513","action started via Async Request","2023-07-18 14:04:04","2023-07-18 14:04:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1662","505","action complete via Async Request","2023-07-18 14:04:04","2023-07-18 14:04:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1645","509","action created","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1644","487","action complete via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1660","514","action created","2023-07-18 14:04:04","2023-07-18 14:04:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1636","495","action started via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1634","496","action complete via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1635","505","action created","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1631","483","action complete via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1632","504","action created","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1629","503","action created","2023-07-14 15:32:58","2023-07-14 15:32:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1630","483","action started via WP Cron","2023-07-14 15:32:58","2023-07-14 15:32:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1626","502","action created","2023-07-14 15:32:58","2023-07-14 15:32:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1625","485","action complete via WP Cron","2023-07-14 15:32:58","2023-07-14 15:32:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1624","485","action started via WP Cron","2023-07-14 15:32:57","2023-07-14 15:32:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1623","501","action created","2023-07-14 15:32:57","2023-07-14 15:32:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1622","486","action complete via WP Cron","2023-07-14 15:32:57","2023-07-14 15:32:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1621","486","action started via WP Cron","2023-07-14 15:32:57","2023-07-14 15:32:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2114","682","action complete via Admin List Table","2023-10-02 13:57:48","2023-10-02 13:57:48");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2113","682","action started via Admin List Table","2023-10-02 13:57:48","2023-10-02 13:57:48");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2112","684","action created","2023-10-02 13:57:42","2023-10-02 13:57:42");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2111","683","action created","2023-10-02 13:57:42","2023-10-02 13:57:42");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2110","682","action created","2023-10-02 13:57:42","2023-10-02 13:57:42");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2109","681","action created","2023-10-02 13:57:41","2023-10-02 13:57:41");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1628","484","action complete via WP Cron","2023-07-14 15:32:58","2023-07-14 15:32:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2108","680","action created","2023-10-02 13:57:41","2023-10-02 13:57:41");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1627","484","action started via WP Cron","2023-07-14 15:32:58","2023-07-14 15:32:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2164","700","action created","2023-10-19 22:04:36","2023-10-19 22:04:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1633","496","action started via WP Cron","2023-07-14 15:32:59","2023-07-14 15:32:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2104","674","action started via Admin List Table","2023-10-02 13:57:39","2023-10-02 13:57:39");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2095","673","action created","2023-10-02 05:04:24","2023-10-02 05:04:24");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2094","672","action created","2023-10-02 05:04:18","2023-10-02 05:04:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2093","671","action created","2023-10-02 05:04:18","2023-10-02 05:04:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2092","670","action created","2023-10-01 19:31:53","2023-10-01 19:31:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2091","669","action created","2023-09-30 16:29:46","2023-09-30 16:29:46");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2178","714","action created","2023-10-19 22:06:17","2023-10-19 22:06:17");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2089","665","action complete via Admin List Table","2023-09-10 15:31:11","2023-09-10 15:31:11");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2088","665","action started via Admin List Table","2023-09-10 15:31:11","2023-09-10 15:31:11");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2096","674","action created","2023-10-02 05:56:12","2023-10-02 05:56:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2086","660","action complete via Admin List Table","2023-09-10 15:31:03","2023-09-10 15:31:03");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2085","660","action started via Admin List Table","2023-09-10 15:31:02","2023-09-10 15:31:02");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2084","665","action created","2023-09-10 15:31:02","2023-09-10 15:31:02");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2083","661","action complete via Admin List Table","2023-09-10 15:30:57","2023-09-10 15:30:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2082","661","action started via Admin List Table","2023-09-10 15:30:57","2023-09-10 15:30:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2097","675","action created","2023-10-02 05:56:12","2023-10-02 05:56:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2192","728","action created","2023-10-20 00:23:40","2023-10-20 00:23:40");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2167","703","action created","2023-10-19 22:04:36","2023-10-19 22:04:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2076","656","action started via Admin List Table","2023-09-10 15:30:39","2023-09-10 15:30:39");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2077","656","action complete via Admin List Table","2023-09-10 15:30:39","2023-09-10 15:30:39");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2075","662","action complete via Admin List Table","2023-09-10 15:30:29","2023-09-10 15:30:29");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2073","662","action created","2023-09-09 21:13:58","2023-09-09 21:13:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2074","662","action started via Admin List Table","2023-09-10 15:30:29","2023-09-10 15:30:29");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2072","661","action created","2023-09-07 13:26:20","2023-09-07 13:26:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2061","635","action complete via Admin List Table","2023-09-07 12:00:53","2023-09-07 12:00:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1671","517","action complete via Async Request","2023-07-18 14:06:01","2023-07-18 14:06:01");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1913","565","action complete via Admin List Table","2023-09-02 14:25:23","2023-09-02 14:25:23");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1669","516","action complete via Async Request","2023-07-18 14:06:00","2023-07-18 14:06:00");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1667","517","action created","2023-07-18 14:04:16","2023-07-18 14:04:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1666","516","action created","2023-07-18 14:04:16","2023-07-18 14:04:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1912","565","action started via Admin List Table","2023-09-02 14:25:23","2023-09-02 14:25:23");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1665","513","action complete via Async Request","2023-07-18 14:04:04","2023-07-18 14:04:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1910","566","action complete via Admin List Table","2023-09-02 14:24:36","2023-09-02 14:24:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1663","515","action created","2023-07-18 14:04:04","2023-07-18 14:04:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1661","505","action started via Async Request","2023-07-18 14:04:04","2023-07-18 14:04:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1909","566","action started via Admin List Table","2023-09-02 14:24:36","2023-09-02 14:24:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1659","507","action complete via Async Request","2023-07-18 14:04:04","2023-07-18 14:04:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1657","507","action started via Async Request","2023-07-18 14:04:04","2023-07-18 14:04:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1721","523","action started via WP Cron","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1686","520","action complete via WP Cron","2023-07-20 11:55:54","2023-07-20 11:55:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1685","520","action started via WP Cron","2023-07-20 11:55:54","2023-07-20 11:55:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1684","522","action created","2023-07-20 11:55:54","2023-07-20 11:55:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1683","515","action complete via WP Cron","2023-07-20 11:55:54","2023-07-20 11:55:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1682","515","action started via WP Cron","2023-07-20 11:55:54","2023-07-20 11:55:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1681","521","action created","2023-07-20 11:55:54","2023-07-20 11:55:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1680","514","action complete via WP Cron","2023-07-20 11:55:54","2023-07-20 11:55:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1695","501","action complete via WP Cron","2023-07-21 15:43:12","2023-07-21 15:43:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1689","521","action complete via WP Cron","2023-07-21 15:43:10","2023-07-21 15:43:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2043","644","action complete via Admin List Table","2023-09-07 11:59:48","2023-09-07 11:59:48");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2044","645","action created","2023-09-07 11:59:48","2023-09-07 11:59:48");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1709","509","action started via WP Cron","2023-07-21 15:43:14","2023-07-21 15:43:14");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1678","514","action started via WP Cron","2023-07-20 11:55:54","2023-07-20 11:55:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1722","523","action complete via WP Cron","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1716","511","action complete via WP Cron","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1714","532","action created","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1715","511","action started via WP Cron","2023-07-21 15:43:15","2023-07-21 15:43:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1688","523","action created","2023-07-21 15:43:10","2023-07-21 15:43:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1687","521","action started via WP Cron","2023-07-21 15:43:09","2023-07-21 15:43:09");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2026","639","action started via Admin List Table","2023-09-07 11:58:58","2023-09-07 11:58:58");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2023","638","action started via Admin List Table","2023-09-07 11:58:49","2023-09-07 11:58:49");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2024","638","action complete via Admin List Table","2023-09-07 11:58:49","2023-09-07 11:58:49");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2018","636","action complete via Admin List Table","2023-09-07 11:58:28","2023-09-07 11:58:28");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2017","636","action started via Admin List Table","2023-09-07 11:58:28","2023-09-07 11:58:28");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2016","636","action created","2023-09-07 11:58:19","2023-09-07 11:58:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2022","638","action created","2023-09-07 11:58:41","2023-09-07 11:58:41");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2021","637","action complete via Admin List Table","2023-09-07 11:58:41","2023-09-07 11:58:41");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2015","634","action complete via Admin List Table","2023-09-07 11:58:19","2023-09-07 11:58:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2014","634","action started via Admin List Table","2023-09-07 11:58:18","2023-09-07 11:58:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1727","525","action started via WP Cron","2023-07-24 09:34:18","2023-07-24 09:34:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1728","525","action complete via WP Cron","2023-07-24 09:34:18","2023-07-24 09:34:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2011","627","action started via Admin List Table","2023-09-07 11:58:10","2023-09-07 11:58:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1729","537","action created","2023-07-24 09:34:18","2023-07-24 09:34:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1730","535","action started via WP Cron","2023-07-24 09:34:18","2023-07-24 09:34:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1731","535","action complete via WP Cron","2023-07-24 09:34:18","2023-07-24 09:34:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2009","633","action complete via Admin List Table","2023-09-07 11:58:04","2023-09-07 11:58:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2010","634","action created","2023-09-07 11:58:04","2023-09-07 11:58:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1724","535","action created","2023-07-24 09:34:18","2023-07-24 09:34:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1725","524","action complete via WP Cron","2023-07-24 09:34:18","2023-07-24 09:34:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2013","635","action created","2023-09-07 11:58:10","2023-09-07 11:58:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1726","536","action created","2023-07-24 09:34:18","2023-07-24 09:34:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1723","524","action started via WP Cron","2023-07-24 09:34:18","2023-07-24 09:34:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2012","627","action complete via Admin List Table","2023-09-07 11:58:10","2023-09-07 11:58:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2008","633","action started via Admin List Table","2023-09-07 11:58:04","2023-09-07 11:58:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2007","633","action created","2023-09-07 11:57:57","2023-09-07 11:57:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2006","632","action complete via Admin List Table","2023-09-07 11:57:57","2023-09-07 11:57:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2005","632","action started via Admin List Table","2023-09-07 11:57:57","2023-09-07 11:57:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2004","632","action created","2023-09-07 11:57:22","2023-09-07 11:57:22");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2003","631","action complete via Admin List Table","2023-09-07 11:57:22","2023-09-07 11:57:22");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2002","631","action started via Admin List Table","2023-09-07 11:57:22","2023-09-07 11:57:22");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2001","631","action created","2023-09-07 11:57:07","2023-09-07 11:57:07");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2000","630","action complete via Admin List Table","2023-09-07 11:57:07","2023-09-07 11:57:07");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1999","630","action started via Admin List Table","2023-09-07 11:57:07","2023-09-07 11:57:07");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1998","630","action created","2023-09-07 11:56:57","2023-09-07 11:56:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1997","629","action complete via Admin List Table","2023-09-07 11:56:57","2023-09-07 11:56:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1996","629","action started via Admin List Table","2023-09-07 11:56:57","2023-09-07 11:56:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1995","629","action created","2023-09-07 11:56:44","2023-09-07 11:56:44");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1994","628","action complete via Admin List Table","2023-09-07 11:56:44","2023-09-07 11:56:44");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1993","628","action started via Admin List Table","2023-09-07 11:56:44","2023-09-07 11:56:44");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1992","628","action created","2023-09-07 11:56:36","2023-09-07 11:56:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1991","620","action complete via Admin List Table","2023-09-07 11:56:36","2023-09-07 11:56:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1990","620","action started via Admin List Table","2023-09-07 11:56:36","2023-09-07 11:56:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1989","627","action created","2023-09-07 11:56:28","2023-09-07 11:56:28");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1988","617","action complete via Admin List Table","2023-09-07 11:56:28","2023-09-07 11:56:28");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1987","617","action started via Admin List Table","2023-09-07 11:56:28","2023-09-07 11:56:28");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1986","626","action created","2023-09-07 11:56:08","2023-09-07 11:56:08");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1985","625","action complete via Admin List Table","2023-09-07 11:56:08","2023-09-07 11:56:08");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1984","625","action started via Admin List Table","2023-09-07 11:56:08","2023-09-07 11:56:08");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1809","544","action complete via WP Cron","2023-08-05 08:36:55","2023-08-05 08:36:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1983","625","action created","2023-09-07 11:55:48","2023-09-07 11:55:48");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1982","624","action complete via Admin List Table","2023-09-07 11:55:48","2023-09-07 11:55:48");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1981","624","action started via Admin List Table","2023-09-07 11:55:48","2023-09-07 11:55:48");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1980","624","action created","2023-09-07 11:55:38","2023-09-07 11:55:38");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1979","623","action complete via Admin List Table","2023-09-07 11:55:38","2023-09-07 11:55:38");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1978","623","action started via Admin List Table","2023-09-07 11:55:38","2023-09-07 11:55:38");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1977","623","action created","2023-09-07 11:55:28","2023-09-07 11:55:28");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1976","622","action complete via Admin List Table","2023-09-07 11:55:28","2023-09-07 11:55:28");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1975","622","action started via Admin List Table","2023-09-07 11:55:28","2023-09-07 11:55:28");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1974","622","action created","2023-09-07 11:55:19","2023-09-07 11:55:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1973","621","action complete via Admin List Table","2023-09-07 11:55:19","2023-09-07 11:55:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1972","621","action started via Admin List Table","2023-09-07 11:55:19","2023-09-07 11:55:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1971","621","action created","2023-09-07 11:55:10","2023-09-07 11:55:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1970","595","action complete via Admin List Table","2023-09-07 11:55:10","2023-09-07 11:55:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1969","595","action started via Admin List Table","2023-09-07 11:55:10","2023-09-07 11:55:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1968","620","action created","2023-09-07 11:54:59","2023-09-07 11:54:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1967","616","action complete via Admin List Table","2023-09-07 11:54:59","2023-09-07 11:54:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1966","616","action started via Admin List Table","2023-09-07 11:54:59","2023-09-07 11:54:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1965","619","action created","2023-09-07 11:54:13","2023-09-07 11:54:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2100","671","action started via Admin List Table","2023-10-02 13:56:49","2023-10-02 13:56:49");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1963","611","action started via Admin List Table","2023-09-07 11:54:13","2023-09-07 11:54:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1964","611","action complete via Admin List Table","2023-09-07 11:54:13","2023-09-07 11:54:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1961","610","action complete via Admin List Table","2023-09-07 11:54:04","2023-09-07 11:54:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1960","610","action started via Admin List Table","2023-09-07 11:54:04","2023-09-07 11:54:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1959","617","action created","2023-09-07 11:53:53","2023-09-07 11:53:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1954","616","action created","2023-09-07 11:53:34","2023-09-07 11:53:34");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1908","584","action complete via Admin List Table","2023-09-02 14:24:13","2023-09-02 14:24:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1907","584","action started via Admin List Table","2023-09-02 14:24:13","2023-09-02 14:24:13");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1906","585","action complete via Admin List Table","2023-09-02 14:23:57","2023-09-02 14:23:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1905","585","action started via Admin List Table","2023-09-02 14:23:57","2023-09-02 14:23:57");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1903","588","action complete via Admin List Table","2023-09-02 14:23:42","2023-09-02 14:23:42");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1904","597","action created","2023-09-02 14:23:45","2023-09-02 14:23:45");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1808","544","action started via WP Cron","2023-08-05 08:36:54","2023-08-05 08:36:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1740","538","action complete via WP Cron","2023-07-28 12:05:16","2023-07-28 12:05:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1805","543","action started via WP Cron","2023-08-05 08:36:54","2023-08-05 08:36:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1806","543","action complete via WP Cron","2023-08-05 08:36:54","2023-08-05 08:36:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1802","542","action started via WP Cron","2023-08-05 08:36:54","2023-08-05 08:36:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1797","553","action complete via WP Cron","2023-08-05 08:36:53","2023-08-05 08:36:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1798","560","action created","2023-08-05 08:36:53","2023-08-05 08:36:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1793","558","action created","2023-08-05 08:36:53","2023-08-05 08:36:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1794","552","action complete via WP Cron","2023-08-05 08:36:53","2023-08-05 08:36:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1790","557","action started via WP Cron","2023-08-01 08:16:19","2023-08-01 08:16:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1902","588","action started via Admin List Table","2023-09-02 14:23:42","2023-09-02 14:23:42");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1946","610","action created","2023-09-04 15:54:49","2023-09-04 15:54:49");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1900","567","action complete via Admin List Table","2023-09-02 14:23:26","2023-09-02 14:23:26");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1899","567","action started via Admin List Table","2023-09-02 14:23:26","2023-09-02 14:23:26");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1897","586","action started via Admin List Table","2023-09-02 14:23:12","2023-09-02 14:23:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1898","586","action complete via Admin List Table","2023-09-02 14:23:12","2023-09-02 14:23:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1896","595","action created","2023-09-02 14:22:07","2023-09-02 14:22:07");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1895","550","action complete via Admin List Table","2023-09-02 14:22:07","2023-09-02 14:22:07");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1939","603","action started via Admin List Table","2023-09-04 15:53:51","2023-09-04 15:53:51");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1893","587","action complete via Admin List Table","2023-09-02 14:21:55","2023-09-02 14:21:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1894","550","action started via Admin List Table","2023-09-02 14:22:06","2023-09-02 14:22:06");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1767","549","action created","2023-07-28 16:09:20","2023-07-28 16:09:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1766","534","action complete via WP Cron","2023-07-28 16:09:20","2023-07-28 16:09:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1765","534","action started via WP Cron","2023-07-28 16:09:20","2023-07-28 16:09:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1764","548","action created","2023-07-28 16:09:20","2023-07-28 16:09:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1763","533","action complete via WP Cron","2023-07-28 16:09:20","2023-07-28 16:09:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1762","533","action started via WP Cron","2023-07-28 16:09:20","2023-07-28 16:09:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1761","547","action created","2023-07-28 16:09:20","2023-07-28 16:09:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1760","532","action complete via WP Cron","2023-07-28 16:09:20","2023-07-28 16:09:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1759","532","action started via WP Cron","2023-07-28 16:09:19","2023-07-28 16:09:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1758","546","action created","2023-07-28 16:09:19","2023-07-28 16:09:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1757","531","action complete via WP Cron","2023-07-28 16:09:19","2023-07-28 16:09:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1756","531","action started via WP Cron","2023-07-28 16:09:19","2023-07-28 16:09:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1744","527","action started via WP Cron","2023-07-28 16:09:18","2023-07-28 16:09:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1745","527","action complete via WP Cron","2023-07-28 16:09:18","2023-07-28 16:09:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1746","542","action created","2023-07-28 16:09:18","2023-07-28 16:09:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1747","528","action started via WP Cron","2023-07-28 16:09:18","2023-07-28 16:09:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1748","528","action complete via WP Cron","2023-07-28 16:09:19","2023-07-28 16:09:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1749","543","action created","2023-07-28 16:09:19","2023-07-28 16:09:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1750","529","action started via WP Cron","2023-07-28 16:09:19","2023-07-28 16:09:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1751","529","action complete via WP Cron","2023-07-28 16:09:19","2023-07-28 16:09:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1752","544","action created","2023-07-28 16:09:19","2023-07-28 16:09:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1743","541","action created","2023-07-28 16:09:18","2023-07-28 16:09:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1742","526","action complete via WP Cron","2023-07-28 16:09:18","2023-07-28 16:09:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1741","526","action started via WP Cron","2023-07-28 16:09:18","2023-07-28 16:09:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1892","587","action started via Admin List Table","2023-09-02 14:21:55","2023-09-02 14:21:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1947","611","action created","2023-09-04 15:54:49","2023-09-04 15:54:49");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1875","579","action started via Admin List Table","2023-09-02 14:19:39","2023-09-02 14:19:39");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1950","614","action created","2023-09-04 15:54:50","2023-09-04 15:54:50");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1871","590","action created","2023-09-02 14:19:15","2023-09-02 14:19:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1870","577","action complete via Admin List Table","2023-09-02 14:19:15","2023-09-02 14:19:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1869","577","action started via Admin List Table","2023-09-02 14:19:15","2023-09-02 14:19:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1868","589","action created","2023-09-02 14:19:12","2023-09-02 14:19:12");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1845","574","action complete via WP Cron","2023-08-05 08:49:26","2023-08-05 08:49:26");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1844","574","action started via WP Cron","2023-08-05 08:49:26","2023-08-05 08:49:26");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1841","573","action started via WP Cron","2023-08-05 08:48:25","2023-08-05 08:48:25");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1842","573","action complete via WP Cron","2023-08-05 08:48:25","2023-08-05 08:48:25");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1843","574","action created","2023-08-05 08:48:55","2023-08-05 08:48:55");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1840","572","action complete via WP Cron","2023-08-05 08:48:25","2023-08-05 08:48:25");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1827","558","action complete via WP Cron","2023-08-05 08:36:56","2023-08-05 08:36:56");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1773","539","action complete via WP Cron","2023-07-31 18:18:20","2023-07-31 18:18:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1774","552","action created","2023-07-31 18:18:20","2023-07-31 18:18:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1775","540","action started via WP Cron","2023-07-31 18:18:20","2023-07-31 18:18:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1776","540","action complete via WP Cron","2023-07-31 18:18:20","2023-07-31 18:18:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1543","475","action created","2023-06-29 06:26:47","2023-06-29 06:26:47");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1772","551","action created","2023-07-31 18:18:20","2023-07-31 18:18:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1771","539","action started via WP Cron","2023-07-31 18:18:20","2023-07-31 18:18:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1770","550","action created","2023-07-31 18:18:20","2023-07-31 18:18:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1787","557","action created","2023-08-01 08:15:04","2023-08-01 08:15:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1769","475","action complete via WP Cron","2023-07-31 18:18:20","2023-07-31 18:18:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1768","475","action started via WP Cron","2023-07-31 18:18:20","2023-07-31 18:18:20");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1786","556","action created","2023-08-01 08:15:04","2023-08-01 08:15:04");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1784","555","action started via WP Cron","2023-08-01 08:13:50","2023-08-01 08:13:50");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1785","555","action complete via WP Cron","2023-08-01 08:13:50","2023-08-01 08:13:50");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1575","485","action created","2023-07-01 06:43:18","2023-07-01 06:43:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1803","542","action complete via WP Cron","2023-08-05 08:36:54","2023-08-05 08:36:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1578","486","action created","2023-07-01 06:43:19","2023-07-01 06:43:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1800","541","action complete via WP Cron","2023-08-05 08:36:54","2023-08-05 08:36:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1799","541","action started via WP Cron","2023-08-05 08:36:53","2023-08-05 08:36:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1581","487","action created","2023-07-01 06:43:19","2023-07-01 06:43:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1796","553","action started via WP Cron","2023-08-05 08:36:53","2023-08-05 08:36:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1795","559","action created","2023-08-05 08:36:53","2023-08-05 08:36:53");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1584","488","action created","2023-07-01 06:43:19","2023-07-01 06:43:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1792","552","action started via WP Cron","2023-08-05 08:36:52","2023-08-05 08:36:52");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1791","557","action complete via WP Cron","2023-08-01 08:16:19","2023-08-01 08:16:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1587","489","action created","2023-07-01 06:43:19","2023-07-01 06:43:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1789","556","action complete via WP Cron","2023-08-01 08:16:19","2023-08-01 08:16:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1788","556","action started via WP Cron","2023-08-01 08:16:18","2023-08-01 08:16:18");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1590","490","action created","2023-07-01 06:43:19","2023-07-01 06:43:19");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1782","554","action complete via WP Cron","2023-08-01 08:09:31","2023-08-01 08:09:31");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1783","555","action created","2023-08-01 08:09:56","2023-08-01 08:09:56");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1846","559","action started via WP Cron","2023-08-06 09:02:36","2023-08-06 09:02:36");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1781","554","action started via WP Cron","2023-08-01 08:09:31","2023-08-01 08:09:31");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("1780","554","action created","2023-08-01 08:09:07","2023-08-01 08:09:07");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2116","657","action complete via Admin List Table","2023-10-02 13:57:56","2023-10-02 13:57:56");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2117","685","action created","2023-10-02 13:57:56","2023-10-02 13:57:56");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2118","681","action started via Admin List Table","2023-10-02 13:58:06","2023-10-02 13:58:06");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2119","681","action complete via Admin List Table","2023-10-02 13:58:06","2023-10-02 13:58:06");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2169","705","action created","2023-10-19 22:04:37","2023-10-19 22:04:37");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2121","669","action started via Admin List Table","2023-10-02 13:58:14","2023-10-02 13:58:14");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2122","669","action complete via Admin List Table","2023-10-02 13:58:15","2023-10-02 13:58:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2123","670","action started via Admin List Table","2023-10-02 13:58:46","2023-10-02 13:58:46");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2124","670","action complete via Admin List Table","2023-10-02 13:58:46","2023-10-02 13:58:46");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2125","675","action started via Admin List Table","2023-10-02 13:58:54","2023-10-02 13:58:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2126","675","action complete via Admin List Table","2023-10-02 13:58:54","2023-10-02 13:58:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2127","687","action created","2023-10-02 13:58:54","2023-10-02 13:58:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2128","672","action started via Admin List Table","2023-10-02 13:59:02","2023-10-02 13:59:02");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2129","672","action complete via Admin List Table","2023-10-02 13:59:02","2023-10-02 13:59:02");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2130","683","action started via Admin List Table","2023-10-02 13:59:10","2023-10-02 13:59:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2131","683","action complete via Admin List Table","2023-10-02 13:59:10","2023-10-02 13:59:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2132","688","action created","2023-10-02 13:59:10","2023-10-02 13:59:10");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2133","684","action started via Admin List Table","2023-10-02 13:59:39","2023-10-02 13:59:39");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2134","684","action complete via Admin List Table","2023-10-02 13:59:39","2023-10-02 13:59:39");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2135","680","action started via Admin List Table","2023-10-02 13:59:46","2023-10-02 13:59:46");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2136","680","action complete via Admin List Table","2023-10-02 13:59:46","2023-10-02 13:59:46");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2137","689","action created","2023-10-02 13:59:46","2023-10-02 13:59:46");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2138","690","action created","2023-10-02 15:51:46","2023-10-02 15:51:46");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2139","690","action started via Admin List Table","2023-10-05 18:24:41","2023-10-05 18:24:41");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2140","690","action complete via Admin List Table","2023-10-05 18:24:41","2023-10-05 18:24:41");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2142","687","action started via Admin List Table","2023-10-05 18:24:42","2023-10-05 18:24:42");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2143","687","action complete via Admin List Table","2023-10-05 18:24:42","2023-10-05 18:24:42");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2191","727","action created","2023-10-19 22:07:16","2023-10-19 22:07:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2145","688","action started via Admin List Table","2023-10-05 18:24:45","2023-10-05 18:24:45");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2146","688","action complete via Admin List Table","2023-10-05 18:24:45","2023-10-05 18:24:45");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2190","726","action created","2023-10-19 22:07:16","2023-10-19 22:07:16");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2148","689","action started via Admin List Table","2023-10-05 18:24:46","2023-10-05 18:24:46");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2149","689","action complete via Admin List Table","2023-10-05 18:24:46","2023-10-05 18:24:46");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2170","706","action created","2023-10-19 22:04:37","2023-10-19 22:04:37");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2151","695","action created","2023-10-05 18:24:50","2023-10-05 18:24:50");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2152","690","action ignored via Admin List Table","2023-10-05 18:24:54","2023-10-05 18:24:54");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2153","687","action ignored via Admin List Table","2023-10-05 18:24:56","2023-10-05 18:24:56");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2154","688","action ignored via Admin List Table","2023-10-05 18:24:59","2023-10-05 18:24:59");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2155","688","action ignored via Admin List Table","2023-10-05 18:25:00","2023-10-05 18:25:00");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2156","690","action ignored via Admin List Table","2023-10-05 18:25:01","2023-10-05 18:25:01");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2157","690","action ignored via Admin List Table","2023-10-05 18:25:01","2023-10-05 18:25:01");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2158","695","action started via Admin List Table","2023-10-05 18:25:14","2023-10-05 18:25:14");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2159","695","action complete via Admin List Table","2023-10-05 18:25:15","2023-10-05 18:25:15");/*END*/
INSERT INTO `webtoffee_actionscheduler_logs` VALUES
("2165","701","action created","2023-10-19 22:04:36","2023-10-19 22:04:36");/*END*/