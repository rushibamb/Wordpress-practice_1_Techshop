
INSERT INTO `webtoffee_urls` VALUES
("4001","static_file","/wp-content/plugins/woocommerce/assets/js/admin/woocommerce_admin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4002","static_file","/wp-content/plugins/woocommerce/assets/js/flexslider/jquery.flexslider.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4003","static_file","/wp-content/plugins/woocommerce/assets/js/flexslider/jquery.flexslider.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4004","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/add-payment-method.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4005","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/add-payment-method.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4006","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4007","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4008","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4009","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4010","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/address-i18n.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4011","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/address-i18n.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4012","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4013","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4014","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/cart.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4015","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/cart.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4016","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/checkout.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4017","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/checkout.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4018","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/country-select.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4019","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/country-select.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4020","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/credit-card-form.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4021","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/credit-card-form.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4022","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/geolocation.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4023","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/geolocation.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4024","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/lost-password.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4025","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/lost-password.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4026","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/password-strength-meter.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4027","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/password-strength-meter.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4028","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/price-slider.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4029","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/price-slider.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4030","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/single-product.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4031","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/single-product.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4032","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/tokenization-form.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4033","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/tokenization-form.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4034","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4035","static_file","/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4036","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4037","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4038","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4039","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4040","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-flot/jquery.flot.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4041","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-flot/jquery.flot.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4042","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-flot/jquery.flot.pie.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4043","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-flot/jquery.flot.pie.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4044","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-flot/jquery.flot.resize.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4045","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-flot/jquery.flot.resize.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4046","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-flot/jquery.flot.stack.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4047","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-flot/jquery.flot.stack.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4048","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-flot/jquery.flot.time.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4049","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-flot/jquery.flot.time.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4050","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-payment/jquery.payment.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4051","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-payment/jquery.payment.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4052","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-qrcode/jquery.qrcode.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4053","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-qrcode/jquery.qrcode.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4054","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-serializejson/jquery.serializejson.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4055","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-serializejson/jquery.serializejson.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4056","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-tiptip/jquery.tipTip.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4057","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-tiptip/jquery.tipTip.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4058","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-ui-touch-punch/jquery-ui-touch-punch.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4059","static_file","/wp-content/plugins/woocommerce/assets/js/jquery-ui-touch-punch/jquery-ui-touch-punch.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4060","static_file","/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4061","static_file","/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4062","static_file","/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe-ui-default.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4063","static_file","/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe-ui-default.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4064","static_file","/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4065","static_file","/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4066","static_file","/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.init.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4067","static_file","/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.init.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4068","static_file","/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4069","static_file","/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4070","static_file","/wp-content/plugins/woocommerce/assets/js/round/round.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4071","static_file","/wp-content/plugins/woocommerce/assets/js/round/round.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4072","static_file","/wp-content/plugins/woocommerce/assets/js/select2/select2.full.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4073","static_file","/wp-content/plugins/woocommerce/assets/js/select2/select2.full.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4074","static_file","/wp-content/plugins/woocommerce/assets/js/select2/select2.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4075","static_file","/wp-content/plugins/woocommerce/assets/js/select2/select2.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4076","static_file","/wp-content/plugins/woocommerce/assets/js/selectWoo/selectWoo.full.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4077","static_file","/wp-content/plugins/woocommerce/assets/js/selectWoo/selectWoo.full.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:45","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4078","static_file","/wp-content/plugins/woocommerce/assets/js/selectWoo/selectWoo.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:46","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4079","static_file","/wp-content/plugins/woocommerce/assets/js/selectWoo/selectWoo.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:46","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4080","static_file","/wp-content/plugins/woocommerce/assets/js/stupidtable/stupidtable.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:46","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4081","static_file","/wp-content/plugins/woocommerce/assets/js/stupidtable/stupidtable.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:46","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4082","static_file","/wp-content/plugins/woocommerce/assets/js/zoom/jquery.zoom.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:46","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4083","static_file","/wp-content/plugins/woocommerce/assets/js/zoom/jquery.zoom.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:46","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4084","static_file","/wp-content/plugins/woocommerce/includes/gateways/paypal/assets/images/paypal.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:49","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4085","static_file","/wp-content/plugins/woocommerce/includes/gateways/paypal/assets/js/paypal-admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:49","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4086","static_file","/wp-content/plugins/woocommerce/includes/gateways/paypal/assets/js/paypal-admin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:49","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4087","static_file","/wp-content/plugins/woocommerce/packages/action-scheduler/license.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4088","static_file","/wp-content/plugins/woocommerce/packages/action-scheduler/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4089","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/atomic/blocks/product-elements/shared/with-product-selector.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4090","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/atomic/blocks/product-elements/title/test/block.test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4091","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/atomic/blocks/product-elements/save.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4092","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/atomic/blocks/component-init.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4093","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/atomic/blocks/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4094","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/atomic/utils/create-blocks-from-template.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4095","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/atomic/utils/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4096","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/atomic/utils/render-standalone-blocks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4097","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/cart-checkout/address-form/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4098","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/cart-checkout/form-step/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4099","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/cart-checkout/order-summary/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4100","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/cart-checkout/product-details/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4101","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/cart-checkout/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4102","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/chip/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4103","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/label/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4104","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/notice-banner/screenshots/default.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4105","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/notice-banner/screenshots/error.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4106","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/notice-banner/screenshots/info.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4107","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/notice-banner/screenshots/success.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4108","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/notice-banner/screenshots/warning.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4109","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/pagination/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4110","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/price-slider/test/constrain-range-slider-values.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:52","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4111","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/product-name/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4112","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/product-price/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4113","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/reviews/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4114","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/sidebar-layout/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4115","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/components/summary/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4116","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/event-emit/test/emitters.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4117","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/hooks/cart/test/use-store-cart-item-quantity.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4118","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/hooks/cart/test/use-store-cart.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4119","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/hooks/collections/test/use-collection.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4120","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/hooks/payment-methods/test/use-payment-method-interface.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4121","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/hooks/payment-methods/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4122","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/hooks/shipping/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4123","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/hooks/test/use-checkout-submit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4124","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/hooks/test/use-query-state.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4125","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/hooks/test/use-store-products.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4126","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/hooks/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4127","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/hooks/use-checkout-submit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4128","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/hooks/use-query-state.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4129","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/add-to-cart-form/form-state/actions.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4130","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/add-to-cart-form/form-state/constants.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4131","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/add-to-cart-form/form-state/event-emit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4132","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/add-to-cart-form/form-state/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4133","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/add-to-cart-form/form-state/reducer.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4134","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/add-to-cart-form/form/submit/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4135","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/add-to-cart-form/form/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4136","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/add-to-cart-form/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4137","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/cart-checkout/cart/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4138","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/cart-checkout/shipping/event-emit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4139","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/cart-checkout/shipping/reducers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4140","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/cart-checkout/shipping/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4141","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/cart-checkout/checkout-provider.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4142","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/cart-checkout/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4143","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4144","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/providers/query-state-context.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4145","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/test/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4146","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/context/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4147","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/hocs/test/with-reviews.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4148","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/hocs/with-scroll-to-top/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4149","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/hocs/with-reviews.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4150","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/hooks/test/use-position-relative-to-viewport.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4151","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/hooks/test/use-previous.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4152","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/hooks/test/use-shallow-equal.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4153","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/hooks/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4154","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/hooks/use-position-relative-to-viewport.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4155","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/utils/test/errors.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4156","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/utils/errors.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4157","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/utils/get-valid-block-attributes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4158","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/utils/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4159","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/base/utils/product-data.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4160","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks-registry/block-components/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4161","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks-registry/block-components/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4162","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks-registry/block-components/register-block-component.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4163","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks-registry/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4164","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart-checkout-shared/payment-methods/express-payment/cart-express-payment.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4165","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart-checkout-shared/payment-methods/express-payment/checkout-express-payment.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4166","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart-checkout-shared/payment-methods/express-payment/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4167","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart-checkout-shared/payment-methods/no-payment-methods/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4168","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart-checkout-shared/payment-methods/test/payment-methods.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4169","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart-checkout-shared/payment-methods/express-payment-methods.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4170","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart-checkout-shared/payment-methods/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4171","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart-checkout-shared/payment-methods/payment-method-card.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4172","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart-checkout-shared/payment-methods/payment-method-error-boundary.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4173","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart-checkout-shared/payment-methods/payment-method-options.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4174","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart-checkout-shared/payment-methods/payment-methods.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4175","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart-checkout-shared/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4176","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart/test/block.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4177","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart/test/slots.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4178","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart/attributes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4179","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart/block.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4180","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4181","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart/frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4182","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/cart/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:53","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4183","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/checkout/checkout-order-error/constants.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4184","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/checkout/checkout-order-error/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4185","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/checkout/empty-cart/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4186","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/checkout/inner-blocks/checkout-contact-information-block/login-prompt.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4187","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/checkout/inner-blocks/checkout-order-summary-block/test/block.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4188","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/checkout/inner-blocks/checkout-shipping-method-block/shared/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4189","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/checkout/inner-blocks/checkout-shipping-methods-block/no-shipping-placeholder/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4190","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/checkout/inner-blocks/checkout-terms-block/test/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4191","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/checkout/inner-blocks/checkout-terms-block/test/frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4192","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/checkout/inner-blocks/checkout-terms-block/constants.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4193","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/checkout/order-notes/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4194","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/checkout/phone-number/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4195","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/classic-template/assets/doc-image-single-product-classic-block.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:54","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4196","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/mini-cart/test/block.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4197","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/price-filter/test/use-price-constraints.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4198","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/product-on-sale/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4199","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/products/all-products/defaults.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4200","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/products/all-products/deprecated.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4201","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/products/all-products/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4202","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/products/all-products/frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4203","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/products/all-products/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4204","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/products/all-products/save.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4205","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/products/base-utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4206","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/products/edit-utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4207","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/products/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4208","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/products/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4209","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/reviews/reviews-by-product/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4210","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/reviews/reviews-by-product/no-reviews-placeholder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4211","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/reviews/attributes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4212","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/reviews/edit-utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4213","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/reviews/editor-block.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4214","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/reviews/editor-container-block.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4215","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/reviews/example.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4216","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/reviews/frontend-block.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4217","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/reviews/frontend-container-block.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4218","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/reviews/frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4219","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/reviews/save.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4220","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/blocks/reviews/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4221","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/cart/test/reducers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4222","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/cart/test/selectors.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4223","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/collections/test/reducers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4224","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/collections/test/resolvers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4225","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/collections/test/selectors.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4226","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/collections/action-types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4227","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/collections/actions.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4228","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/collections/constants.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4229","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/collections/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4230","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/collections/reducers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4231","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/collections/resolvers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4232","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/collections/selectors.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4233","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/payment/test/reducers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4234","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/payment/test/selectors.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4235","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/query-state/test/reducers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4236","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/query-state/test/selectors.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4237","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/query-state/action-types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4238","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/query-state/actions.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4239","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/query-state/constants.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4240","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/query-state/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4241","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/query-state/reducers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4242","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/query-state/selectors.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4243","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/query-state/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4244","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/schema/test/reducers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4245","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/schema/test/resolvers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4246","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/schema/test/selectors.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4247","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/schema/test/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4248","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/schema/action-types.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4249","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/schema/actions.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4250","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/schema/constants.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4251","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/schema/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4252","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/schema/reducers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4253","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/schema/resolvers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4254","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/schema/selectors.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:55","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4255","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/schema/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4256","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/data/utils/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4257","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/editor-components/heading-toolbar/heading-level-icon.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4258","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/editor-components/heading-toolbar/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4259","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/editor-components/page-selector/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4260","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/editor-components/product-category-control/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4261","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/editor-components/product-control/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4262","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/editor-components/product-tag-control/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4263","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/editor-components/products-control/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4264","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/editor-components/search-list-control/test/hierarchy.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4265","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/editor-components/search-list-control/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4266","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/editor-components/tag/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4267","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/editor-components/text-toolbar-button/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4268","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/editor-components/utils/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4269","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/extensions/payment-methods/bacs/constants.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4270","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/extensions/payment-methods/bacs/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4271","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/extensions/payment-methods/cheque/constants.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4272","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/extensions/payment-methods/cheque/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4273","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/extensions/payment-methods/cod/constants.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4274","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/extensions/payment-methods/cod/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4275","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/extensions/payment-methods/paypal/constants.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4276","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/extensions/payment-methods/paypal/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4277","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/extensions/shipping-methods/pickup-location/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4278","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/filters/block-list-block.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4279","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/filters/exclude-draft-status-from-analytics.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4280","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/filters/get-block-attributes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4281","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/hocs/test/with-categories.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4282","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/hocs/test/with-category.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4283","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/hocs/test/with-product-variations.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4284","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/hocs/test/with-product.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4285","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/hocs/test/with-searched-products.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4286","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/hocs/test/with-transform-single-select-to-multiple-select.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4287","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/hocs/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4288","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/hocs/with-attributes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4289","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/hocs/with-categories.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4290","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/hocs/with-category.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4291","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/hocs/with-product-variations.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4292","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/hocs/with-product.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4293","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/icons/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4294","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/interactivity/constants.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4295","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/interactivity/directives.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4296","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/interactivity/hooks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4297","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/interactivity/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4298","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/interactivity/router.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4299","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/interactivity/store.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4300","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/interactivity/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4301","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/interactivity/vdom.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4302","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/middleware/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4303","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/middleware/store-api-nonce.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4304","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/previews/categories.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4305","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/previews/grid-block.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4306","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/previews/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4307","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/previews/products.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4308","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/previews/reviews.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4309","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/previews/saved-payment-methods.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4310","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/settings/shared/test/compare-with-wp-version.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4311","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/settings/shared/test/get-setting.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4312","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/shared/context/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4313","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/shared/hocs/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4314","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/shared/hocs/with-filtered-attributes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4315","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/shared/hocs/with-product-data-context.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4316","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/types/type-defs/add-to-cart-form.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4317","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/types/type-defs/address-fields.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4318","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/types/type-defs/billing.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4319","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/types/type-defs/cart.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4320","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/types/type-defs/contexts.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4321","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/types/type-defs/hooks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4322","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/types/type-defs/settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4323","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/types/type-defs/shipping.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4324","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/utils/test/filters.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4325","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/utils/test/notices.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4326","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/utils/test/products.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4327","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/utils/products.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4328","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/utils/shared-attributes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4329","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/assets/js/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4330","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/active-filters-wrapper--mini-cart-contents-block/cart-button--mini-cart-contents-block/checkout-but--3d5b804b-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4331","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-express-payment--checkout-blocks/express-payment-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4332","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-line-items--mini-cart-contents-block/products-table-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4333","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-accepted-payment-methods-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4334","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-accepted-payment-methods-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4335","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-cross-sells-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4336","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-cross-sells-products--product-price-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4337","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-cross-sells-products-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4338","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-cross-sells-products-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4339","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-cross-sells-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4340","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-express-payment-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4341","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-express-payment-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4342","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-items-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4343","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-items-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4344","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-line-items-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4345","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-line-items-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4346","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-order-summary-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4347","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-order-summary-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4348","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-totals-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4349","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/cart-totals-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4350","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/empty-cart-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4351","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/empty-cart-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4352","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/filled-cart-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4353","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/filled-cart-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4354","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-coupon-form-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4355","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-coupon-form-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4356","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-discount-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4357","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-discount-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4358","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-fee-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4359","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-fee-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4360","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-heading-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4361","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-heading-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4362","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-shipping-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4363","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-shipping-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4364","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-subtotal-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4365","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-subtotal-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4366","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-taxes-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4367","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/order-summary-taxes-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4368","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/proceed-to-checkout-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4369","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-blocks/proceed-to-checkout-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4370","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/actions--checkout-blocks/terms-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4371","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/billing-address--checkout-blocks/shipping-address-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4372","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/actions-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4373","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/actions-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4374","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/billing-address-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4375","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/billing-address-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4376","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/contact-information-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4377","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/contact-information-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4378","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/express-payment-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4379","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/fields-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4380","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/fields-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4381","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-note-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4382","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-cart-items-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4383","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-cart-items-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4384","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-coupon-form-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4385","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-coupon-form-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4386","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-discount-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4387","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-discount-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4388","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-fee-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4389","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-fee-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4390","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4391","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-shipping-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4392","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-shipping-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4393","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4394","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-subtotal-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4395","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-subtotal-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4396","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-taxes-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4397","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/order-summary-taxes-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4398","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/payment-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4399","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/payment-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4400","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/pickup-options-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4401","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/pickup-options-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4402","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/shipping-address-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4403","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/shipping-address-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4404","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/shipping-method-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4405","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/shipping-method-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4406","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/shipping-methods-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4407","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/shipping-methods-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4408","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/terms-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4409","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/terms-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4410","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/totals-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4411","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-blocks/totals-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4412","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/cart-button--mini-cart-contents-block/checkout-button--mini-cart-contents---358acf4e-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4413","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/footer-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4414","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/footer.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4415","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/products-table-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4416","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/products-table.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4417","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/cart-button-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4418","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/cart-button-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4419","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/checkout-button-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4420","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/checkout-button-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4421","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/empty-cart-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4422","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/empty-cart-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4423","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/filled-cart-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4424","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/filled-cart-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4425","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/footer-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4426","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/footer-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4427","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/items-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4428","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/items-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4429","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/products-table--product-summary-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4430","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/products-table-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4431","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/products-table-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4432","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/shopping-button-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4433","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/shopping-button-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4434","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/title-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4435","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/title-items-counter-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4436","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/title-items-counter-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4437","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/title-label-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4438","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/title-label-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4439","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-block/title-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4440","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--active-filters-wrapper--attribute-filter-wrapper--mini-cart-contents-block/cart-button--mi--6436fd83-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4441","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--attribute-filter-wrapper--cart-blocks/order-summary-coupon-form--cart-blocks/order-summary--48e1e4bb-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4442","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--attribute-filter-wrapper--cart-blocks/order-summary-shipping--checkout-blocks/billing-addr--d9f38f9d-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4443","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--cart-blocks/cart-cross-sells-products--cart-blocks/cart-line-items--cart-blocks/cart-order--3c5fe802-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4444","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--cart-blocks/cart-line-items--checkout-blocks/order-summary-cart-items--mini-cart-contents---233ab542-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4445","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--cart-blocks/order-summary-shipping--checkout-blocks/billing-address--checkout-blocks/order--decc3dc6-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4446","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--cart-blocks/proceed-to-checkout-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4447","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--checkout-blocks/pickup-options--checkout-blocks/shipping-methods-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4448","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--checkout-blocks/shipping-method-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4449","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--checkout-blocks/shipping-method-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4450","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--mini-cart-contents-block/products-table--price-filter-wrapper--product-price-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4451","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--mini-cart-contents-block/products-table-style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4452","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/active-filters-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4453","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/active-filters-wrapper-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4454","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/active-filters-wrapper.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4455","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/active-filters.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4456","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/add-to-cart-form-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4457","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/add-to-cart-form.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4458","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-products-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4459","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-products.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4460","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-reviews-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4461","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-reviews.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4462","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/attribute-filter-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4463","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/attribute-filter-wrapper-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4464","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/attribute-filter-wrapper.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4465","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/attribute-filter.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4466","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/breadcrumbs-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4467","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/breadcrumbs.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4468","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4469","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4470","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/catalog-sorting-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4471","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/catalog-sorting.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4472","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:37");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4473","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4474","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/customer-account-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4475","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/customer-account.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4476","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/featured-category-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4477","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/featured-category.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4478","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/featured-product-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4479","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/featured-product.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4480","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/filter-wrapper-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4481","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/filter-wrapper.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4482","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/legacy-template-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4483","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/legacy-template.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4484","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4485","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4486","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4487","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4488","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/packages-style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4489","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/packages-style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4490","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-filter-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4491","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-filter-wrapper-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4492","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-filter-wrapper.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4493","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-filter.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4494","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-add-to-cart-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4495","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-add-to-cart.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4496","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-button-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4497","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-button.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4498","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-categories-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4499","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-categories.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4500","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-details-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4501","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-details.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4502","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-image-gallery-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4503","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-image-gallery.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4504","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-image-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4505","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-image.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4506","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-price-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4507","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-price.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4508","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-query-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4509","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-query.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4510","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-rating-stars-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4511","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-rating-stars.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4512","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-results-count-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4513","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-results-count.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4514","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-reviews-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4515","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-reviews.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4516","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sale-badge-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4517","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sale-badge.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4518","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-search-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4519","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-search.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4520","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sku-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4521","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sku.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4522","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-stock-indicator-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4523","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-stock-indicator.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4524","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-summary-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4525","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-summary.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4526","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-template-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4527","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-template.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4528","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-title-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4529","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-title.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4530","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/rating-filter-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4531","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/rating-filter-wrapper-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4532","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/rating-filter-wrapper.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4533","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/rating-filter.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4534","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-by-category-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4535","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-by-category.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4536","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-by-product-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4537","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-by-product.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4538","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/single-product-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4539","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/single-product.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4540","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/stock-filter-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4541","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/stock-filter-wrapper-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4542","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/stock-filter-wrapper.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4543","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/stock-filter.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4544","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-classic-template-revert-button-style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4545","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-classic-template-revert-button-style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4546","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-editor-style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4547","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-editor-style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4548","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4549","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4550","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/active-filters-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4551","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/active-filters-wrapper-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4552","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/active-filters.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4553","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-products-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:56","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4554","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-products.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4555","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/all-reviews.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4556","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/attribute-filter-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4557","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/attribute-filter-wrapper-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4558","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/attribute-filter.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4559","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/blocks-checkout.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4560","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/breadcrumbs.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4561","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4562","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/cart.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4563","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/catalog-sorting.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:57","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4564","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4565","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/checkout.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4566","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/customer-account.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4567","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/featured-category.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4568","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/featured-product.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4569","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/filter-wrapper-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4570","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/filter-wrapper.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4571","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/handpicked-products.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4572","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/legacy-template.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4573","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-component-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4574","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-contents.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4575","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4576","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/mini-cart.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4577","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-filter-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4578","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-filter-wrapper-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4579","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-filter.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4580","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/price-format.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4581","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-add-to-cart--product-button--product-image--product-price--product-rating--product-rating-s--92e2d51d.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4582","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-add-to-cart--product-button--product-image--product-rating--product-rating-stars--product-title.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4583","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-add-to-cart-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4584","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-add-to-cart.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4585","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-best-sellers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:58","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4586","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-button--product-image--product-price--product-rating--product-rating-stars--product-sale-ba--4e6a8b3c.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4587","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-button-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4588","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-button.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4589","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-categories.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4590","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-category.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4591","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-collection.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4592","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-gallery.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4593","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-image-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4594","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-image.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4595","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-new.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4596","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-on-sale.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4597","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-price-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4598","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-price.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4599","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-query.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4600","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-rating-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4601","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-rating-stars-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4602","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-rating-stars.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4603","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-rating.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4604","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-results-count.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4605","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sale-badge-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4606","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sale-badge.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4607","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-search.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4608","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sku-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4609","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-sku.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4610","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-stock-indicator-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4611","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-stock-indicator.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4612","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-summary-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4613","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-summary.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4614","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-tag.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4615","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-template.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4616","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-title-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4617","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-title.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4618","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/product-top-rated.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4619","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/products-by-attribute.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4620","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/rating-filter-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4621","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/rating-filter-wrapper-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4622","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/rating-filter.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4623","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-by-category.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4624","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-by-product.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4625","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/reviews-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4626","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/single-product.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4627","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/stock-filter-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4628","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/stock-filter-wrapper-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4629","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/stock-filter.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4630","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/store-notices.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4631","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--attribute-filter-wrapper-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:26:59","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4632","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--price-filter-wrapper-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4633","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--product-add-to-cart-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4634","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--rating-filter-wrapper-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4635","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors--stock-filter-wrapper-frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4636","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-classic-template-revert-button.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4637","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-data.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4638","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-google-analytics.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4639","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-middleware.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4640","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-registry.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4641","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-shared-context.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4642","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-shared-hocs.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4643","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-vendors.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4644","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4645","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-interactivity.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4646","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-payment-method-bacs.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4647","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-payment-method-cheque.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4648","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-payment-method-cod.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4649","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-payment-method-paypal.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4650","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4651","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-shipping-method-pickup-location.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4652","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/block-placeholders/product-image-gallery.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4653","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/block-placeholders/product-reviews.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4654","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/blocks/mini-cart/cart-drawer-rtl.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4655","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/blocks/mini-cart/cart-drawer.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4656","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/desk-table-wood-chair-floor-home-square.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4657","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/dish-food-baking-dessert-bread-bakery.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:01","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4658","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/dish-meal-food-breakfast-dessert-eat.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:01","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4659","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/floor-home-decoration-fireplace-property-living-room.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:01","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4660","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/hand-guitar-finger-tshirt-clothing-rack.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:01","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4661","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/leather-guitar-typewriter-red-gadget-sofa.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:01","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4662","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/man-person-winter-photography-statue-coat.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:01","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4663","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/music-technology-play-equipment-studio-gadget.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:01","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4664","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/pattern-fashion-clothing-outerwear-wool-scarf.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:01","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4665","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/person-winter-blur-wood-girl-woman.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:01","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4666","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/sweet-restaurant-celebration-food-chocolate-cupcake.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4667","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/table-floor-home-living-room-furniture-room-square.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4668","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/table-floor-home-living-room-furniture-room.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4669","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/table-floor-interior-atmosphere-living-room-furniture-square-lg.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4670","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/table-floor-interior-atmosphere-living-room-furniture-square.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4671","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/table-white-chair-floor-shelf-lamp-square-lg.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4672","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/table-wood-chair-floor-living-room-furniture-horizontal.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4673","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/table-wood-chair-floor-living-room-furniture-vertical.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4674","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/technology-joystick-gadget-console-games-playstation.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4675","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/technology-white-camera-photography-vintage-photographer.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4676","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/wood-home-wall-decoration-shelf-living-room.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4677","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/wood-leather-fur-shop-jeans-shelf.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4678","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/pattern-placeholders/beach-landscape-sea-coast-nature-person.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4679","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/alipay.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4680","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/amex.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4681","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/bancontact.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4682","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/diners.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4683","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/discover.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4684","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/eps.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4685","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/giropay.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4686","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/ideal.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4687","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/jcb.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4688","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/laser.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4689","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/maestro.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4690","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/mastercard.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4691","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/multibanco.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4692","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/p24.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:02","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4693","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/sepa.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4694","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/sofort.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4695","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/unionpay.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4696","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/visa.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4697","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/payment-methods/wechat.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4698","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/previews/beanie.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4699","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/previews/cap.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4700","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/previews/collection.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4701","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/previews/hoodie-with-logo.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4702","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/previews/hoodie-with-pocket.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4703","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/previews/hoodie-with-zipper.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4704","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/previews/long-sleeve-tee.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4705","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/previews/pennant.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4706","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/previews/polo.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4707","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/previews/tshirt.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4708","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/template-placeholders/archive-product.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4709","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/template-placeholders/fallback.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4710","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/template-placeholders/single-product.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4711","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/images/block-error.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4712","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/blocks-registry/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4713","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/blocks-registry/inserter.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4714","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/components/discounts-meta/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4715","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/components/error-boundary/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4716","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/components/order-meta/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4717","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/components/order-shipping-packages/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4718","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/components/totals/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4719","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/components/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4720","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/filter-registry/test/admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4721","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/filter-registry/test/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4722","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/slot/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4723","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/utils/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4724","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/checkout/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4725","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/prices/utils/test/price.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4726","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/prices/utils/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4727","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/packages/prices/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4728","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/parts/checkout-header.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4729","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/parts/mini-cart.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4730","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/blockified/archive-product.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4731","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/blockified/cart.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4732","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/blockified/checkout.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4733","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/blockified/order-confirmation.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4734","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/blockified/product-search-results.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4735","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/blockified/single-product.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4736","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/blockified/taxonomy-product_attribute.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4737","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/blockified/taxonomy-product_cat.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4738","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/blockified/taxonomy-product_tag.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4739","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/archive-product.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4740","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/cart.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4741","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/checkout.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4742","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/order-confirmation.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4743","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/product-search-results.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4744","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/single-product.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4745","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/taxonomy-product_attribute.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4746","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/taxonomy-product_cat.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4747","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/templates/templates/taxonomy-product_tag.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4748","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/vendor/automattic/jetpack-autoloader/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:04","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4749","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:03","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4750","static_file","/wp-content/plugins/woocommerce/packages/woocommerce-blocks/checkstyle.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:00","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4751","static_file","/wp-content/plugins/woocommerce/sample-data/sample_products.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:05","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4752","static_file","/wp-content/plugins/woocommerce/vendor/automattic/jetpack-a8c-mc-stats/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:08","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4753","static_file","/wp-content/plugins/woocommerce/vendor/automattic/jetpack-admin-ui/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:08","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4754","static_file","/wp-content/plugins/woocommerce/vendor/automattic/jetpack-autoloader/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:08","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4755","static_file","/wp-content/plugins/woocommerce/vendor/automattic/jetpack-config/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:08","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4756","static_file","/wp-content/plugins/woocommerce/vendor/automattic/jetpack-connection/dist/tracks-ajax.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:08","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4757","static_file","/wp-content/plugins/woocommerce/vendor/automattic/jetpack-connection/dist/tracks-callables.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:08","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4758","static_file","/wp-content/plugins/woocommerce/vendor/automattic/jetpack-connection/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:08","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4759","static_file","/wp-content/plugins/woocommerce/vendor/automattic/jetpack-constants/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:08","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4760","static_file","/wp-content/plugins/woocommerce/vendor/automattic/jetpack-redirect/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:08","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4761","static_file","/wp-content/plugins/woocommerce/vendor/automattic/jetpack-roles/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:08","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4762","static_file","/wp-content/plugins/woocommerce/vendor/automattic/jetpack-status/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:08","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4763","static_file","/wp-content/plugins/woocommerce/vendor/maxmind-db/reader/package.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:09","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4764","static_file","/wp-content/plugins/woocommerce/license.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:26:51","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4765","static_file","/wp-content/plugins/woocommerce/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:05","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4766","static_file","/wp-content/plugins/wp-file-manager/css/images/ui-icons_444444_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4767","static_file","/wp-content/plugins/wp-file-manager/css/images/ui-icons_555555_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4768","static_file","/wp-content/plugins/wp-file-manager/css/images/ui-icons_777620_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4769","static_file","/wp-content/plugins/wp-file-manager/css/images/ui-icons_777777_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4770","static_file","/wp-content/plugins/wp-file-manager/css/images/ui-icons_cc0000_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4771","static_file","/wp-content/plugins/wp-file-manager/css/images/ui-icons_ffffff_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4772","static_file","/wp-content/plugins/wp-file-manager/css/fm-backup.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4773","static_file","/wp-content/plugins/wp-file-manager/css/fm_common.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4774","static_file","/wp-content/plugins/wp-file-manager/css/fm_custom.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4775","static_file","/wp-content/plugins/wp-file-manager/css/fm_custom_style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4776","static_file","/wp-content/plugins/wp-file-manager/css/fm_script.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4777","static_file","/wp-content/plugins/wp-file-manager/css/jquery-ui.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4778","static_file","/wp-content/plugins/wp-file-manager/images/loader-fm-console.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4779","static_file","/wp-content/plugins/wp-file-manager/images/loading.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4780","static_file","/wp-content/plugins/wp-file-manager/images/btn-arrow-icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4781","static_file","/wp-content/plugins/wp-file-manager/images/wp_file_manager.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4782","static_file","/wp-content/plugins/wp-file-manager/inc/images/app-store.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4783","static_file","/wp-content/plugins/wp-file-manager/inc/images/fm-shortcode-icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4784","static_file","/wp-content/plugins/wp-file-manager/inc/images/google.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4785","static_file","/wp-content/plugins/wp-file-manager/inc/images/root-directory-icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4786","static_file","/wp-content/plugins/wp-file-manager/js/file_manager_free_shortcode_admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4787","static_file","/wp-content/plugins/wp-file-manager/js/fm-backup.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4788","static_file","/wp-content/plugins/wp-file-manager/js/fm_script.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4789","static_file","/wp-content/plugins/wp-file-manager/js/top.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:27","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4790","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/lib/codemirror.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4791","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/lib/codemirror.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4792","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/apl/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4793","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/apl/apl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4794","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/asciiarmor/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4795","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/asciiarmor/asciiarmor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4796","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/asn.1/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4797","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/asn.1/asn.1.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4798","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/asterisk/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4799","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/asterisk/asterisk.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4800","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/brainfuck/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4801","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/brainfuck/brainfuck.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4802","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/clike/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4803","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/clike/scala.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4804","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/clike/clike.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4805","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/clike/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4806","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/clojure/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4807","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/clojure/clojure.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4808","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/cmake/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4809","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/cmake/cmake.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4810","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/cobol/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4811","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/cobol/cobol.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4812","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/coffeescript/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4813","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/coffeescript/coffeescript.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4814","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/commonlisp/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4815","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/commonlisp/commonlisp.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4816","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/crystal/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4817","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/crystal/crystal.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4818","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/css/gss.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4819","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/css/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4820","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/css/less.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4821","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/css/scss.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4822","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/css/css.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4823","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/css/gss_test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4824","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/css/less_test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4825","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/css/scss_test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4826","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/css/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4827","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/cypher/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4828","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/cypher/cypher.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4829","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/d/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4830","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/d/d.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4831","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/dart/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4832","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/dart/dart.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4833","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/diff/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4834","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/diff/diff.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4835","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/django/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4836","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/django/django.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4837","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/dockerfile/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4838","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/dockerfile/dockerfile.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4839","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/dtd/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4840","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/dtd/dtd.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4841","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/dylan/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4842","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/dylan/dylan.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4843","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/dylan/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4844","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ebnf/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4845","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ebnf/ebnf.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4846","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ecl/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4847","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ecl/ecl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4848","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/eiffel/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4849","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/eiffel/eiffel.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4850","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/elm/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4851","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/elm/elm.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4852","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/erlang/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4853","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/erlang/erlang.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4854","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/factor/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4855","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/factor/factor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4856","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/fcl/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4857","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/fcl/fcl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4858","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/forth/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4859","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/forth/forth.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4860","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/fortran/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4861","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/fortran/fortran.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4862","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/gas/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4863","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/gas/gas.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4864","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/gfm/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4865","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/gfm/gfm.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4866","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/gfm/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4867","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/gherkin/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4868","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/gherkin/gherkin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4869","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/go/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4870","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/go/go.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4871","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/groovy/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4872","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/groovy/groovy.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4873","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/haml/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4874","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/haml/haml.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4875","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/haml/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4876","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/handlebars/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4877","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/handlebars/handlebars.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4878","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/haskell-literate/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4879","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/haskell-literate/haskell-literate.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4880","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/haskell/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4881","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/haskell/haskell.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4882","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/haxe/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4883","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/haxe/haxe.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4884","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/htmlembedded/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4885","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/htmlembedded/htmlembedded.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4886","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/htmlmixed/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4887","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/htmlmixed/htmlmixed.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4888","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/http/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4889","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/http/http.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4890","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/idl/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4891","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/idl/idl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4892","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/javascript/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4893","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/javascript/json-ld.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4894","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/javascript/typescript.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4895","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/javascript/javascript.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4896","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/javascript/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4897","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/jinja2/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4898","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/jinja2/jinja2.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4899","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/jsx/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4900","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/jsx/jsx.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4901","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/jsx/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4902","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/julia/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4903","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/julia/julia.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4904","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/livescript/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4905","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/livescript/livescript.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4906","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/lua/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4907","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/lua/lua.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4908","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/markdown/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4909","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/markdown/markdown.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4910","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/markdown/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4911","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mathematica/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4912","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mathematica/mathematica.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4913","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mbox/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4914","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mbox/mbox.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4915","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mirc/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4916","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mirc/mirc.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4917","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mllike/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4918","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mllike/mllike.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4919","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/modelica/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4920","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/modelica/modelica.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4921","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mscgen/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4922","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mscgen/mscgen.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4923","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mscgen/mscgen_test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4924","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mscgen/msgenny_test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4925","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mscgen/xu_test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4926","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mumps/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4927","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/mumps/mumps.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4928","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/nginx/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4929","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/nginx/nginx.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4930","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/nsis/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4931","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/nsis/nsis.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4932","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ntriples/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4933","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ntriples/ntriples.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4934","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/octave/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4935","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/octave/octave.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4936","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/oz/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4937","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/oz/oz.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4938","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/pascal/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4939","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/pascal/pascal.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4940","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/pegjs/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4941","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/pegjs/pegjs.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4942","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/perl/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4943","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/perl/perl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4944","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/php/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4945","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/php/php.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4946","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/php/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4947","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/pig/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4948","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/pig/pig.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4949","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/powershell/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4950","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/powershell/powershell.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4951","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/powershell/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4952","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/properties/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4953","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/properties/properties.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4954","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/protobuf/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4955","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/protobuf/protobuf.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4956","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/pug/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4957","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/pug/pug.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4958","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/puppet/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4959","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/puppet/puppet.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4960","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/python/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4961","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/python/python.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4962","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/python/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4963","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/q/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4964","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/q/q.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4965","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/r/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4966","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/r/r.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4967","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/rpm/changes/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4968","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/rpm/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4969","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/rpm/rpm.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4970","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/rst/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4971","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/rst/rst.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4972","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ruby/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4973","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ruby/ruby.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4974","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ruby/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4975","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/rust/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4976","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/rust/rust.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4977","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/rust/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4978","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/sas/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4979","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/sas/sas.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4980","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/sass/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4981","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/sass/sass.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4982","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/scheme/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4983","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/scheme/scheme.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4984","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/shell/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4985","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/shell/shell.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4986","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/shell/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4987","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/sieve/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4988","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/sieve/sieve.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4989","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/slim/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4990","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/slim/slim.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4991","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/slim/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4992","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/smalltalk/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4993","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/smalltalk/smalltalk.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:38");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4994","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/smarty/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4995","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/smarty/smarty.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4996","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/solr/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4997","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/solr/solr.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4998","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/soy/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4999","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/soy/soy.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5000","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/sparql/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/