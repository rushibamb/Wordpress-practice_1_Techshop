

DROP TABLE IF EXISTS `webtoffee_actionscheduler_groups` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_actionscheduler_groups` VALUES
("1","action-scheduler-migration");/*END*/
INSERT INTO `webtoffee_actionscheduler_groups` VALUES
("2","wpforms");/*END*/
INSERT INTO `webtoffee_actionscheduler_groups` VALUES
("3","wc_update_product_lookup_tables");/*END*/
INSERT INTO `webtoffee_actionscheduler_groups` VALUES
("4","woocommerce-db-updates");/*END*/
INSERT INTO `webtoffee_actionscheduler_groups` VALUES
("5","wc-admin-data");/*END*/
INSERT INTO `webtoffee_actionscheduler_groups` VALUES
("6","wp_mail_smtp");/*END*/
INSERT INTO `webtoffee_actionscheduler_groups` VALUES
("7","woocommerce-remote-inbox-engine");/*END*/
INSERT INTO `webtoffee_actionscheduler_groups` VALUES
("8","aioseo");/*END*/
INSERT INTO `webtoffee_actionscheduler_groups` VALUES
("9","");/*END*/