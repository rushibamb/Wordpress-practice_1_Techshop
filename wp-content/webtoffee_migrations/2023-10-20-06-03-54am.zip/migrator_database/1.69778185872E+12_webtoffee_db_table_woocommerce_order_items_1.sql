

DROP TABLE IF EXISTS `webtoffee_woocommerce_order_items` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("40","Instagram Indian ?? indian ?? Likes {100}","line_item","1651");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("39","Instagram Likes [Female] {100}","line_item","1651");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("38","vivek","coupon","1650");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("37","Instagram Likes [Female] {100}","line_item","1650");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("36","vivek","coupon","1649");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("35","Exif","line_item","1649");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("34","vivek","coupon","1648");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("33","Instagram Likes [Female] {100}","line_item","1648");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("32","vivek","coupon","1647");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("31","Instagram Reel Views {1000Views}","line_item","1647");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("30","Instagram Indian ?? indian ?? Likes {100}","line_item","1647");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("29","vivek","coupon","1646");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("28","Instagram Likes [Female] {100}","line_item","1646");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("27","Instagram Likes [Female] {100}","line_item","1645");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("41","vivek","coupon","1651");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("42","Exif","line_item","1652");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("43","vivek","coupon","1652");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("44","Instagram Indian ?? indian ?? Likes {100}","line_item","1657");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("45","Instagram Likes [Female] {100}","line_item","1658");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("46","Instagram Likes [Female] {100}","line_item","1659");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("47","vivek","coupon","1659");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("48","Instagram Likes [Female] {100}","line_item","1660");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("49","Instagram Indian ?? indian ?? Likes {100}","line_item","1661");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("50","vivek","coupon","1661");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("51","Instagram Likes [Female] {100}","line_item","1662");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("52","vivek","coupon","1662");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("53","Instagram Reel Views {1000Views}","line_item","1663");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("54","vivek","coupon","1663");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("55","Instagram Indian ?? indian ?? Likes {100}","line_item","1664");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("56","Instagram Likes [Female] {100}","line_item","1664");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("57","vivek","coupon","1664");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("58","Instagram Likes [Female] {100}","line_item","1665");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("59","vivek","coupon","1665");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("60","Instagram Indian ?? indian ?? Likes {100}","line_item","1667");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("61","Instagram Indian ?? indian ?? Likes {100}","line_item","1670");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("62","Instagram Likes [Female] {100}","line_item","1670");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("63","aditya2345","coupon","1670");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("64","Instagram Indian ?? indian ?? Likes {100}","line_item","1671");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("65","Regular permanent instagram follower {100}","line_item","1671");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("66","vivek","coupon","1671");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("67","Instagram Indian ?? indian ?? Likes {100}","line_item","1672");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("68","vivek","coupon","1672");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("69","Premium Instagram Followers{100}","line_item","1673");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("70","vivek","coupon","1673");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("71","Instagram Likes [Female] {100}","line_item","1675");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("72","Instagram Likes [Female] {100}","line_item","1676");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("73","vivek","coupon","1676");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("74","Instagram Likes [Female] {100}","line_item","1678");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("75","vivek","coupon","1678");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("76","Regular Instagram Followers [ Indian ?? ]","line_item","1679");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("77","vivek","coupon","1679");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("78","Instagram Reel Views {1000Views}","line_item","1683");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("79","insta30","coupon","1683");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("80","Instagram Indian ?? indian ?? Likes {100}","line_item","1684");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("81","insta30","coupon","1684");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("82","Regular Instagram Followers [ Indian ?? ]","line_item","1712");/*END*/
INSERT INTO `webtoffee_woocommerce_order_items` VALUES
("83","Instagram Indian ?? indian ?? Likes {100}","line_item","1713");/*END*/