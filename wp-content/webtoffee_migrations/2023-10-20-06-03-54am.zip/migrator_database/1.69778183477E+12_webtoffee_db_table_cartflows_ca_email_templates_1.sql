

DROP TABLE IF EXISTS `webtoffee_cartflows_ca_email_templates` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_cartflows_ca_email_templates` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `template_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email_subject` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email_body` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_activated` tinyint(1) NOT NULL DEFAULT 0,
  `frequency` int(11) NOT NULL,
  `frequency_unit` enum('MINUTE','HOUR','DAY') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'MINUTE',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_cartflows_ca_email_templates` VALUES
("1","Sample Email Template 1","Purchase issue?","<p>Hi {{customer.firstname}}!</p><p>We\\\'re having trouble processing your recent purchase. Would you mind completing it?</p><p>Here\\\'s a link to continue where you left off:</p><p><a href=\'{{cart.checkout_url}}\' target=\'_blank\' rel=\'noopener\'> Continue Your Purchase Now </a></p><p>Kindly,<br />{{admin.firstname}}<br />{{admin.company}}</p><p>{{cart.unsubscribe}}</p>","0","30","MINUTE");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates` VALUES
("2","Sample Email Template 2","Need help?","<p>Hi {{customer.firstname}}!</p><p>I\'m {{admin.firstname}}, and I help handle customer issues at {{admin.company}}.</p><p>I just noticed that you tried to make a purchase, but unfortunately, there was some trouble. Is there anything I can do to help?</p><p>You should be able to complete your checkout in less than a minute:<br /><a href=\'{{cart.checkout_url}}\' target=\'_blank\' rel=\'noopener\'> Click here to continue your purchase </a><p><p>Thanks!<br />{{admin.firstname}}<br />{{admin.company}}</p><p>{{cart.unsubscribe}}</p>","0","1","DAY");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates` VALUES
("3","Sample Email Template 3","Exclusive discount for you. Let\'s get things started!","<p>Few days back you left {{cart.product.names}} in your cart.</p><p>To help make up your mind, we have added an exclusive 10% discount coupon {{cart.coupon_code}} to your cart.</p><p><a href=\'{{cart.checkout_url}}\' target=\'_blank\' rel=\'noopener\'>Complete Your Purchase Now &gt;&gt;</a></p><p>Hurry! This is a onetime offer and will expire in 24 Hours.</p><p>In case you couldn\\\'t finish your order due to technical difficulties or because you need some help, just reply to this email we will be happy to help.</p><p>Kind Regards,<br />{{admin.firstname}}<br />{{admin.company}}</p><p>{{cart.unsubscribe}}</p>","0","3","DAY");/*END*/