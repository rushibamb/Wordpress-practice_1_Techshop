

DROP TABLE IF EXISTS `webtoffee_usermeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=210 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO `webtoffee_usermeta` VALUES
("1","1","nickname","vivek");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("2","1","first_name","sw");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("3","1","last_name","dsdad");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("4","1","description","");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("5","1","rich_editing","true");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("6","1","syntax_highlighting","true");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("7","1","comment_shortcuts","false");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("8","1","admin_color","fresh");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("9","1","use_ssl","0");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("10","1","show_admin_bar_front","true");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("11","1","locale","");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("12","1","wpco_capabilities","a:1:{s:13:\"administrator\";b:1;}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("13","1","wpco_user_level","10");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("14","1","dismissed_wp_pointers","omapi_please_connect_notice,theme_editor_notice");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("15","1","show_welcome_panel","0");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("16","1","session_tokens","a:13:{s:64:\"b48ebafbfb69ee64a421f33b4a6347804fde68c03969ffbe0692558fadc57095\";a:4:{s:10:\"expiration\";i:1697923537;s:2:\"ip\";s:13:\"49.36.235.180\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36\";s:5:\"login\";i:1697750737;}s:64:\"a615c66036b7b33fea79fa744b723a2af62c341d467fde03e39bf3969a35bb01\";a:4:{s:10:\"expiration\";i:1697923537;s:2:\"ip\";s:13:\"49.36.235.180\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36\";s:5:\"login\";i:1697750737;}s:64:\"60ab66532c26d7ea4d30ad147034d99d91d708dc2c4aed00957b679dde75d4b2\";a:4:{s:10:\"expiration\";i:1697925372;s:2:\"ip\";s:13:\"49.36.235.180\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36\";s:5:\"login\";i:1697752572;}s:64:\"1ac86f5fc7d2454e9f839803a530d75d97b8f6620f396479b536668786a352be\";a:4:{s:10:\"expiration\";i:1697925372;s:2:\"ip\";s:13:\"49.36.235.180\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36\";s:5:\"login\";i:1697752572;}s:64:\"0e95da425e810a7b6b6ba395e835f9dd010dde254f85c64a383c06691f7768d6\";a:4:{s:10:\"expiration\";i:1697925377;s:2:\"ip\";s:13:\"49.36.235.180\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36\";s:5:\"login\";i:1697752577;}s:64:\"f3f7bacdef2bd75d5ca6766433ff36e1e6e7239b5da4814414364113cb12756d\";a:4:{s:10:\"expiration\";i:1697925378;s:2:\"ip\";s:13:\"49.36.235.180\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36\";s:5:\"login\";i:1697752578;}s:64:\"bc2bad7ce5277010b649f2d08b84938318c189aba2ca53f26c9e7024f1ec3803\";a:4:{s:10:\"expiration\";i:1698967028;s:2:\"ip\";s:13:\"49.36.235.180\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36\";s:5:\"login\";i:1697757428;}s:64:\"eee8e315e4ae8ef579e2c80c0f8ee5fd52d377e1b9f87e73a8ae9e28bd106d13\";a:4:{s:10:\"expiration\";i:1698967029;s:2:\"ip\";s:13:\"49.36.235.180\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36\";s:5:\"login\";i:1697757429;}s:64:\"2fedf8378068951b40f40a852eb4c75ec39d1de065af59f3703e8609120003bf\";a:4:{s:10:\"expiration\";i:1697933754;s:2:\"ip\";s:13:\"49.36.235.180\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36\";s:5:\"login\";i:1697760954;}s:64:\"4bb49c5bb508e81d20aec8b438910c30590af25514871892baec62df53a4e490\";a:4:{s:10:\"expiration\";i:1697933937;s:2:\"ip\";s:12:\"20.2.216.159\";s:2:\"ua\";s:129:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36 Edg/118.0.2088.46\";s:5:\"login\";i:1697761137;}s:64:\"da2abe146f962525a704a146b44dbeebffd30a3ac293991bbaeb19dafa4269a7\";a:4:{s:10:\"expiration\";i:1697934946;s:2:\"ip\";s:12:\"4.240.88.248\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36\";s:5:\"login\";i:1697762146;}s:64:\"9f2abb969295901075e03f359dbf00a33d73ebf5c0a36a1a7b7286ccabc02ce7\";a:4:{s:10:\"expiration\";i:1698985632;s:2:\"ip\";s:14:\"34.131.189.244\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36\";s:5:\"login\";i:1697776032;}s:64:\"59eaacd7e76190ef33789d54aeb80b706ff811e3c1cc36c01916b73992607fde\";a:4:{s:10:\"expiration\";i:1697948836;s:2:\"ip\";s:14:\"34.131.189.244\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36\";s:5:\"login\";i:1697776036;}}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("134","1","screen_layout_shop_order","2");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("133","1","meta-box-order_shop_order","a:3:{s:4:\"side\";s:25:\"woocommerce-order-actions\";s:6:\"normal\";s:109:\"woocommerce-order-notes,woocommerce-order-data,woocommerce-order-items,postcustom,woocommerce-order-downloads\";s:8:\"advanced\";s:0:\"\";}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("131","1","thwcfd_review_skipped_time","1688020150");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("17","1","wpco_dashboard_quick_press_last_post_id","1677");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("18","1","community-events-location","a:1:{s:2:\"ip\";s:12:\"34.131.189.0\";}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("19","1","astra-sites-on-active","notice-dismissed");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("20","1","astra-sites-subscribed","yes");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("21","1","wc_last_active","1697760000");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("22","1","_woocommerce_tracks_anon_id","woo:rzPJCEamGgvsQ8R0qXs1QHsB");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("23","1","wpco_user-settings","libraryContent=browse&editor=tinymce&mfold=o");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("24","1","wpco_user-settings-time","1696197640");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("25","1","meta-box-order_product","a:3:{s:4:\"side\";s:122:\"submitdiv,woocommerce-product-images,product_catdiv,postimagediv,tagsdiv-product_tag,pageparentdiv,astra_settings_meta_box\";s:6:\"normal\";s:80:\"woocommerce-product-data,postcustom,slugdiv,postexcerpt,revisionsdiv,commentsdiv\";s:8:\"advanced\";s:0:\"\";}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("26","1","last_update","1692930160");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("27","1","wpco_persisted_preferences","a:2:{s:14:\"core/edit-post\";a:2:{s:26:\"isComplementaryAreaVisible\";b:0;s:12:\"welcomeGuide\";b:0;}s:9:\"_modified\";s:24:\"2023-08-25T02:22:25.606Z\";}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("28","1","announcements_user_counter","1");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("29","1","astra-sites-5-start-notice","notice-dismissed");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("32","1","cartflows-ca-5-star-notice","notice-dismissed");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("33","1","dismissed_no_secure_connection_notice","1");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("34","1","wpforms_dismissed","a:3:{s:20:\"edu-edit-post-notice\";i:1682674147;s:20:\"edu-admin-notice-bar\";i:1687264007;s:31:\"edu-admin-did-you-know-overview\";i:1687521535;}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("35","1","closedpostboxes_product","a:0:{}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("36","1","metaboxhidden_product","a:3:{i:0;s:11:\"postdivrich\";i:1;s:10:\"postcustom\";i:2;s:7:\"slugdiv\";}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("40","1","screen_layout_product","2");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("41","1","elementor_introduction","a:5:{s:20:\"globals_introduction\";b:1;s:14:\"ai_get_started\";b:1;s:19:\"aioseo-introduction\";b:1;s:6:\"e-apps\";b:1;s:16:\"favorites-notice\";b:1;}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("42","1","wpco_elementor_connect_common_data","a:6:{s:9:\"client_id\";s:32:\"7YMiYGOk2inkbUIFz1nzY0ZoqpEuJjv7\";s:11:\"auth_secret\";s:32:\"xm4vGnBTf8qtNuaVlS7zkej6LnlUk6xg\";s:12:\"access_token\";s:299:\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjUwNzE3MzksImF1ZCI6Imh0dHA6Ly90b29sLXNob3AuYXJ5YW52YncudGVjaC8iLCJjbGllbnRfaWQiOiI3WU1pWUdPazJpbmtiVUlGejFuelkwWm9xcEV1Smp2NyIsImNvbm5lY3RfdHlwZSI6ImxpYnJhcnkiLCJpYXQiOjE2ODI4MDA4OTcsImV4cCI6MzE3MjI3MjQzMjk3fQ.UK0sTI1eN15DBSqiyZ76VTFioufUQidYlX0vpzT60RQ\";s:19:\"access_token_secret\";s:32:\"lVRZ3gIM9UAHVn5J8LcopI5nbF2nWyT5\";s:10:\"token_type\";s:6:\"bearer\";s:4:\"user\";O:8:\"stdClass\":1:{s:5:\"email\";s:40:\"bakliwaltutorialscomprehensive@gmail.com\";}}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("43","1","billing_first_name","Viveksw");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("44","1","billing_last_name","dsdad");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("45","1","billing_address_1","dsa");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("46","1","billing_city","pune");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("47","1","billing_state","MH");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("48","1","billing_postcode","412218");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("49","1","billing_country","IN");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("50","1","billing_email","vivekwagadare+mysite@gmail.com");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("51","1","billing_phone","98349444412");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("52","1","shipping_method","");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("53","1","paying_customer","1");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("56","1","billing_company","fcfc");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("62","1","dismissed_update_notice","1");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("63","1","astra-upgrade-pro-wc","notice-dismissed");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("67","1","cartflows-5-start-notice","notice-dismissed");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("68","1","quadlayers_wp-whatsapp-chat_notice_hidden_0","1");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("69","1","meta-box-order_dashboard","a:4:{s:6:\"normal\";s:192:\"dashboard_activity,wpforms_reports_widget_lite,wc_admin_dashboard_setup,dashboard_right_now,dashboard_site_health,e-dashboard-overview,wp_mail_smtp_reports_widget_lite,wp-dashboard-widget-news\";s:4:\"side\";s:39:\"dashboard_quick_press,dashboard_primary\";s:7:\"column3\";s:0:\"\";s:7:\"column4\";s:0:\"\";}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("72","1","wp_mail_smtp_dash_widget_lite_hide_graph","1");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("73","1","closedpostboxes_dashboard","a:10:{i:0;s:18:\"dashboard_activity\";i:1;s:27:\"wpforms_reports_widget_lite\";i:2;s:24:\"wc_admin_dashboard_setup\";i:3;s:20:\"e-dashboard-overview\";i:4;s:21:\"dashboard_site_health\";i:5;s:19:\"dashboard_right_now\";i:6;s:32:\"wp_mail_smtp_reports_widget_lite\";i:7;s:24:\"wp-dashboard-widget-news\";i:8;s:21:\"dashboard_quick_press\";i:9;s:17:\"dashboard_primary\";}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("74","1","metaboxhidden_dashboard","a:0:{}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("75","1","dismissed_product_reviews_moved_notice","1");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("116","1","_woocommerce_persistent_cart_1","a:1:{s:4:\"cart\";a:1:{s:32:\"115f89503138416a242f40fb7d7f338e\";a:11:{s:3:\"key\";s:32:\"115f89503138416a242f40fb7d7f338e\";s:10:\"product_id\";i:223;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:49;s:17:\"line_subtotal_tax\";d:0;s:10:\"line_total\";d:49;s:8:\"line_tax\";d:0;}}}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("110","1","wp_mail_smtp_edu_notice_bar_dismissed","1687416037");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("136","1","metaboxhidden_shop_order","a:0:{}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("111","1","billing_","");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("112","1","billing_1","fghrt");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("113","1","woocommerce_admin_homepage_stats","{\"installJetpackDismissed\":true}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("82","1","odp_cfs_shield_notice","1686489273");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("130","1","thwcfd_review_skipped","1");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("88","1","woocommerce_admin_android_app_banner_dismissed","\"yes\"");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("89","1","woocommerce_admin_task_list_tracked_started_tasks","{\"store_details\":1,\"tax\":1}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("86","1","elementor_admin_notices","a:3:{s:19:\"woocommerce_promote\";s:4:\"true\";s:11:\"cf7_promote\";s:4:\"true\";s:20:\"design_not_appearing\";a:2:{s:9:\"is_viewed\";b:1;s:4:\"meta\";a:1:{s:7:\"version\";s:11:\"3.17.0-dev4\";}}}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("184","1","wpcf7_hide_welcome_panel_on","a:1:{i:0;s:3:\"5.8\";}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("195","1","wpco_media_library_mode","grid");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("135","1","closedpostboxes_shop_order","a:1:{i:0;s:25:\"woocommerce-order-actions\";}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("138","1","quadlayers_wp-whatsapp-chat_notice_hidden_1","1");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("139","1","thwcfd_reviewed","1");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("140","1","thwcfd_reviewed_time","1689689466");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("145","1","meta-box-order_shop_coupon","a:3:{s:4:\"side\";s:9:\"submitdiv\";s:6:\"normal\";s:23:\"woocommerce-coupon-data\";s:8:\"advanced\";s:0:\"\";}");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("146","1","screen_layout_shop_coupon","2");/*END*/
INSERT INTO `webtoffee_usermeta` VALUES
("209","1","quadlayers_wp-whatsapp-chat_notice_hidden_2","1");/*END*/