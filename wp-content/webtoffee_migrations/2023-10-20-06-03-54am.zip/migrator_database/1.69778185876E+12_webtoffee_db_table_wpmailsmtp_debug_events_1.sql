

DROP TABLE IF EXISTS `webtoffee_wpmailsmtp_debug_events` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wpmailsmtp_debug_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `initiator` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_type` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("1","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3874}","0","2023-05-02 06:59:07");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("2","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3874}","0","2023-05-02 06:59:07");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("3","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3874}","0","2023-05-02 07:13:44");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("4","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3874}","0","2023-05-02 07:13:44");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("5","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-includes\\/pluggable.php\",\"line\":2025}","0","2023-05-02 13:56:43");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("6","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-includes\\/pluggable.php\",\"line\":2025}","0","2023-05-02 13:56:43");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("7","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-05-05 10:09:15");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("8","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-05-05 10:09:15");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("9","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}","0","2023-05-08 14:40:59");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("10","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}","0","2023-05-08 14:40:59");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("11","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-08 14:41:06");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("12","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-08 14:41:06");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("13","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-08 18:13:38");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("14","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-08 18:13:38");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("15","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/includes\\/emails\\/class-emails.php\",\"line\":438}","0","2023-05-09 09:51:57");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("16","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/includes\\/emails\\/class-emails.php\",\"line\":438}","0","2023-05-09 09:51:57");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("17","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3874}","0","2023-05-09 10:03:21");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("18","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3874}","0","2023-05-09 10:03:21");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("19","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-10 06:50:26");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("20","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-10 06:50:26");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("21","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-10 06:50:26");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("22","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-10 06:50:26");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("23","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-05-10 09:12:04");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("24","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-05-10 09:12:04");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("25","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-10 14:17:00");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("26","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-10 14:17:00");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("27","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-10 14:17:00");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("28","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-10 14:17:00");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("29","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-10 14:18:20");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("30","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-10 14:18:20");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("31","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-10 14:18:20");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("32","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-10 14:18:20");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("33","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}","0","2023-05-18 04:21:24");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("34","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}","0","2023-05-18 04:21:24");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("35","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":963}","0","2023-05-18 04:22:16");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("36","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":963}","0","2023-05-18 04:22:16");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("37","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-18 04:22:19");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("38","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-18 04:22:19");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("39","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3874}","0","2023-05-18 04:40:11");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("40","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3874}","0","2023-05-18 04:40:11");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("41","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":963}","0","2023-05-22 14:47:36");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("42","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":963}","0","2023-05-22 14:47:36");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("43","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-22 14:47:55");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("44","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-22 14:47:55");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("45","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-22 14:48:12");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("46","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-22 14:48:12");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("47","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:05:45");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("48","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:05:45");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("49","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:07:11");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("50","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:07:11");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("51","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:10:11");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("52","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:10:11");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("53","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:12:09");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("54","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:12:09");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("55","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:12:09");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("56","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:12:09");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("57","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:36:20");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("58","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:36:20");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("59","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:37:33");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("60","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:37:33");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("61","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:37:33");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("62","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-05-22 17:37:33");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("63","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3874}","0","2023-05-23 11:44:57");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("64","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3874}","0","2023-05-23 11:44:57");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("65","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}","0","2023-05-25 10:16:43");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("66","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}","0","2023-05-25 10:16:43");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("67","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-05-25 10:16:53");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("68","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-05-25 10:16:53");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("69","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-05-26 17:11:09");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("70","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-05-26 17:11:09");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("71","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-05-30 02:07:54");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("72","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-05-30 02:07:54");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("73","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-30 02:08:00");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("74","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-30 02:08:00");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("75","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-30 02:08:09");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("76","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-05-30 02:08:09");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("77","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-06-01 16:44:22");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("78","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-06-01 16:44:22");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("79","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}","0","2023-06-01 16:44:23");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("80","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}","0","2023-06-01 16:44:23");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("81","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-01 16:45:11");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("82","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-01 16:45:11");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("83","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-06-01 16:49:08");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("84","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-06-01 16:49:08");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("85","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3874}","0","2023-06-01 17:02:58");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("86","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3874}","0","2023-06-01 17:02:58");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("87","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-06-04 03:30:11");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("88","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-06-04 03:30:11");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("89","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}","0","2023-06-09 10:38:10");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("90","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}","0","2023-06-09 10:38:10");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("91","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-06-09 10:39:45");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("92","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-06-09 10:39:45");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("93","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-06-09 10:39:56");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("94","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-06-09 10:39:56");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("95","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-06-09 10:40:47");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("96","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-06-09 10:40:47");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("97","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-09 10:53:34");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("98","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-09 10:53:34");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("99","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-includes\\/class-wp-recovery-mode-email-service.php\",\"line\":230}","0","2023-06-09 11:20:21");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("100","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol19_1\\/unaux.com\\/unaux_34095745\\/htdocs\\/wp-includes\\/class-wp-recovery-mode-email-service.php\",\"line\":230}","0","2023-06-09 11:20:21");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("101","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-11 14:42:48");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("102","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-11 14:42:48");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("103","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-11 14:42:48");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("104","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-11 14:42:48");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("105","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-11 15:49:21");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("106","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-11 15:49:21");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("107","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-11 15:52:56");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("108","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-11 15:52:56");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("109","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-11 15:52:56");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("110","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/woocommerce\\/includes\\/emails\\/class-wc-email.php\",\"line\":688}","0","2023-06-11 15:52:56");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("111","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-06-12 14:00:17");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("112","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/src\\/Emails\\/Mailer.php\",\"line\":519}","0","2023-06-12 14:00:17");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("113","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/includes\\/emails\\/class-emails.php\",\"line\":438}","0","2023-06-13 09:41:11");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("114","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wpforms-lite\\/includes\\/emails\\/class-emails.php\",\"line\":438}","0","2023-06-13 09:41:11");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("115","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3876}","0","2023-06-13 11:03:40");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("116","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/updraftplus\\/class-updraftplus.php\",\"line\":3876}","0","2023-06-13 11:03:40");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("117","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-06-14 11:13:13");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("118","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-06-14 11:13:13");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("119","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-06-15 04:49:10");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("120","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-06-15 04:49:10");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("121","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}","0","2023-06-17 05:38:34");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("122","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Reports\\/Emails\\/Summary.php\",\"line\":112}","0","2023-06-17 05:38:34");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("123","Mailer: Other SMTP
PHPMailer was able to connect to SMTP server but failed while trying to send an email.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-06-17 05:38:54");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("124","Mailer: Other SMTP
Could not instantiate mail function.","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-admin\\/includes\\/class-wp-automatic-updater.php\",\"line\":1346}","0","2023-06-17 05:38:54");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("125","Mailer: Other SMTP
SMTP Error: Could not authenticate.SMTP server error: QUIT command failed","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Admin\\/SetupWizard.php\",\"line\":1172}","0","2023-06-22 07:05:14");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("126","Mailer: Other SMTP
SMTP Error: Could not authenticate.SMTP server error: QUIT command failed","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Admin\\/Pages\\/TestTab.php\",\"line\":349}","0","2023-06-22 07:06:47");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_debug_events` VALUES
("127","Mailer: Other SMTP
SMTP Error: Could not authenticate.SMTP server error: QUIT command failed","{\"file\":\"\\/home\\/vol17_1\\/unaux.com\\/unaux_34393270\\/htdocs\\/wp-content\\/plugins\\/wp-mail-smtp\\/src\\/Admin\\/Pages\\/TestTab.php\",\"line\":349}","0","2023-06-22 07:07:38");/*END*/