

DROP TABLE IF EXISTS `webtoffee_wpforms_tasks_meta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wpforms_tasks_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("1","wpforms_process_forms_locator_scan","W10=","2023-04-28 07:17:56");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("3","wpforms_admin_addons_cache_update","W10=","2023-04-28 07:21:24");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("4","wpforms_admin_builder_templates_cache_update","W10=","2023-04-28 07:24:11");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("5","wpforms_builder_help_cache_update","W10=","2023-04-28 07:24:12");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("99","wpforms_process_forms_locator_scan","W10=","2023-10-19 22:04:36");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("93","wpforms_process_forms_locator_scan","W10=","2023-09-07 12:01:12");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("95","wpforms_process_forms_locator_scan","W10=","2023-10-02 13:57:41");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("98","wpforms_admin_notifications_update","W10=","2023-10-11 12:25:06");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("91","wpforms_process_forms_locator_scan","W10=","2023-09-04 15:54:49");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("100","wpforms_admin_notifications_update","W10=","2023-10-19 22:04:37");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("101","wpforms_process_forms_locator_scan","W10=","2023-10-19 22:04:46");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("102","wpforms_admin_notifications_update","W10=","2023-10-19 22:04:46");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("103","wpforms_process_forms_locator_scan","W10=","2023-10-19 22:06:16");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("104","wpforms_admin_notifications_update","W10=","2023-10-19 22:06:17");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("105","wpforms_process_forms_locator_scan","W10=","2023-10-19 22:06:26");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("106","wpforms_admin_notifications_update","W10=","2023-10-19 22:06:27");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("107","wpforms_process_forms_locator_scan","W10=","2023-10-19 22:06:55");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("108","wpforms_admin_notifications_update","W10=","2023-10-19 22:06:56");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("109","wpforms_process_forms_locator_scan","W10=","2023-10-19 22:07:07");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("110","wpforms_admin_notifications_update","W10=","2023-10-19 22:07:08");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("111","wpforms_process_forms_locator_scan","W10=","2023-10-19 22:07:16");/*END*/
INSERT INTO `webtoffee_wpforms_tasks_meta` VALUES
("112","wpforms_admin_notifications_update","W10=","2023-10-19 22:07:16");/*END*/