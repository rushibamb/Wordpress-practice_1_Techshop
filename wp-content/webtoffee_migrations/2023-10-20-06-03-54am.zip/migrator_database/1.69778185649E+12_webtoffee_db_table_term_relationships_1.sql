

DROP TABLE IF EXISTS `webtoffee_term_relationships` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO `webtoffee_term_relationships` VALUES
("1","1","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("9","4","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("9","22","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("10","5","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("10","22","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("150","33","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("151","33","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("208","14","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("424","33","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("223","42","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("223","36","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("223","38","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("208","8","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("208","37","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("208","38","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("208","41","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("220","8","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("208","36","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("220","36","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1554","8","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("223","8","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1297","34","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1326","4","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1326","35","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1327","5","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1327","35","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("223","37","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1620","48","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1602","4","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1602","43","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1603","5","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1603","43","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1626","48","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1620","8","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1630","48","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1626","8","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1630","20","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1630","8","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1632","48","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1632","47","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1632","49","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1632","8","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1637","48","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1637","47","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1637","8","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1554","48","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1554","47","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1620","47","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1626","47","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1630","47","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("223","20","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1706","50","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1706","51","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1706","52","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1706","53","0");/*END*/
INSERT INTO `webtoffee_term_relationships` VALUES
("1706","54","0");/*END*/