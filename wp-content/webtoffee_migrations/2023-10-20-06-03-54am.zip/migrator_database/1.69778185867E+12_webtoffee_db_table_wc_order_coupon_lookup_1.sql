

DROP TABLE IF EXISTS `webtoffee_wc_order_coupon_lookup` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wc_order_coupon_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `date_created` (`date_created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1652","1617","2023-06-22 16:06:37","19");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1651","1617","2023-06-22 15:30:34","15");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1650","1617","2023-06-22 09:56:09","7");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1649","1617","2023-06-22 09:39:14","38");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1648","1617","2023-06-22 09:21:21","7");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1647","1617","2023-06-22 09:16:13","37");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1646","1617","2023-06-22 09:08:46","7");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1659","1617","2023-06-23 15:20:12","7");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1661","1617","2023-06-24 14:43:53","8");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1662","1617","2023-06-25 04:16:14","7");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1663","1617","2023-06-25 04:20:17","29");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1664","1617","2023-06-25 04:25:11","15");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1665","1617","2023-06-25 16:57:36","21");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1670","1669","2023-06-28 03:05:27","10");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1671","1617","2023-06-28 03:10:58","27");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1672","1617","2023-06-28 03:42:42","80");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1673","1617","2023-06-30 05:57:27","29");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1676","1617","2023-08-01 08:09:56","7");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1678","1617","2023-08-05 08:43:52","7");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1684","1680","2023-08-26 10:39:46","16");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1683","1680","2023-08-17 03:20:24","10");/*END*/
INSERT INTO `webtoffee_wc_order_coupon_lookup` VALUES
("1679","1617","2023-08-15 11:51:26","70");/*END*/