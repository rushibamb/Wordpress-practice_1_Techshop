

DROP TABLE IF EXISTS `webtoffee_wc_order_product_lookup` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT 0,
  `product_gross_revenue` double NOT NULL DEFAULT 0,
  `coupon_amount` double NOT NULL DEFAULT 0,
  `tax_amount` double NOT NULL DEFAULT 0,
  `shipping_amount` double NOT NULL DEFAULT 0,
  `shipping_tax_amount` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("53","1663","1637","0","14","2023-06-25 04:20:17","1","0","0","29","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("51","1662","1626","0","14","2023-06-25 04:16:14","1","0","0","7","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("49","1661","1630","0","15","2023-06-24 14:43:53","1","0","0","8","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("48","1660","1626","0","14","2023-06-23 15:22:34","1","7","7","0","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("46","1659","1626","0","14","2023-06-23 15:20:12","1","0","0","7","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("45","1658","1626","0","14","2023-06-23 15:18:01","1","7","7","0","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("44","1657","1630","0","11","2023-06-22 17:01:23","1","8","8","0","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("42","1652","220","0","10","2023-06-22 16:06:37","1","0","0","19","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("39","1651","1626","0","14","2023-06-22 15:30:34","1","0","0","7","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("40","1651","1630","0","14","2023-06-22 15:30:34","1","0","0","8","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("37","1650","1626","0","13","2023-06-22 09:56:09","1","0","0","7","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("35","1649","220","0","12","2023-06-22 09:39:14","2","0","0","38","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("33","1648","1626","0","11","2023-06-22 09:21:21","1","0","0","7","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("31","1647","1637","0","11","2023-06-22 09:16:13","1","0","0","29","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("30","1647","1630","0","11","2023-06-22 09:16:13","1","0","0","8","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("27","1645","1626","0","10","2023-06-22 08:38:40","1","7","7","0","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("28","1646","1626","0","11","2023-06-22 09:08:46","1","0","0","7","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("55","1664","1630","0","14","2023-06-25 04:25:11","1","0","0","8","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("56","1664","1626","0","14","2023-06-25 04:25:11","1","0","0","7","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("58","1665","1626","0","14","2023-06-25 16:57:36","3","0","0","21","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("60","1667","1630","0","11","2023-06-27 15:10:15","1","8","8","0","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("61","1670","1630","0","11","2023-06-28 03:05:27","3","18","18","6","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("62","1670","1626","0","11","2023-06-28 03:05:27","2","10","10","4","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("64","1671","1630","0","11","2023-06-28 03:10:58","1","0","0","8","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("65","1671","1554","0","11","2023-06-28 03:10:58","1","0","0","19","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("67","1672","1630","0","16","2023-06-28 03:42:42","10","0","0","80","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("69","1673","1620","0","17","2023-06-30 05:57:27","1","0","0","29","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("71","1675","1626","0","18","2023-08-01 08:09:07","1","7","7","0","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("72","1676","1626","0","18","2023-08-01 08:09:56","1","0","0","7","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("74","1678","1626","0","19","2023-08-05 08:43:52","1","0","0","7","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("80","1684","1630","0","20","2023-08-26 10:39:46","2","0","0","16","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("78","1683","1637","0","20","2023-08-17 03:20:24","1","19","19","10","0","0","0");/*END*/
INSERT INTO `webtoffee_wc_order_product_lookup` VALUES
("76","1679","1632","0","21","2023-08-15 11:51:26","2","0","0","70","0","0","0");/*END*/