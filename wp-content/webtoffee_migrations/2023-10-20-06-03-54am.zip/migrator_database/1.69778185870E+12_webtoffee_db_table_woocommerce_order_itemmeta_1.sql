

DROP TABLE IF EXISTS `webtoffee_woocommerce_order_itemmeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=MyISAM AUTO_INCREMENT=574 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("315","45","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("314","45","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("313","45","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("312","44","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("311","44","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("310","44","_line_total","8");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("309","44","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("308","44","_line_subtotal","8");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("307","44","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("306","44","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("305","44","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("304","44","_product_id","1630");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("295","42","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("296","42","_line_subtotal","19");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("297","42","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("298","42","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("299","42","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("300","42","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("301","43","discount_amount","19");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("302","43","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("303","43","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:7;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("294","42","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("293","42","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("292","42","_product_id","220");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("286","40","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("287","40","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("288","40","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("289","41","discount_amount","15");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("290","41","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("291","41","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:6;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("285","40","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("284","40","_line_subtotal","8");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("283","40","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("282","40","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("281","40","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("280","40","_product_id","1630");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("279","39","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("271","39","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("272","39","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("273","39","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("274","39","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("275","39","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("276","39","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("277","39","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("278","39","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("270","38","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:5;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("259","37","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("260","37","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("261","37","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("262","37","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("263","37","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("264","37","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("265","37","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("266","37","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("267","37","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("268","38","discount_amount","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("269","38","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("247","35","_product_id","220");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("248","35","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("249","35","_qty","2");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("250","35","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("251","35","_line_subtotal","38");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("252","35","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("253","35","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("254","35","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("255","35","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("256","36","discount_amount","38");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("257","36","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("258","36","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:4;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("235","33","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("236","33","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("237","33","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("238","33","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("239","33","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("240","33","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("241","33","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("242","33","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("243","33","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("244","34","discount_amount","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("245","34","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("246","34","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:3;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("234","32","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:2;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("233","32","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("232","32","discount_amount","37");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("231","31","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("230","31","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("229","31","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("228","31","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("227","31","_line_subtotal","29");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("226","31","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("225","31","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("224","31","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("223","31","_product_id","1637");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("222","30","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("221","30","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("220","30","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("218","30","_line_subtotal","8");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("219","30","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("217","30","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("216","30","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("215","30","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("214","30","_product_id","1630");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("210","28","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("211","29","discount_amount","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("212","29","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("213","29","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:1;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("209","28","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("208","28","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("207","28","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("206","28","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("205","28","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("204","28","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("202","28","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("203","28","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("201","27","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("200","27","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("199","27","_line_total","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("198","27","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("197","27","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("196","27","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("195","27","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("193","27","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("194","27","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("316","45","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("317","45","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("318","45","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("319","45","_line_total","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("320","45","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("321","45","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("322","46","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("323","46","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("324","46","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("325","46","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("326","46","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("327","46","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("328","46","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("329","46","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("330","46","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("331","47","discount_amount","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("332","47","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("333","47","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:8;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("334","48","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("335","48","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("336","48","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("337","48","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("338","48","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("339","48","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("340","48","_line_total","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("341","48","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("342","48","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("343","49","_product_id","1630");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("344","49","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("345","49","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("346","49","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("347","49","_line_subtotal","8");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("348","49","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("349","49","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("350","49","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("351","49","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("352","50","discount_amount","8");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("353","50","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("354","50","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:9;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("355","51","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("356","51","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("357","51","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("358","51","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("359","51","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("360","51","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("361","51","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("362","51","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("363","51","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("364","52","discount_amount","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("365","52","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("366","52","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:10;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("367","53","_product_id","1637");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("368","53","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("369","53","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("370","53","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("371","53","_line_subtotal","29");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("372","53","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("373","53","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("374","53","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("375","53","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("376","54","discount_amount","29");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("377","54","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("378","54","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:11;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("379","55","_product_id","1630");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("380","55","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("381","55","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("382","55","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("383","55","_line_subtotal","8");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("384","55","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("385","55","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("386","55","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("387","55","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("388","56","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("389","56","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("390","56","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("391","56","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("392","56","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("393","56","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("394","56","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("395","56","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("396","56","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("397","57","discount_amount","15");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("398","57","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("399","57","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:12;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("400","58","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("401","58","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("402","58","_qty","3");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("403","58","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("404","58","_line_subtotal","21");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("405","58","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("406","58","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("407","58","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("408","58","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("409","59","discount_amount","21");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("410","59","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("411","59","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:12;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("412","60","_product_id","1630");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("413","60","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("414","60","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("415","60","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("416","60","_line_subtotal","8");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("417","60","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("418","60","_line_total","8");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("419","60","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("420","60","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("421","61","_product_id","1630");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("422","61","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("423","61","_qty","3");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("424","61","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("425","61","_line_subtotal","24");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("426","61","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("427","61","_line_total","18");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("428","61","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("429","61","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("430","62","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("431","62","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("432","62","_qty","2");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("433","62","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("434","62","_line_subtotal","14");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("435","62","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("436","62","_line_total","10");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("437","62","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("438","62","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("439","63","discount_amount","10");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("440","63","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("441","63","coupon_data","a:25:{s:2:\"id\";i:1669;s:4:\"code\";s:10:\"aditya2345\";s:6:\"amount\";s:2:\"10\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-28 03:04:48.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-28 03:04:48.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";N;s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:17:\"Aditya Admin code\";s:11:\"usage_count\";i:0;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("442","64","_product_id","1630");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("443","64","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("444","64","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("445","64","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("446","64","_line_subtotal","8");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("447","64","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("448","64","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("449","64","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("450","64","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("451","65","_product_id","1554");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("452","65","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("453","65","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("454","65","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("455","65","_line_subtotal","19");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("456","65","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("457","65","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("458","65","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("459","65","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("460","66","discount_amount","27");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("461","66","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("462","66","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:12;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("463","67","_product_id","1630");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("464","67","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("465","67","_qty","10");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("466","67","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("467","67","_line_subtotal","80");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("468","67","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("469","67","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("470","67","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("471","67","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("472","68","discount_amount","80");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("473","68","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("474","68","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:13;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("475","69","_product_id","1620");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("476","69","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("477","69","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("478","69","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("479","69","_line_subtotal","29");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("480","69","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("481","69","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("482","69","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("483","69","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("484","70","discount_amount","29");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("485","70","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("486","70","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:14;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("487","71","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("488","71","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("489","71","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("490","71","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("491","71","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("492","71","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("493","71","_line_total","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("494","71","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("495","71","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("496","72","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("497","72","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("498","72","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("499","72","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("500","72","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("501","72","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("502","72","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("503","72","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("504","72","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("505","73","discount_amount","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("506","73","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("507","73","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:15;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("508","74","_product_id","1626");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("509","74","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("510","74","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("511","74","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("512","74","_line_subtotal","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("513","74","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("514","74","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("515","74","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("516","74","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("517","75","discount_amount","7");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("518","75","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("519","75","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:16;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("520","76","_product_id","1632");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("521","76","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("522","76","_qty","2");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("523","76","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("524","76","_line_subtotal","70");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("525","76","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("526","76","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("527","76","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("528","76","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("529","77","discount_amount","70");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("530","77","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("531","77","coupon_data","a:25:{s:2:\"id\";i:1617;s:4:\"code\";s:5:\"vivek\";s:6:\"amount\";s:3:\"100\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-06-19 17:21:10.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2024-05-23 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:10:\"fixed_cart\";s:11:\"description\";s:5:\"vivek\";s:11:\"usage_count\";i:17;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("532","78","_product_id","1637");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("533","78","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("534","78","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("535","78","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("536","78","_line_subtotal","29");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("537","78","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("538","78","_line_total","19");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("539","78","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("540","78","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("541","79","discount_amount","10");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("542","79","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("543","79","coupon_data","a:25:{s:2:\"id\";i:1680;s:4:\"code\";s:7:\"insta30\";s:6:\"amount\";s:2:\"10\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-08-15 17:22:03.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-08-15 17:22:03.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-08-31 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:13:\"fixed_product\";s:11:\"description\";s:27:\"30% on all social products \";s:11:\"usage_count\";i:0;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("544","80","_product_id","1630");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("545","80","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("546","80","_qty","2");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("547","80","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("548","80","_line_subtotal","16");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("549","80","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("550","80","_line_total","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("551","80","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("552","80","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("553","81","discount_amount","16");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("554","81","discount_amount_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("555","81","coupon_data","a:25:{s:2:\"id\";i:1680;s:4:\"code\";s:7:\"insta30\";s:6:\"amount\";s:2:\"10\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-08-15 17:22:03.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-08-15 17:22:03.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-08-31 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:13:\"fixed_product\";s:11:\"description\";s:27:\"30% on all social products \";s:11:\"usage_count\";i:0;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:0;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("556","82","_product_id","1632");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("557","82","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("558","82","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("559","82","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("560","82","_line_subtotal","35");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("561","82","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("562","82","_line_total","35");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("563","82","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("564","82","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("565","83","_product_id","1630");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("566","83","_variation_id","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("567","83","_qty","1");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("568","83","_tax_class","");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("569","83","_line_subtotal","8");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("570","83","_line_subtotal_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("571","83","_line_total","8");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("572","83","_line_tax","0");/*END*/
INSERT INTO `webtoffee_woocommerce_order_itemmeta` VALUES
("573","83","_line_tax_data","a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}");/*END*/