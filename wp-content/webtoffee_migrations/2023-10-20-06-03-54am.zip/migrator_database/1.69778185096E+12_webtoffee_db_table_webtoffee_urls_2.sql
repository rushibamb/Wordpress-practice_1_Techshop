
INSERT INTO `webtoffee_urls` VALUES
("1001","static_file","/wp-includes/blocks/template-part/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1002","static_file","/wp-includes/blocks/template-part/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1003","static_file","/wp-includes/blocks/template-part/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1004","static_file","/wp-includes/blocks/template-part/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1005","static_file","/wp-includes/blocks/template-part/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1006","static_file","/wp-includes/blocks/template-part/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1007","static_file","/wp-includes/blocks/template-part/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1008","static_file","/wp-includes/blocks/template-part/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1009","static_file","/wp-includes/blocks/term-description/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1010","static_file","/wp-includes/blocks/term-description/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1011","static_file","/wp-includes/blocks/term-description/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1012","static_file","/wp-includes/blocks/term-description/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1013","static_file","/wp-includes/blocks/text-columns/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1014","static_file","/wp-includes/blocks/text-columns/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1015","static_file","/wp-includes/blocks/text-columns/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1016","static_file","/wp-includes/blocks/text-columns/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1017","static_file","/wp-includes/blocks/text-columns/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1018","static_file","/wp-includes/blocks/text-columns/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1019","static_file","/wp-includes/blocks/text-columns/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1020","static_file","/wp-includes/blocks/text-columns/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1021","static_file","/wp-includes/blocks/verse/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1022","static_file","/wp-includes/blocks/verse/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1023","static_file","/wp-includes/blocks/verse/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1024","static_file","/wp-includes/blocks/verse/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1025","static_file","/wp-includes/blocks/video/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1026","static_file","/wp-includes/blocks/video/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1027","static_file","/wp-includes/blocks/video/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1028","static_file","/wp-includes/blocks/video/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1029","static_file","/wp-includes/blocks/video/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1030","static_file","/wp-includes/blocks/video/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1031","static_file","/wp-includes/blocks/video/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1032","static_file","/wp-includes/blocks/video/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1033","static_file","/wp-includes/blocks/video/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1034","static_file","/wp-includes/blocks/video/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1035","static_file","/wp-includes/blocks/video/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1036","static_file","/wp-includes/blocks/video/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1037","static_file","/wp-includes/css/dist/block-directory/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1038","static_file","/wp-includes/css/dist/block-directory/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1039","static_file","/wp-includes/css/dist/block-directory/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1040","static_file","/wp-includes/css/dist/block-directory/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1041","static_file","/wp-includes/css/dist/block-editor/content-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1042","static_file","/wp-includes/css/dist/block-editor/content-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1043","static_file","/wp-includes/css/dist/block-editor/content.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1044","static_file","/wp-includes/css/dist/block-editor/content.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1045","static_file","/wp-includes/css/dist/block-editor/default-editor-styles-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1046","static_file","/wp-includes/css/dist/block-editor/default-editor-styles-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1047","static_file","/wp-includes/css/dist/block-editor/default-editor-styles.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1048","static_file","/wp-includes/css/dist/block-editor/default-editor-styles.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1049","static_file","/wp-includes/css/dist/block-editor/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1050","static_file","/wp-includes/css/dist/block-editor/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1051","static_file","/wp-includes/css/dist/block-editor/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1052","static_file","/wp-includes/css/dist/block-editor/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1053","static_file","/wp-includes/css/dist/block-library/classic-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-14 03:44:36","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1054","static_file","/wp-includes/css/dist/block-library/classic-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-14 03:44:36","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1055","static_file","/wp-includes/css/dist/block-library/classic.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-14 03:44:36","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1056","static_file","/wp-includes/css/dist/block-library/classic.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-14 03:44:36","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1057","static_file","/wp-includes/css/dist/block-library/common-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1058","static_file","/wp-includes/css/dist/block-library/common-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1059","static_file","/wp-includes/css/dist/block-library/common.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1060","static_file","/wp-includes/css/dist/block-library/common.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1061","static_file","/wp-includes/css/dist/block-library/editor-elements-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 06:59:20","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1062","static_file","/wp-includes/css/dist/block-library/editor-elements-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2022-09-20 03:43:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1063","static_file","/wp-includes/css/dist/block-library/editor-elements.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 06:59:20","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1064","static_file","/wp-includes/css/dist/block-library/editor-elements.min.css","","","0","1","1","","0000-00-00 00:00:00","","2022-09-20 03:43:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1065","static_file","/wp-includes/css/dist/block-library/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1066","static_file","/wp-includes/css/dist/block-library/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1067","static_file","/wp-includes/css/dist/block-library/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1068","static_file","/wp-includes/css/dist/block-library/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1069","static_file","/wp-includes/css/dist/block-library/elements-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 06:59:20","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1070","static_file","/wp-includes/css/dist/block-library/elements-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2022-09-20 03:43:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1071","static_file","/wp-includes/css/dist/block-library/elements.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 06:59:20","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1072","static_file","/wp-includes/css/dist/block-library/elements.min.css","","","0","1","1","","0000-00-00 00:00:00","","2022-09-20 03:43:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1073","static_file","/wp-includes/css/dist/block-library/reset-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 06:59:20","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1074","static_file","/wp-includes/css/dist/block-library/reset-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-01-27 03:56:28","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1075","static_file","/wp-includes/css/dist/block-library/reset.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 06:59:20","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1076","static_file","/wp-includes/css/dist/block-library/reset.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-01-27 03:56:28","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1077","static_file","/wp-includes/css/dist/block-library/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1078","static_file","/wp-includes/css/dist/block-library/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1079","static_file","/wp-includes/css/dist/block-library/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1080","static_file","/wp-includes/css/dist/block-library/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1081","static_file","/wp-includes/css/dist/block-library/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 07:04:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1082","static_file","/wp-includes/css/dist/block-library/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 07:04:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1083","static_file","/wp-includes/css/dist/block-library/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 07:04:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1084","static_file","/wp-includes/css/dist/block-library/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 07:04:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1085","static_file","/wp-includes/css/dist/commands/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1086","static_file","/wp-includes/css/dist/commands/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1087","static_file","/wp-includes/css/dist/commands/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1088","static_file","/wp-includes/css/dist/commands/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1089","static_file","/wp-includes/css/dist/components/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1090","static_file","/wp-includes/css/dist/components/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1091","static_file","/wp-includes/css/dist/components/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1092","static_file","/wp-includes/css/dist/components/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1093","static_file","/wp-includes/css/dist/customize-widgets/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1094","static_file","/wp-includes/css/dist/customize-widgets/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1095","static_file","/wp-includes/css/dist/customize-widgets/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1096","static_file","/wp-includes/css/dist/customize-widgets/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1097","static_file","/wp-includes/css/dist/edit-post/classic-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1098","static_file","/wp-includes/css/dist/edit-post/classic-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1099","static_file","/wp-includes/css/dist/edit-post/classic.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1100","static_file","/wp-includes/css/dist/edit-post/classic.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1101","static_file","/wp-includes/css/dist/edit-post/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1102","static_file","/wp-includes/css/dist/edit-post/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1103","static_file","/wp-includes/css/dist/edit-post/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1104","static_file","/wp-includes/css/dist/edit-post/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1105","static_file","/wp-includes/css/dist/edit-site/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1106","static_file","/wp-includes/css/dist/edit-site/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1107","static_file","/wp-includes/css/dist/edit-site/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1108","static_file","/wp-includes/css/dist/edit-site/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1109","static_file","/wp-includes/css/dist/edit-widgets/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1110","static_file","/wp-includes/css/dist/edit-widgets/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1111","static_file","/wp-includes/css/dist/edit-widgets/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1112","static_file","/wp-includes/css/dist/edit-widgets/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1113","static_file","/wp-includes/css/dist/editor/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1114","static_file","/wp-includes/css/dist/editor/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1115","static_file","/wp-includes/css/dist/editor/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1116","static_file","/wp-includes/css/dist/editor/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1117","static_file","/wp-includes/css/dist/format-library/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1118","static_file","/wp-includes/css/dist/format-library/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1119","static_file","/wp-includes/css/dist/format-library/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1120","static_file","/wp-includes/css/dist/format-library/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1121","static_file","/wp-includes/css/dist/list-reusable-blocks/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1122","static_file","/wp-includes/css/dist/list-reusable-blocks/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1123","static_file","/wp-includes/css/dist/list-reusable-blocks/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1124","static_file","/wp-includes/css/dist/list-reusable-blocks/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1125","static_file","/wp-includes/css/dist/nux/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1126","static_file","/wp-includes/css/dist/nux/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1127","static_file","/wp-includes/css/dist/nux/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1128","static_file","/wp-includes/css/dist/nux/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1129","static_file","/wp-includes/css/dist/reusable-blocks/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1130","static_file","/wp-includes/css/dist/reusable-blocks/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1131","static_file","/wp-includes/css/dist/reusable-blocks/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1132","static_file","/wp-includes/css/dist/reusable-blocks/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1133","static_file","/wp-includes/css/dist/widgets/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1134","static_file","/wp-includes/css/dist/widgets/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1135","static_file","/wp-includes/css/dist/widgets/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1136","static_file","/wp-includes/css/dist/widgets/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1137","static_file","/wp-includes/css/admin-bar-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-11 05:39:20","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1138","static_file","/wp-includes/css/admin-bar-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-11 05:39:20","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1139","static_file","/wp-includes/css/admin-bar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-11 05:39:20","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1140","static_file","/wp-includes/css/admin-bar.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-11 05:39:20","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1141","static_file","/wp-includes/css/buttons-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2021-11-15 11:22:02","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1142","static_file","/wp-includes/css/buttons-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-11-15 11:22:02","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1143","static_file","/wp-includes/css/buttons.css","","","0","1","1","","0000-00-00 00:00:00","","2021-11-15 11:22:02","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1144","static_file","/wp-includes/css/buttons.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-11-15 11:22:02","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1145","static_file","/wp-includes/css/classic-themes.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-13 08:50:20","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1146","static_file","/wp-includes/css/classic-themes.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-02-13 08:50:20","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1147","static_file","/wp-includes/css/customize-preview-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2021-01-26 06:55:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1148","static_file","/wp-includes/css/customize-preview-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-03-03 09:16:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1149","static_file","/wp-includes/css/customize-preview.css","","","0","1","1","","0000-00-00 00:00:00","","2021-01-26 06:55:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1150","static_file","/wp-includes/css/customize-preview.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-03-03 09:16:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1151","static_file","/wp-includes/css/dashicons.css","","","0","1","1","","0000-00-00 00:00:00","","2020-10-21 01:16:08","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1152","static_file","/wp-includes/css/dashicons.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-03-03 09:16:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1153","static_file","/wp-includes/css/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1154","static_file","/wp-includes/css/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1155","static_file","/wp-includes/css/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1156","static_file","/wp-includes/css/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1157","static_file","/wp-includes/css/jquery-ui-dialog-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2021-01-26 06:55:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1158","static_file","/wp-includes/css/jquery-ui-dialog-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-01-26 06:55:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1159","static_file","/wp-includes/css/jquery-ui-dialog.css","","","0","1","1","","0000-00-00 00:00:00","","2021-01-26 06:55:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1160","static_file","/wp-includes/css/jquery-ui-dialog.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-01-26 06:55:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1161","static_file","/wp-includes/css/media-views-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1162","static_file","/wp-includes/css/media-views-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1163","static_file","/wp-includes/css/media-views.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1164","static_file","/wp-includes/css/media-views.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1165","static_file","/wp-includes/css/wp-auth-check-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1166","static_file","/wp-includes/css/wp-auth-check-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1167","static_file","/wp-includes/css/wp-auth-check.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1168","static_file","/wp-includes/css/wp-auth-check.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1169","static_file","/wp-includes/css/wp-embed-template-ie.css","","","0","1","1","","0000-00-00 00:00:00","","2015-10-31 04:38:26","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1170","static_file","/wp-includes/css/wp-embed-template-ie.min.css","","","0","1","1","","0000-00-00 00:00:00","","2017-08-19 08:10:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1171","static_file","/wp-includes/css/wp-embed-template.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1172","static_file","/wp-includes/css/wp-embed-template.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1173","static_file","/wp-includes/css/wp-pointer-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1174","static_file","/wp-includes/css/wp-pointer-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1175","static_file","/wp-includes/css/wp-pointer.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1176","static_file","/wp-includes/css/wp-pointer.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1177","static_file","/wp-includes/fonts/dashicons.ttf","","","0","1","1","","0000-00-00 00:00:00","","2020-07-17 05:11:04","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1178","static_file","/wp-includes/fonts/dashicons.woff","","","0","1","1","","0000-00-00 00:00:00","","2016-03-18 08:26:26","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1179","static_file","/wp-includes/fonts/dashicons.woff2","","","0","1","1","","0000-00-00 00:00:00","","2020-07-17 05:11:04","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1180","static_file","/wp-includes/fonts/dashicons.eot","","","0","1","1","","0000-00-00 00:00:00","","2020-07-17 05:11:04","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1181","static_file","/wp-includes/fonts/dashicons.svg","","","0","1","1","","0000-00-00 00:00:00","","2020-07-17 05:11:04","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1182","static_file","/wp-includes/images/crystal/license.txt","","","0","1","1","","0000-00-00 00:00:00","","2014-03-03 02:34:28","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1183","static_file","/wp-includes/images/crystal/archive.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1184","static_file","/wp-includes/images/crystal/audio.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1185","static_file","/wp-includes/images/crystal/code.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1186","static_file","/wp-includes/images/crystal/default.png","","","0","1","1","","0000-00-00 00:00:00","","2014-02-13 08:03:14","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1187","static_file","/wp-includes/images/crystal/document.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1188","static_file","/wp-includes/images/crystal/interactive.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1189","static_file","/wp-includes/images/crystal/spreadsheet.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1190","static_file","/wp-includes/images/crystal/text.png","","","0","1","1","","0000-00-00 00:00:00","","2014-02-13 08:03:14","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1191","static_file","/wp-includes/images/crystal/video.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1192","static_file","/wp-includes/images/media/archive.png","","","0","1","1","","0000-00-00 00:00:00","","2014-03-27 10:41:14","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1193","static_file","/wp-includes/images/media/audio.png","","","0","1","1","","0000-00-00 00:00:00","","2014-03-27 10:41:14","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1194","static_file","/wp-includes/images/media/code.png","","","0","1","1","","0000-00-00 00:00:00","","2014-03-25 09:10:16","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1195","static_file","/wp-includes/images/media/default.png","","","0","1","1","","0000-00-00 00:00:00","","2014-03-25 09:10:16","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1196","static_file","/wp-includes/images/media/document.png","","","0","1","1","","0000-00-00 00:00:00","","2014-03-25 09:10:16","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1197","static_file","/wp-includes/images/media/interactive.png","","","0","1","1","","0000-00-00 00:00:00","","2014-03-25 09:10:16","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1198","static_file","/wp-includes/images/media/spreadsheet.png","","","0","1","1","","0000-00-00 00:00:00","","2014-03-25 09:10:16","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1199","static_file","/wp-includes/images/media/text.png","","","0","1","1","","0000-00-00 00:00:00","","2014-03-25 09:10:16","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1200","static_file","/wp-includes/images/media/video.png","","","0","1","1","","0000-00-00 00:00:00","","2014-03-25 09:10:16","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1201","static_file","/wp-includes/images/smilies/icon_arrow.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1202","static_file","/wp-includes/images/smilies/icon_biggrin.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1203","static_file","/wp-includes/images/smilies/icon_confused.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1204","static_file","/wp-includes/images/smilies/icon_cool.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1205","static_file","/wp-includes/images/smilies/icon_cry.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1206","static_file","/wp-includes/images/smilies/icon_eek.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1207","static_file","/wp-includes/images/smilies/icon_evil.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1208","static_file","/wp-includes/images/smilies/icon_exclaim.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1209","static_file","/wp-includes/images/smilies/icon_idea.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1210","static_file","/wp-includes/images/smilies/icon_lol.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1211","static_file","/wp-includes/images/smilies/icon_mad.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1212","static_file","/wp-includes/images/smilies/icon_mrgreen.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1213","static_file","/wp-includes/images/smilies/icon_neutral.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1214","static_file","/wp-includes/images/smilies/icon_question.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1215","static_file","/wp-includes/images/smilies/icon_razz.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1216","static_file","/wp-includes/images/smilies/icon_redface.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1217","static_file","/wp-includes/images/smilies/icon_rolleyes.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1218","static_file","/wp-includes/images/smilies/icon_sad.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1219","static_file","/wp-includes/images/smilies/icon_smile.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1220","static_file","/wp-includes/images/smilies/icon_surprised.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1221","static_file","/wp-includes/images/smilies/icon_twisted.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1222","static_file","/wp-includes/images/smilies/icon_wink.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1223","static_file","/wp-includes/images/smilies/frownie.png","","","0","1","1","","0000-00-00 00:00:00","","2015-04-10 06:20:26","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1224","static_file","/wp-includes/images/smilies/mrgreen.png","","","0","1","1","","0000-00-00 00:00:00","","2015-04-10 06:20:26","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1225","static_file","/wp-includes/images/smilies/rolleyes.png","","","0","1","1","","0000-00-00 00:00:00","","2015-04-10 06:20:26","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1226","static_file","/wp-includes/images/smilies/simple-smile.png","","","0","1","1","","0000-00-00 00:00:00","","2015-04-10 06:20:26","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1227","static_file","/wp-includes/images/blank.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1228","static_file","/wp-includes/images/down_arrow-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1229","static_file","/wp-includes/images/down_arrow.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1230","static_file","/wp-includes/images/spinner-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1231","static_file","/wp-includes/images/spinner.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1232","static_file","/wp-includes/images/wpspin-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1233","static_file","/wp-includes/images/wpspin.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1234","static_file","/wp-includes/images/xit-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1235","static_file","/wp-includes/images/xit.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1236","static_file","/wp-includes/images/admin-bar-sprite-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1237","static_file","/wp-includes/images/admin-bar-sprite.png","","","0","1","1","","0000-00-00 00:00:00","","2014-02-13 08:03:14","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1238","static_file","/wp-includes/images/arrow-pointer-blue-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1239","static_file","/wp-includes/images/arrow-pointer-blue.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1240","static_file","/wp-includes/images/icon-pointer-flag-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2012-09-27 02:12:54","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1241","static_file","/wp-includes/images/icon-pointer-flag.png","","","0","1","1","","0000-00-00 00:00:00","","2011-12-05 09:49:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1242","static_file","/wp-includes/images/rss-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 08:54:08","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1243","static_file","/wp-includes/images/rss.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1244","static_file","/wp-includes/images/toggle-arrow-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 08:54:08","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1245","static_file","/wp-includes/images/toggle-arrow.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1246","static_file","/wp-includes/images/uploader-icons-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1247","static_file","/wp-includes/images/uploader-icons.png","","","0","1","1","","0000-00-00 00:00:00","","2014-02-13 08:03:14","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1248","static_file","/wp-includes/images/w-logo-blue-white-bg.png","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1249","static_file","/wp-includes/images/w-logo-blue.png","","","0","1","1","","0000-00-00 00:00:00","","2016-02-23 04:55:28","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1250","static_file","/wp-includes/images/wpicons-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-11-25 06:12:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1251","static_file","/wp-includes/images/wpicons.png","","","0","1","1","","0000-00-00 00:00:00","","2014-11-25 06:12:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1252","static_file","/wp-includes/js/codemirror/codemirror.min.css","","","0","1","1","","0000-00-00 00:00:00","","2017-09-13 06:08:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1253","static_file","/wp-includes/js/codemirror/codemirror.min.js","","","0","1","1","","0000-00-00 00:00:00","","2017-09-13 06:08:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1254","static_file","/wp-includes/js/codemirror/csslint.js","","","0","1","1","","0000-00-00 00:00:00","","2019-10-25 04:38:08","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1255","static_file","/wp-includes/js/codemirror/esprima.js","","","0","1","1","","0000-00-00 00:00:00","","2018-01-23 01:29:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1256","static_file","/wp-includes/js/codemirror/fakejshint.js","","","0","1","1","","0000-00-00 00:00:00","","2018-01-23 01:29:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1257","static_file","/wp-includes/js/codemirror/htmlhint-kses.js","","","0","1","1","","0000-00-00 00:00:00","","2017-09-13 06:08:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1258","static_file","/wp-includes/js/codemirror/htmlhint.js","","","0","1","1","","0000-00-00 00:00:00","","2017-09-13 06:08:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1259","static_file","/wp-includes/js/codemirror/jsonlint.js","","","0","1","1","","0000-00-00 00:00:00","","2017-09-13 06:08:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1260","static_file","/wp-includes/js/crop/cropper.css","","","0","1","1","","0000-00-00 00:00:00","","2012-12-20 03:55:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1261","static_file","/wp-includes/js/crop/cropper.js","","","0","1","1","","0000-00-00 00:00:00","","2007-05-04 09:48:44","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1262","static_file","/wp-includes/js/crop/marqueeHoriz.gif","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1263","static_file","/wp-includes/js/crop/marqueeVert.gif","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1264","static_file","/wp-includes/js/dist/development/react-refresh-entry.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 04:10:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1265","static_file","/wp-includes/js/dist/development/react-refresh-entry.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 04:10:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1266","static_file","/wp-includes/js/dist/development/react-refresh-runtime.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 04:10:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1267","static_file","/wp-includes/js/dist/development/react-refresh-runtime.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 04:10:22","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1268","static_file","/wp-includes/js/dist/vendor/lodash.js","","","0","1","1","","0000-00-00 00:00:00","","2021-05-20 01:02:18","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1269","static_file","/wp-includes/js/dist/vendor/lodash.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1270","static_file","/wp-includes/js/dist/vendor/moment.js","","","0","1","1","","0000-00-00 00:00:00","","2022-07-19 07:43:26","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1271","static_file","/wp-includes/js/dist/vendor/moment.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1272","static_file","/wp-includes/js/dist/vendor/react-dom.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 07:04:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1273","static_file","/wp-includes/js/dist/vendor/react-dom.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1274","static_file","/wp-includes/js/dist/vendor/react.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 07:04:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1275","static_file","/wp-includes/js/dist/vendor/react.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 07:04:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1276","static_file","/wp-includes/js/dist/vendor/regenerator-runtime.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 03:56:38","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1277","static_file","/wp-includes/js/dist/vendor/regenerator-runtime.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 03:56:38","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1278","static_file","/wp-includes/js/dist/vendor/wp-polyfill-dom-rect.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-12 05:35:28","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1279","static_file","/wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 12:04:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1280","static_file","/wp-includes/js/dist/vendor/wp-polyfill-element-closest.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 04:48:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1281","static_file","/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 04:48:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1282","static_file","/wp-includes/js/dist/vendor/wp-polyfill-fetch.js","","","0","1","1","","0000-00-00 00:00:00","","2021-08-30 01:51:12","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1283","static_file","/wp-includes/js/dist/vendor/wp-polyfill-fetch.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 12:04:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1284","static_file","/wp-includes/js/dist/vendor/wp-polyfill-formdata.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-12 05:35:28","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1285","static_file","/wp-includes/js/dist/vendor/wp-polyfill-formdata.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-12 05:35:28","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1286","static_file","/wp-includes/js/dist/vendor/wp-polyfill-inert.js","","","0","1","1","","0000-00-00 00:00:00","","2023-01-18 11:16:34","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1287","static_file","/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-01-18 11:16:34","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1288","static_file","/wp-includes/js/dist/vendor/wp-polyfill-node-contains.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-30 02:49:04","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1289","static_file","/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-30 02:49:04","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1290","static_file","/wp-includes/js/dist/vendor/wp-polyfill-object-fit.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-30 02:16:34","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1291","static_file","/wp-includes/js/dist/vendor/wp-polyfill-object-fit.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1292","static_file","/wp-includes/js/dist/vendor/wp-polyfill-url.js","","","0","1","1","","0000-00-00 00:00:00","","2020-03-03 04:55:08","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1293","static_file","/wp-includes/js/dist/vendor/wp-polyfill-url.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1294","static_file","/wp-includes/js/dist/vendor/wp-polyfill.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1295","static_file","/wp-includes/js/dist/vendor/wp-polyfill.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:47","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1296","static_file","/wp-includes/js/dist/a11y.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1297","static_file","/wp-includes/js/dist/a11y.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1298","static_file","/wp-includes/js/dist/annotations.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1299","static_file","/wp-includes/js/dist/annotations.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1300","static_file","/wp-includes/js/dist/api-fetch.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1301","static_file","/wp-includes/js/dist/api-fetch.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:53","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1302","static_file","/wp-includes/js/dist/autop.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1303","static_file","/wp-includes/js/dist/autop.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:53","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1304","static_file","/wp-includes/js/dist/blob.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:51","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1305","static_file","/wp-includes/js/dist/blob.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:53","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1306","static_file","/wp-includes/js/dist/block-directory.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1307","static_file","/wp-includes/js/dist/block-directory.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1308","static_file","/wp-includes/js/dist/block-editor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 11:08:19","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1309","static_file","/wp-includes/js/dist/block-editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 11:08:19","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1310","static_file","/wp-includes/js/dist/block-library.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:54","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1311","static_file","/wp-includes/js/dist/block-library.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1312","static_file","/wp-includes/js/dist/block-serialization-default-parser.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 07:04:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1313","static_file","/wp-includes/js/dist/block-serialization-default-parser.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 07:04:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1314","static_file","/wp-includes/js/dist/blocks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1315","static_file","/wp-includes/js/dist/blocks.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1316","static_file","/wp-includes/js/dist/commands.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1317","static_file","/wp-includes/js/dist/commands.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1318","static_file","/wp-includes/js/dist/components.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 11:08:21","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1319","static_file","/wp-includes/js/dist/components.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 11:08:21","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1320","static_file","/wp-includes/js/dist/compose.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1321","static_file","/wp-includes/js/dist/compose.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:51","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1322","static_file","/wp-includes/js/dist/core-commands.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1323","static_file","/wp-includes/js/dist/core-commands.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1324","static_file","/wp-includes/js/dist/core-data.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 11:08:21","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1325","static_file","/wp-includes/js/dist/core-data.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 11:08:21","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1326","static_file","/wp-includes/js/dist/customize-widgets.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1327","static_file","/wp-includes/js/dist/customize-widgets.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1328","static_file","/wp-includes/js/dist/data-controls.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:53","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1329","static_file","/wp-includes/js/dist/data-controls.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1330","static_file","/wp-includes/js/dist/data.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1331","static_file","/wp-includes/js/dist/data.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1332","static_file","/wp-includes/js/dist/date.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1333","static_file","/wp-includes/js/dist/date.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1334","static_file","/wp-includes/js/dist/deprecated.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1335","static_file","/wp-includes/js/dist/deprecated.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1336","static_file","/wp-includes/js/dist/dom-ready.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 12:04:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1337","static_file","/wp-includes/js/dist/dom-ready.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 12:04:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1338","static_file","/wp-includes/js/dist/dom.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1339","static_file","/wp-includes/js/dist/dom.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1340","static_file","/wp-includes/js/dist/edit-post.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 11:08:21","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1341","static_file","/wp-includes/js/dist/edit-post.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-02 11:08:21","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1342","static_file","/wp-includes/js/dist/edit-site.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1343","static_file","/wp-includes/js/dist/edit-site.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:49","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1344","static_file","/wp-includes/js/dist/edit-widgets.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1345","static_file","/wp-includes/js/dist/edit-widgets.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1346","static_file","/wp-includes/js/dist/editor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1347","static_file","/wp-includes/js/dist/editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:51","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1348","static_file","/wp-includes/js/dist/element.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1349","static_file","/wp-includes/js/dist/element.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1350","static_file","/wp-includes/js/dist/escape-html.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-20 03:43:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1351","static_file","/wp-includes/js/dist/escape-html.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 12:04:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1352","static_file","/wp-includes/js/dist/format-library.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:51","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1353","static_file","/wp-includes/js/dist/format-library.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1354","static_file","/wp-includes/js/dist/hooks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1355","static_file","/wp-includes/js/dist/hooks.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1356","static_file","/wp-includes/js/dist/html-entities.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-12 03:12:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1357","static_file","/wp-includes/js/dist/html-entities.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 12:04:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1358","static_file","/wp-includes/js/dist/i18n.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1359","static_file","/wp-includes/js/dist/i18n.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:53","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1360","static_file","/wp-includes/js/dist/is-shallow-equal.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1361","static_file","/wp-includes/js/dist/is-shallow-equal.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 12:04:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1362","static_file","/wp-includes/js/dist/keyboard-shortcuts.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1363","static_file","/wp-includes/js/dist/keyboard-shortcuts.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1364","static_file","/wp-includes/js/dist/keycodes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1365","static_file","/wp-includes/js/dist/keycodes.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1366","static_file","/wp-includes/js/dist/list-reusable-blocks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1367","static_file","/wp-includes/js/dist/list-reusable-blocks.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1368","static_file","/wp-includes/js/dist/media-utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1369","static_file","/wp-includes/js/dist/media-utils.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:51","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1370","static_file","/wp-includes/js/dist/notices.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1371","static_file","/wp-includes/js/dist/notices.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:53","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1372","static_file","/wp-includes/js/dist/nux.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1373","static_file","/wp-includes/js/dist/nux.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1374","static_file","/wp-includes/js/dist/plugins.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:54","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1375","static_file","/wp-includes/js/dist/plugins.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1376","static_file","/wp-includes/js/dist/preferences-persistence.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1377","static_file","/wp-includes/js/dist/preferences-persistence.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1378","static_file","/wp-includes/js/dist/preferences.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:51","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1379","static_file","/wp-includes/js/dist/preferences.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1380","static_file","/wp-includes/js/dist/primitives.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1381","static_file","/wp-includes/js/dist/primitives.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1382","static_file","/wp-includes/js/dist/priority-queue.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 07:04:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1383","static_file","/wp-includes/js/dist/priority-queue.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 07:04:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1384","static_file","/wp-includes/js/dist/private-apis.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1385","static_file","/wp-includes/js/dist/private-apis.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1386","static_file","/wp-includes/js/dist/redux-routine.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1387","static_file","/wp-includes/js/dist/redux-routine.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:53","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1388","static_file","/wp-includes/js/dist/reusable-blocks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1389","static_file","/wp-includes/js/dist/reusable-blocks.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1390","static_file","/wp-includes/js/dist/rich-text.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1391","static_file","/wp-includes/js/dist/rich-text.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:53","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1392","static_file","/wp-includes/js/dist/router.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1393","static_file","/wp-includes/js/dist/router.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:52","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1394","static_file","/wp-includes/js/dist/server-side-render.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1395","static_file","/wp-includes/js/dist/server-side-render.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1396","static_file","/wp-includes/js/dist/shortcode.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1397","static_file","/wp-includes/js/dist/shortcode.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1398","static_file","/wp-includes/js/dist/style-engine.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1399","static_file","/wp-includes/js/dist/style-engine.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1400","static_file","/wp-includes/js/dist/token-list.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1401","static_file","/wp-includes/js/dist/token-list.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:54","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1402","static_file","/wp-includes/js/dist/url.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1403","static_file","/wp-includes/js/dist/url.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1404","static_file","/wp-includes/js/dist/viewport.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1405","static_file","/wp-includes/js/dist/viewport.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:53","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1406","static_file","/wp-includes/js/dist/warning.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-12 03:12:48","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1407","static_file","/wp-includes/js/dist/warning.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 12:04:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1408","static_file","/wp-includes/js/dist/widgets.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1409","static_file","/wp-includes/js/dist/widgets.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:50","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1410","static_file","/wp-includes/js/dist/wordcount.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:49","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1411","static_file","/wp-includes/js/dist/wordcount.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:55","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1412","static_file","/wp-includes/js/imgareaselect/imgareaselect.css","","","0","1","1","","0000-00-00 00:00:00","","2012-04-25 09:49:58","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1413","static_file","/wp-includes/js/imgareaselect/jquery.imgareaselect.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:56","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1414","static_file","/wp-includes/js/imgareaselect/jquery.imgareaselect.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:56","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1415","static_file","/wp-includes/js/imgareaselect/border-anim-h.gif","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1416","static_file","/wp-includes/js/imgareaselect/border-anim-v.gif","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1417","static_file","/wp-includes/js/jcrop/jquery.Jcrop.min.css","","","0","1","1","","0000-00-00 00:00:00","","2022-03-24 08:07:06","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1418","static_file","/wp-includes/js/jcrop/jquery.Jcrop.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-03-24 08:07:06","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1419","static_file","/wp-includes/js/jcrop/Jcrop.gif","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1420","static_file","/wp-includes/js/jquery/ui/accordion.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1421","static_file","/wp-includes/js/jquery/ui/accordion.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1422","static_file","/wp-includes/js/jquery/ui/autocomplete.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1423","static_file","/wp-includes/js/jquery/ui/autocomplete.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1424","static_file","/wp-includes/js/jquery/ui/button.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1425","static_file","/wp-includes/js/jquery/ui/button.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1426","static_file","/wp-includes/js/jquery/ui/checkboxradio.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1427","static_file","/wp-includes/js/jquery/ui/checkboxradio.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1428","static_file","/wp-includes/js/jquery/ui/controlgroup.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1429","static_file","/wp-includes/js/jquery/ui/controlgroup.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1430","static_file","/wp-includes/js/jquery/ui/core.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1431","static_file","/wp-includes/js/jquery/ui/core.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1432","static_file","/wp-includes/js/jquery/ui/datepicker.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1433","static_file","/wp-includes/js/jquery/ui/datepicker.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1434","static_file","/wp-includes/js/jquery/ui/dialog.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1435","static_file","/wp-includes/js/jquery/ui/dialog.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1436","static_file","/wp-includes/js/jquery/ui/draggable.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1437","static_file","/wp-includes/js/jquery/ui/draggable.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1438","static_file","/wp-includes/js/jquery/ui/droppable.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1439","static_file","/wp-includes/js/jquery/ui/droppable.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1440","static_file","/wp-includes/js/jquery/ui/effect-blind.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1441","static_file","/wp-includes/js/jquery/ui/effect-blind.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1442","static_file","/wp-includes/js/jquery/ui/effect-bounce.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1443","static_file","/wp-includes/js/jquery/ui/effect-bounce.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1444","static_file","/wp-includes/js/jquery/ui/effect-clip.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1445","static_file","/wp-includes/js/jquery/ui/effect-clip.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1446","static_file","/wp-includes/js/jquery/ui/effect-drop.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1447","static_file","/wp-includes/js/jquery/ui/effect-drop.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1448","static_file","/wp-includes/js/jquery/ui/effect-explode.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1449","static_file","/wp-includes/js/jquery/ui/effect-explode.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1450","static_file","/wp-includes/js/jquery/ui/effect-fade.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1451","static_file","/wp-includes/js/jquery/ui/effect-fade.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1452","static_file","/wp-includes/js/jquery/ui/effect-fold.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1453","static_file","/wp-includes/js/jquery/ui/effect-fold.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1454","static_file","/wp-includes/js/jquery/ui/effect-highlight.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1455","static_file","/wp-includes/js/jquery/ui/effect-highlight.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1456","static_file","/wp-includes/js/jquery/ui/effect-puff.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1457","static_file","/wp-includes/js/jquery/ui/effect-puff.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1458","static_file","/wp-includes/js/jquery/ui/effect-pulsate.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1459","static_file","/wp-includes/js/jquery/ui/effect-pulsate.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1460","static_file","/wp-includes/js/jquery/ui/effect-scale.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1461","static_file","/wp-includes/js/jquery/ui/effect-scale.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1462","static_file","/wp-includes/js/jquery/ui/effect-shake.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1463","static_file","/wp-includes/js/jquery/ui/effect-shake.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1464","static_file","/wp-includes/js/jquery/ui/effect-size.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1465","static_file","/wp-includes/js/jquery/ui/effect-size.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1466","static_file","/wp-includes/js/jquery/ui/effect-slide.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1467","static_file","/wp-includes/js/jquery/ui/effect-slide.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1468","static_file","/wp-includes/js/jquery/ui/effect-transfer.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1469","static_file","/wp-includes/js/jquery/ui/effect-transfer.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1470","static_file","/wp-includes/js/jquery/ui/effect.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1471","static_file","/wp-includes/js/jquery/ui/effect.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1472","static_file","/wp-includes/js/jquery/ui/menu.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1473","static_file","/wp-includes/js/jquery/ui/menu.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1474","static_file","/wp-includes/js/jquery/ui/mouse.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1475","static_file","/wp-includes/js/jquery/ui/mouse.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1476","static_file","/wp-includes/js/jquery/ui/progressbar.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1477","static_file","/wp-includes/js/jquery/ui/progressbar.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1478","static_file","/wp-includes/js/jquery/ui/resizable.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1479","static_file","/wp-includes/js/jquery/ui/resizable.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1480","static_file","/wp-includes/js/jquery/ui/selectable.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1481","static_file","/wp-includes/js/jquery/ui/selectable.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1482","static_file","/wp-includes/js/jquery/ui/selectmenu.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1483","static_file","/wp-includes/js/jquery/ui/selectmenu.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1484","static_file","/wp-includes/js/jquery/ui/slider.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1485","static_file","/wp-includes/js/jquery/ui/slider.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1486","static_file","/wp-includes/js/jquery/ui/sortable.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1487","static_file","/wp-includes/js/jquery/ui/sortable.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1488","static_file","/wp-includes/js/jquery/ui/spinner.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1489","static_file","/wp-includes/js/jquery/ui/spinner.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1490","static_file","/wp-includes/js/jquery/ui/tabs.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1491","static_file","/wp-includes/js/jquery/ui/tabs.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1492","static_file","/wp-includes/js/jquery/ui/tooltip.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 06:04:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1493","static_file","/wp-includes/js/jquery/ui/tooltip.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1494","static_file","/wp-includes/js/jquery/jquery-migrate.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:56","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1495","static_file","/wp-includes/js/jquery/jquery-migrate.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:56","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1496","static_file","/wp-includes/js/jquery/jquery.color.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-02-01 01:22:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1497","static_file","/wp-includes/js/jquery/jquery.form.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 05:53:20","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1498","static_file","/wp-includes/js/jquery/jquery.form.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1499","static_file","/wp-includes/js/jquery/jquery.hotkeys.js","","","0","1","1","","0000-00-00 00:00:00","","2021-02-23 07:45:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1500","static_file","/wp-includes/js/jquery/jquery.hotkeys.min.js","","","0","1","1","","0000-00-00 00:00:00","","2012-08-23 12:04:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1501","static_file","/wp-includes/js/jquery/jquery.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:56","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1502","static_file","/wp-includes/js/jquery/jquery.masonry.min.js","","","0","1","1","","0000-00-00 00:00:00","","2016-08-18 06:55:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1503","static_file","/wp-includes/js/jquery/jquery.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:56","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1504","static_file","/wp-includes/js/jquery/jquery.query.js","","","0","1","1","","0000-00-00 00:00:00","","2022-03-10 06:54:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1505","static_file","/wp-includes/js/jquery/jquery.schedule.js","","","0","1","1","","0000-00-00 00:00:00","","2008-01-10 05:35:48","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1506","static_file","/wp-includes/js/jquery/jquery.serialize-object.js","","","0","1","1","","0000-00-00 00:00:00","","2021-02-23 07:45:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1507","static_file","/wp-includes/js/jquery/jquery.table-hotkeys.js","","","0","1","1","","0000-00-00 00:00:00","","2021-02-23 07:45:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1508","static_file","/wp-includes/js/jquery/jquery.table-hotkeys.min.js","","","0","1","1","","0000-00-00 00:00:00","","2012-08-23 12:04:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1509","static_file","/wp-includes/js/jquery/jquery.ui.touch-punch.js","","","0","1","1","","0000-00-00 00:00:00","","2012-04-11 02:58:24","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1510","static_file","/wp-includes/js/jquery/suggest.js","","","0","1","1","","0000-00-00 00:00:00","","2016-01-13 05:22:28","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1511","static_file","/wp-includes/js/jquery/suggest.min.js","","","0","1","1","","0000-00-00 00:00:00","","2016-01-13 05:22:28","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1512","static_file","/wp-includes/js/mediaelement/renderers/vimeo.js","","","0","1","1","","0000-00-00 00:00:00","","2020-09-29 03:53:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1513","static_file","/wp-includes/js/mediaelement/renderers/vimeo.min.js","","","0","1","1","","0000-00-00 00:00:00","","2020-09-29 03:53:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1514","static_file","/wp-includes/js/mediaelement/mediaelementplayer-legacy.css","","","0","1","1","","0000-00-00 00:00:00","","2019-10-08 04:06:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1515","static_file","/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css","","","0","1","1","","0000-00-00 00:00:00","","2020-09-29 03:53:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1516","static_file","/wp-includes/js/mediaelement/mediaelementplayer.css","","","0","1","1","","0000-00-00 00:00:00","","2019-10-08 04:06:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1517","static_file","/wp-includes/js/mediaelement/mediaelementplayer.min.css","","","0","1","1","","0000-00-00 00:00:00","","2020-09-29 03:53:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1518","static_file","/wp-includes/js/mediaelement/wp-mediaelement.css","","","0","1","1","","0000-00-00 00:00:00","","2019-06-07 08:45:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1519","static_file","/wp-includes/js/mediaelement/wp-mediaelement.min.css","","","0","1","1","","0000-00-00 00:00:00","","2019-06-07 08:45:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1520","static_file","/wp-includes/js/mediaelement/mediaelement-and-player.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-29 02:21:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1521","static_file","/wp-includes/js/mediaelement/mediaelement-and-player.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-29 02:21:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1522","static_file","/wp-includes/js/mediaelement/mediaelement-migrate.js","","","0","1","1","","0000-00-00 00:00:00","","2017-10-16 06:07:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1523","static_file","/wp-includes/js/mediaelement/mediaelement-migrate.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1524","static_file","/wp-includes/js/mediaelement/mediaelement.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-29 02:21:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1525","static_file","/wp-includes/js/mediaelement/mediaelement.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-29 02:21:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1526","static_file","/wp-includes/js/mediaelement/wp-mediaelement.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 04:00:42","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1527","static_file","/wp-includes/js/mediaelement/wp-mediaelement.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-07 04:00:42","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1528","static_file","/wp-includes/js/mediaelement/wp-playlist.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-21 03:30:14","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1529","static_file","/wp-includes/js/mediaelement/wp-playlist.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-21 03:30:14","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1530","static_file","/wp-includes/js/mediaelement/mejs-controls.png","","","0","1","1","","0000-00-00 00:00:00","","2017-08-01 04:43:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1531","static_file","/wp-includes/js/mediaelement/mejs-controls.svg","","","0","1","1","","0000-00-00 00:00:00","","2017-08-01 04:43:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1532","static_file","/wp-includes/js/plupload/license.txt","","","0","1","1","","0000-00-00 00:00:00","","2019-11-03 05:09:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1533","static_file","/wp-includes/js/plupload/handlers.js","","","0","1","1","","0000-00-00 00:00:00","","2022-10-11 05:37:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1534","static_file","/wp-includes/js/plupload/handlers.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-10-11 05:37:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1535","static_file","/wp-includes/js/plupload/moxie.js","","","0","1","1","","0000-00-00 00:00:00","","2019-11-03 05:09:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1536","static_file","/wp-includes/js/plupload/moxie.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1537","static_file","/wp-includes/js/plupload/plupload.js","","","0","1","1","","0000-00-00 00:00:00","","2019-11-03 05:09:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1538","static_file","/wp-includes/js/plupload/plupload.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1539","static_file","/wp-includes/js/plupload/wp-plupload.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-06 09:13:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1540","static_file","/wp-includes/js/plupload/wp-plupload.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1541","static_file","/wp-includes/js/swfupload/license.txt","","","0","1","1","","0000-00-00 00:00:00","","2011-07-29 07:21:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1542","static_file","/wp-includes/js/swfupload/handlers.js","","","0","1","1","","0000-00-00 00:00:00","","2017-09-21 04:35:48","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1543","static_file","/wp-includes/js/swfupload/handlers.min.js","","","0","1","1","","0000-00-00 00:00:00","","2017-09-21 04:35:48","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1544","static_file","/wp-includes/js/swfupload/swfupload.js","","","0","1","1","","0000-00-00 00:00:00","","2017-09-21 04:35:48","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1545","static_file","/wp-includes/js/thickbox/thickbox.css","","","0","1","1","","0000-00-00 00:00:00","","2020-10-26 02:25:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1546","static_file","/wp-includes/js/thickbox/thickbox.js","","","0","1","1","","0000-00-00 00:00:00","","2022-05-30 02:53:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1547","static_file","/wp-includes/js/thickbox/loadingAnimation.gif","","","0","1","1","","0000-00-00 00:00:00","","2012-11-05 09:00:16","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1548","static_file","/wp-includes/js/thickbox/macFFBgHack.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1549","static_file","/wp-includes/js/tinymce/langs/wp-langs-en.js","","","0","1","1","","0000-00-00 00:00:00","","2022-02-27 10:49:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1550","static_file","/wp-includes/js/tinymce/plugins/charmap/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2019-01-29 08:19:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1551","static_file","/wp-includes/js/tinymce/plugins/charmap/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2018-04-25 10:35:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1552","static_file","/wp-includes/js/tinymce/plugins/colorpicker/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2019-01-29 08:19:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1553","static_file","/wp-includes/js/tinymce/plugins/colorpicker/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2018-04-25 10:35:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1554","static_file","/wp-includes/js/tinymce/plugins/compat3x/css/dialog.css","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1555","static_file","/wp-includes/js/tinymce/plugins/compat3x/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1556","static_file","/wp-includes/js/tinymce/plugins/compat3x/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2018-04-25 10:35:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1557","static_file","/wp-includes/js/tinymce/plugins/directionality/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2019-01-29 08:19:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1558","static_file","/wp-includes/js/tinymce/plugins/directionality/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2018-04-25 10:35:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1559","static_file","/wp-includes/js/tinymce/plugins/fullscreen/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2019-05-15 11:45:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1560","static_file","/wp-includes/js/tinymce/plugins/fullscreen/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2019-05-15 11:45:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1561","static_file","/wp-includes/js/tinymce/plugins/hr/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2019-01-29 08:19:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1562","static_file","/wp-includes/js/tinymce/plugins/hr/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2018-04-25 10:35:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1563","static_file","/wp-includes/js/tinymce/plugins/image/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2019-09-19 01:00:58","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1564","static_file","/wp-includes/js/tinymce/plugins/image/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2019-09-19 01:00:58","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1565","static_file","/wp-includes/js/tinymce/plugins/link/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2019-05-15 11:45:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1566","static_file","/wp-includes/js/tinymce/plugins/link/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2019-05-15 11:45:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1567","static_file","/wp-includes/js/tinymce/plugins/lists/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1568","static_file","/wp-includes/js/tinymce/plugins/lists/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1569","static_file","/wp-includes/js/tinymce/plugins/media/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1570","static_file","/wp-includes/js/tinymce/plugins/media/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1571","static_file","/wp-includes/js/tinymce/plugins/paste/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1572","static_file","/wp-includes/js/tinymce/plugins/paste/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1573","static_file","/wp-includes/js/tinymce/plugins/tabfocus/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2019-05-15 11:45:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1574","static_file","/wp-includes/js/tinymce/plugins/tabfocus/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2019-05-15 11:45:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1575","static_file","/wp-includes/js/tinymce/plugins/textcolor/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2019-01-29 08:19:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1576","static_file","/wp-includes/js/tinymce/plugins/textcolor/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2019-01-29 08:19:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1577","static_file","/wp-includes/js/tinymce/plugins/wordpress/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-01 11:09:08","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1578","static_file","/wp-includes/js/tinymce/plugins/wordpress/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1579","static_file","/wp-includes/js/tinymce/plugins/wpautoresize/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2020-01-29 12:45:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1580","static_file","/wp-includes/js/tinymce/plugins/wpautoresize/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1581","static_file","/wp-includes/js/tinymce/plugins/wpdialogs/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2020-01-29 12:45:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1582","static_file","/wp-includes/js/tinymce/plugins/wpdialogs/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 07:49:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1583","static_file","/wp-includes/js/tinymce/plugins/wpeditimage/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2020-01-29 12:45:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1584","static_file","/wp-includes/js/tinymce/plugins/wpeditimage/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1585","static_file","/wp-includes/js/tinymce/plugins/wpemoji/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2020-01-29 12:45:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1586","static_file","/wp-includes/js/tinymce/plugins/wpemoji/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1587","static_file","/wp-includes/js/tinymce/plugins/wpgallery/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2020-01-29 12:45:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1588","static_file","/wp-includes/js/tinymce/plugins/wpgallery/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1589","static_file","/wp-includes/js/tinymce/plugins/wplink/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2020-01-29 12:45:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1590","static_file","/wp-includes/js/tinymce/plugins/wplink/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1591","static_file","/wp-includes/js/tinymce/plugins/wptextpattern/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-20 12:58:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1592","static_file","/wp-includes/js/tinymce/plugins/wptextpattern/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1593","static_file","/wp-includes/js/tinymce/plugins/wpview/plugin.js","","","0","1","1","","0000-00-00 00:00:00","","2020-01-29 12:45:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1594","static_file","/wp-includes/js/tinymce/plugins/wpview/plugin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1595","static_file","/wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.ttf","","","0","1","1","","0000-00-00 00:00:00","","2016-01-20 04:18:34","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1596","static_file","/wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.ttf","","","0","1","1","","0000-00-00 00:00:00","","2019-01-30 10:07:50","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1597","static_file","/wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.woff","","","0","1","1","","0000-00-00 00:00:00","","2016-01-20 04:18:34","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1598","static_file","/wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.woff","","","0","1","1","","0000-00-00 00:00:00","","2019-01-30 10:07:50","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1599","static_file","/wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.eot","","","0","1","1","","0000-00-00 00:00:00","","2016-01-20 04:18:34","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1600","static_file","/wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.eot","","","0","1","1","","0000-00-00 00:00:00","","2019-01-30 10:07:50","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1601","static_file","/wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.svg","","","0","1","1","","0000-00-00 00:00:00","","2016-06-29 01:21:28","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1602","static_file","/wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.svg","","","0","1","1","","0000-00-00 00:00:00","","2019-01-29 08:19:52","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1603","static_file","/wp-includes/js/tinymce/skins/lightgray/img/anchor.gif","","","0","1","1","","0000-00-00 00:00:00","","2013-12-28 11:53:16","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1604","static_file","/wp-includes/js/tinymce/skins/lightgray/img/loader.gif","","","0","1","1","","0000-00-00 00:00:00","","2013-12-28 11:53:16","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1605","static_file","/wp-includes/js/tinymce/skins/lightgray/img/object.gif","","","0","1","1","","0000-00-00 00:00:00","","2013-12-28 11:53:16","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1606","static_file","/wp-includes/js/tinymce/skins/lightgray/img/trans.gif","","","0","1","1","","0000-00-00 00:00:00","","2013-12-28 11:53:16","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1607","static_file","/wp-includes/js/tinymce/skins/lightgray/content.inline.min.css","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1608","static_file","/wp-includes/js/tinymce/skins/lightgray/content.min.css","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1609","static_file","/wp-includes/js/tinymce/skins/lightgray/skin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1610","static_file","/wp-includes/js/tinymce/skins/wordpress/images/audio.png","","","0","1","1","","0000-00-00 00:00:00","","2014-02-13 08:03:14","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1611","static_file","/wp-includes/js/tinymce/skins/wordpress/images/dashicon-edit.png","","","0","1","1","","0000-00-00 00:00:00","","2014-12-02 12:26:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1612","static_file","/wp-includes/js/tinymce/skins/wordpress/images/dashicon-no.png","","","0","1","1","","0000-00-00 00:00:00","","2014-12-02 12:26:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1613","static_file","/wp-includes/js/tinymce/skins/wordpress/images/embedded.png","","","0","1","1","","0000-00-00 00:00:00","","2014-11-25 02:09:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1614","static_file","/wp-includes/js/tinymce/skins/wordpress/images/gallery-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-02-13 08:03:14","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1615","static_file","/wp-includes/js/tinymce/skins/wordpress/images/gallery.png","","","0","1","1","","0000-00-00 00:00:00","","2014-02-13 08:03:14","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1616","static_file","/wp-includes/js/tinymce/skins/wordpress/images/more-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1617","static_file","/wp-includes/js/tinymce/skins/wordpress/images/more.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1618","static_file","/wp-includes/js/tinymce/skins/wordpress/images/pagebreak-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-04-04 05:23:14","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1619","static_file","/wp-includes/js/tinymce/skins/wordpress/images/pagebreak.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1620","static_file","/wp-includes/js/tinymce/skins/wordpress/images/playlist-audio.png","","","0","1","1","","0000-00-00 00:00:00","","2014-03-05 03:54:16","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1621","static_file","/wp-includes/js/tinymce/skins/wordpress/images/playlist-video.png","","","0","1","1","","0000-00-00 00:00:00","","2014-03-05 03:54:16","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1622","static_file","/wp-includes/js/tinymce/skins/wordpress/images/video.png","","","0","1","1","","0000-00-00 00:00:00","","2014-02-13 08:03:14","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1623","static_file","/wp-includes/js/tinymce/skins/wordpress/wp-content.css","","","0","1","1","","0000-00-00 00:00:00","","2020-01-26 11:02:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1624","static_file","/wp-includes/js/tinymce/themes/inlite/theme.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1625","static_file","/wp-includes/js/tinymce/themes/inlite/theme.min.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1626","static_file","/wp-includes/js/tinymce/themes/modern/theme.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1627","static_file","/wp-includes/js/tinymce/themes/modern/theme.min.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-24 10:06:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1628","static_file","/wp-includes/js/tinymce/utils/editable_selects.js","","","0","1","1","","0000-00-00 00:00:00","","2017-05-08 05:32:46","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1629","static_file","/wp-includes/js/tinymce/utils/form_utils.js","","","0","1","1","","0000-00-00 00:00:00","","2017-05-08 05:32:46","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1630","static_file","/wp-includes/js/tinymce/utils/mctabs.js","","","0","1","1","","0000-00-00 00:00:00","","2017-09-26 09:15:48","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1631","static_file","/wp-includes/js/tinymce/utils/validate.js","","","0","1","1","","0000-00-00 00:00:00","","2018-04-25 10:35:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1632","static_file","/wp-includes/js/tinymce/license.txt","","","0","1","1","","0000-00-00 00:00:00","","2017-05-08 05:32:46","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1633","static_file","/wp-includes/js/tinymce/tiny_mce_popup.js","","","0","1","1","","0000-00-00 00:00:00","","2017-09-26 09:15:48","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1634","static_file","/wp-includes/js/tinymce/tinymce.min.js","","","0","1","1","","0000-00-00 00:00:00","","2020-11-10 10:44:08","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1635","static_file","/wp-includes/js/tinymce/wp-tinymce.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1636","static_file","/wp-includes/js/admin-bar.js","","","0","1","1","","0000-00-00 00:00:00","","2020-07-27 11:35:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1637","static_file","/wp-includes/js/admin-bar.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1638","static_file","/wp-includes/js/api-request.js","","","0","1","1","","0000-00-00 00:00:00","","2020-12-01 03:44:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1639","static_file","/wp-includes/js/api-request.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1640","static_file","/wp-includes/js/autosave.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1641","static_file","/wp-includes/js/autosave.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1642","static_file","/wp-includes/js/backbone.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-12 05:17:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1643","static_file","/wp-includes/js/backbone.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1644","static_file","/wp-includes/js/clipboard.js","","","0","1","1","","0000-00-00 00:00:00","","2022-10-04 03:55:24","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1645","static_file","/wp-includes/js/clipboard.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-10-04 03:55:24","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1646","static_file","/wp-includes/js/colorpicker.js","","","0","1","1","","0000-00-00 00:00:00","","2012-11-17 03:11:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1647","static_file","/wp-includes/js/colorpicker.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1648","static_file","/wp-includes/js/comment-reply.js","","","0","1","1","","0000-00-00 00:00:00","","2023-01-10 09:30:14","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1649","static_file","/wp-includes/js/comment-reply.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1650","static_file","/wp-includes/js/customize-base.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:56","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1651","static_file","/wp-includes/js/customize-base.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1652","static_file","/wp-includes/js/customize-loader.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-20 12:58:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1653","static_file","/wp-includes/js/customize-loader.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1654","static_file","/wp-includes/js/customize-models.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-25 12:43:08","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1655","static_file","/wp-includes/js/customize-models.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1656","static_file","/wp-includes/js/customize-preview-nav-menus.js","","","0","1","1","","0000-00-00 00:00:00","","2020-07-27 11:35:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1657","static_file","/wp-includes/js/customize-preview-nav-menus.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1658","static_file","/wp-includes/js/customize-preview-widgets.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-20 12:58:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1659","static_file","/wp-includes/js/customize-preview-widgets.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1660","static_file","/wp-includes/js/customize-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2020-07-27 11:35:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1661","static_file","/wp-includes/js/customize-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1662","static_file","/wp-includes/js/customize-selective-refresh.js","","","0","1","1","","0000-00-00 00:00:00","","2020-07-28 12:07:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1663","static_file","/wp-includes/js/customize-selective-refresh.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1664","static_file","/wp-includes/js/customize-views.js","","","0","1","1","","0000-00-00 00:00:00","","2018-06-28 02:30:16","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1665","static_file","/wp-includes/js/customize-views.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-01-06 03:29:24","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1666","static_file","/wp-includes/js/heartbeat.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-20 05:55:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1667","static_file","/wp-includes/js/heartbeat.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1668","static_file","/wp-includes/js/hoverIntent.js","","","0","1","1","","0000-00-00 00:00:00","","2022-01-03 03:03:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1669","static_file","/wp-includes/js/hoverIntent.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1670","static_file","/wp-includes/js/hoverintent-js.min.js","","","0","1","1","","0000-00-00 00:00:00","","2019-12-10 01:03:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1671","static_file","/wp-includes/js/imagesloaded.min.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-13 06:53:28","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1672","static_file","/wp-includes/js/json2.js","","","0","1","1","","0000-00-00 00:00:00","","2015-10-06 02:02:26","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1673","static_file","/wp-includes/js/json2.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1674","static_file","/wp-includes/js/masonry.min.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-13 06:53:28","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1675","static_file","/wp-includes/js/mce-view.js","","","0","1","1","","0000-00-00 00:00:00","","2020-07-27 11:35:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1676","static_file","/wp-includes/js/mce-view.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1677","static_file","/wp-includes/js/media-audiovideo.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-16 02:50:20","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1678","static_file","/wp-includes/js/media-audiovideo.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-16 02:50:20","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1679","static_file","/wp-includes/js/media-editor.js","","","0","1","1","","0000-00-00 00:00:00","","2020-07-27 11:35:02","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1680","static_file","/wp-includes/js/media-editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1681","static_file","/wp-includes/js/media-grid.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 12:04:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1682","static_file","/wp-includes/js/media-grid.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1683","static_file","/wp-includes/js/media-models.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-11 12:04:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1684","static_file","/wp-includes/js/media-models.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1685","static_file","/wp-includes/js/media-views.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-09 12:07:26","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1686","static_file","/wp-includes/js/media-views.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-09 12:07:26","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1687","static_file","/wp-includes/js/quicktags.js","","","0","1","1","","0000-00-00 00:00:00","","2021-09-08 11:29:58","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1688","static_file","/wp-includes/js/quicktags.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1689","static_file","/wp-includes/js/shortcode.js","","","0","1","1","","0000-00-00 00:00:00","","2020-01-29 12:45:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1690","static_file","/wp-includes/js/shortcode.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1691","static_file","/wp-includes/js/swfobject.js","","","0","1","1","","0000-00-00 00:00:00","","2012-04-17 11:09:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1692","static_file","/wp-includes/js/tw-sack.js","","","0","1","1","","0000-00-00 00:00:00","","2012-08-23 12:04:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1693","static_file","/wp-includes/js/tw-sack.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1694","static_file","/wp-includes/js/twemoji.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 12:53:26","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1695","static_file","/wp-includes/js/twemoji.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 12:53:26","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1696","static_file","/wp-includes/js/underscore.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-27 03:18:26","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1697","static_file","/wp-includes/js/underscore.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-27 03:18:26","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1698","static_file","/wp-includes/js/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2020-01-29 12:45:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1699","static_file","/wp-includes/js/utils.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1700","static_file","/wp-includes/js/wp-ajax-response.js","","","0","1","1","","0000-00-00 00:00:00","","2022-07-16 01:08:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1701","static_file","/wp-includes/js/wp-ajax-response.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1702","static_file","/wp-includes/js/wp-api.js","","","0","1","1","","0000-00-00 00:00:00","","2023-01-10 09:30:14","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1703","static_file","/wp-includes/js/wp-api.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1704","static_file","/wp-includes/js/wp-auth-check.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1705","static_file","/wp-includes/js/wp-auth-check.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1706","static_file","/wp-includes/js/wp-backbone.js","","","0","1","1","","0000-00-00 00:00:00","","2020-06-20 12:58:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1707","static_file","/wp-includes/js/wp-backbone.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1708","static_file","/wp-includes/js/wp-custom-header.js","","","0","1","1","","0000-00-00 00:00:00","","2021-04-10 12:40:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1709","static_file","/wp-includes/js/wp-custom-header.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1710","static_file","/wp-includes/js/wp-embed-template.js","","","0","1","1","","0000-00-00 00:00:00","","2021-11-11 02:49:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1711","static_file","/wp-includes/js/wp-embed-template.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1712","static_file","/wp-includes/js/wp-embed.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-16 02:48:20","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1713","static_file","/wp-includes/js/wp-embed.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-05-16 02:48:20","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1714","static_file","/wp-includes/js/wp-emoji-loader.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:56","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1715","static_file","/wp-includes/js/wp-emoji-loader.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:56","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1716","static_file","/wp-includes/js/wp-emoji-release.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 12:53:26","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1717","static_file","/wp-includes/js/wp-emoji.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 12:53:26","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1718","static_file","/wp-includes/js/wp-emoji.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 12:53:26","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1719","static_file","/wp-includes/js/wp-list-revisions.js","","","0","1","1","","0000-00-00 00:00:00","","2018-06-28 02:30:16","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1720","static_file","/wp-includes/js/wp-list-revisions.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-01-06 03:29:24","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1721","static_file","/wp-includes/js/wp-lists.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:56","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1722","static_file","/wp-includes/js/wp-lists.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:56","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1723","static_file","/wp-includes/js/wp-pointer.js","","","0","1","1","","0000-00-00 00:00:00","","2021-02-16 08:25:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1724","static_file","/wp-includes/js/wp-pointer.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1725","static_file","/wp-includes/js/wp-sanitize.js","","","0","1","1","","0000-00-00 00:00:00","","2019-09-04 05:13:22","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1726","static_file","/wp-includes/js/wp-sanitize.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1727","static_file","/wp-includes/js/wp-util.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-20 03:52:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1728","static_file","/wp-includes/js/wp-util.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-20 03:52:10","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1729","static_file","/wp-includes/js/wpdialog.js","","","0","1","1","","0000-00-00 00:00:00","","2023-01-24 09:13:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1730","static_file","/wp-includes/js/wpdialog.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-01-24 09:13:12","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1731","static_file","/wp-includes/js/wplink.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1732","static_file","/wp-includes/js/wplink.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1733","static_file","/wp-includes/js/zxcvbn-async.js","","","0","1","1","","0000-00-00 00:00:00","","2018-06-28 02:30:16","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1734","static_file","/wp-includes/js/zxcvbn-async.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-02-23 04:45:20","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1735","static_file","/wp-includes/js/zxcvbn.min.js","","","0","1","1","","0000-00-00 00:00:00","","2019-10-26 12:17:08","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1736","static_file","/wp-content/ai1wm-backups/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 11:37:48","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1737","static_file","/wp-content/ai1wm-backups/robots.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 11:37:48","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1738","static_file","/wp-content/plugins/astra-sites/admin/bsf-analytics/assets/css/minified/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1739","static_file","/wp-content/plugins/astra-sites/admin/bsf-analytics/assets/css/minified/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1740","static_file","/wp-content/plugins/astra-sites/admin/bsf-analytics/assets/css/unminified/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1741","static_file","/wp-content/plugins/astra-sites/admin/bsf-analytics/assets/css/unminified/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1742","static_file","/wp-content/plugins/astra-sites/assets/css/admin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1743","static_file","/wp-content/plugins/astra-sites/assets/css/astra-notices-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1744","static_file","/wp-content/plugins/astra-sites/assets/css/astra-notices.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1745","static_file","/wp-content/plugins/astra-sites/assets/js/admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1746","static_file","/wp-content/plugins/astra-sites/inc/assets/css/admin-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1747","static_file","/wp-content/plugins/astra-sites/inc/assets/css/admin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1748","static_file","/wp-content/plugins/astra-sites/inc/assets/css/elementor-admin-common-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1749","static_file","/wp-content/plugins/astra-sites/inc/assets/css/elementor-admin-common.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1750","static_file","/wp-content/plugins/astra-sites/inc/assets/css/elementor-admin-dark-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1751","static_file","/wp-content/plugins/astra-sites/inc/assets/css/elementor-admin-dark.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1752","static_file","/wp-content/plugins/astra-sites/inc/assets/css/elementor-admin-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1753","static_file","/wp-content/plugins/astra-sites/inc/assets/css/elementor-admin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1754","static_file","/wp-content/plugins/astra-sites/inc/assets/css/images-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1755","static_file","/wp-content/plugins/astra-sites/inc/assets/css/images.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1756","static_file","/wp-content/plugins/astra-sites/inc/assets/css/import-status-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1757","static_file","/wp-content/plugins/astra-sites/inc/assets/css/import-status.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1758","static_file","/wp-content/plugins/astra-sites/inc/assets/css/integration-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1759","static_file","/wp-content/plugins/astra-sites/inc/assets/css/integration.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1760","static_file","/wp-content/plugins/astra-sites/inc/assets/fonts/astra-sites.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1761","static_file","/wp-content/plugins/astra-sites/inc/assets/fonts/astra-sites.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1762","static_file","/wp-content/plugins/astra-sites/inc/assets/fonts/astra-sites.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1763","static_file","/wp-content/plugins/astra-sites/inc/assets/fonts/astra-sites.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1764","static_file","/wp-content/plugins/astra-sites/inc/assets/images/block-editor.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1765","static_file","/wp-content/plugins/astra-sites/inc/assets/images/pixabay-logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1766","static_file","/wp-content/plugins/astra-sites/inc/assets/images/placeholder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1767","static_file","/wp-content/plugins/astra-sites/inc/assets/images/templates-showcase.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1768","static_file","/wp-content/plugins/astra-sites/inc/assets/images/welcome.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1769","static_file","/wp-content/plugins/astra-sites/inc/assets/images/beaver-builder.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1770","static_file","/wp-content/plugins/astra-sites/inc/assets/images/brizy.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1771","static_file","/wp-content/plugins/astra-sites/inc/assets/images/elementor.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1772","static_file","/wp-content/plugins/astra-sites/inc/assets/images/gutenberg.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1773","static_file","/wp-content/plugins/astra-sites/inc/assets/images/starter-template-3-banner-image-background.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1774","static_file","/wp-content/plugins/astra-sites/inc/assets/images/arrow-blue.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1775","static_file","/wp-content/plugins/astra-sites/inc/assets/images/cross.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1776","static_file","/wp-content/plugins/astra-sites/inc/assets/images/dashicons-building.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1777","static_file","/wp-content/plugins/astra-sites/inc/assets/images/dashicons-cart.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1778","static_file","/wp-content/plugins/astra-sites/inc/assets/images/dashicons-megaphone.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1779","static_file","/wp-content/plugins/astra-sites/inc/assets/images/dashicons-welcome-write-blog.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1780","static_file","/wp-content/plugins/astra-sites/inc/assets/images/empty-collection.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1781","static_file","/wp-content/plugins/astra-sites/inc/assets/images/logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1782","static_file","/wp-content/plugins/astra-sites/inc/assets/images/premium-crown.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1783","static_file","/wp-content/plugins/astra-sites/inc/assets/images/quick-link-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:37","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1784","static_file","/wp-content/plugins/astra-sites/inc/assets/js/dist/main.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1785","static_file","/wp-content/plugins/astra-sites/inc/assets/js/src/content.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1786","static_file","/wp-content/plugins/astra-sites/inc/assets/js/src/frame.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1787","static_file","/wp-content/plugins/astra-sites/inc/assets/js/src/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1788","static_file","/wp-content/plugins/astra-sites/inc/assets/js/src/search.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1789","static_file","/wp-content/plugins/astra-sites/inc/assets/js/common.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1790","static_file","/wp-content/plugins/astra-sites/inc/assets/js/elementor-admin-page.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1791","static_file","/wp-content/plugins/astra-sites/inc/assets/js/eventsource.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1792","static_file","/wp-content/plugins/astra-sites/inc/assets/js/eventsource.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1793","static_file","/wp-content/plugins/astra-sites/inc/assets/js/fetch.umd.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1794","static_file","/wp-content/plugins/astra-sites/inc/assets/js/helper.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1795","static_file","/wp-content/plugins/astra-sites/inc/assets/js/history.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1796","static_file","/wp-content/plugins/astra-sites/inc/assets/js/import-status.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1797","static_file","/wp-content/plugins/astra-sites/inc/assets/js/install-theme.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1798","static_file","/wp-content/plugins/astra-sites/inc/config/paths.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1799","static_file","/wp-content/plugins/astra-sites/inc/config/webpack.config.dev.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1800","static_file","/wp-content/plugins/astra-sites/inc/config/webpack.config.prod.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:38","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1801","static_file","/wp-content/plugins/astra-sites/inc/lib/astra-notices/notices.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:42","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1802","static_file","/wp-content/plugins/astra-sites/inc/lib/astra-notices/notices.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:42","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1803","static_file","/wp-content/plugins/astra-sites/inc/lib/bsf-quick-links/quicklink.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:42","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1804","static_file","/wp-content/plugins/astra-sites/inc/lib/bsf-quick-links/quicklinks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:42","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1805","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/fonts/ast-block-templates.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:42","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1806","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/fonts/ast-block-templates.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:42","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1807","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/fonts/ast-block-templates.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:42","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1808","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/fonts/ast-block-templates.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:42","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1809","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:42","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1810","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/main.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:43","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1811","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:43","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1812","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/main.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:43","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1813","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/placeholder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:43","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1814","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/placeholder_200_200.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:43","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1815","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/aspect-ratio.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:42","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1816","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:43","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1817","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/spectra-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:43","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1818","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/spectra.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:43","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1819","static_file","/wp-content/plugins/astra-sites/inc/lib/gutenberg-templates/dist/starter-template-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:43","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1820","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/dist/style-main-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1821","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/dist/style-main.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1822","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/dist/main.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1823","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/images/placeholder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1824","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/images/spectra-placeholder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1825","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/images/beaver-builder.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1826","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/images/block-editor.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1827","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/images/brizy.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1828","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/images/elementor.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1829","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/images/get-access.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1830","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/images/logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1831","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/images/surecart-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1832","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/images/woocommerce-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1833","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/button/button.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1834","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/change-template/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1835","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/choose-ecommerce/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1836","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/color-palettes/color-palettes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1837","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/customizer-step/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1838","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/default-step/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1839","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/error/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1840","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/exist-to-dashboard/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1841","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/font-selector/font-selector.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1842","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/import-steps/import-loader.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1843","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/logo/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1844","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/media-uploader/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1845","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/site-preview/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1846","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/site-preview/site-skeleton.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1847","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/site-preview/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1848","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/util/next-step-button/next-step-button.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1849","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/util/next-step-link/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1850","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/util/previous-step-button/previous-step-button.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1851","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/util/previous-step-link/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1852","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/components/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1853","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/congrats/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1854","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/customize-steps/business-logo/controls.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1855","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/customize-steps/business-logo/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1856","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/customize-steps/ecommerce-selections/controls.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1857","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/customize-steps/ecommerce-selections/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1858","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/customize-steps/license-validation/controls.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1859","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/customize-steps/license-validation/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1860","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/customize-steps/site-colors-typography/colors.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1861","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/customize-steps/site-colors-typography/controls.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1862","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/customize-steps/site-colors-typography/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1863","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/customize-steps/site-colors-typography/other-fonts.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1864","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/customize-steps/site-colors-typography/typography.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1865","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/customize-steps/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1866","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/customize-site/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1867","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/import-site/import-utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1868","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/import-site/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1869","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/import-site/sse-import.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1870","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/page-builder/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1871","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/favorite-sites/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1872","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/header/my-favorite/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1873","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/header/sync-library/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1874","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/header/sync-library/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1875","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/header/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1876","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/no-favorite-sites/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1877","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/page-builder-filter/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1878","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/related-sites/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1879","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/search-filter/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1880","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/site-category-filter/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1881","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/sites-grid/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1882","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/grid-skeleton.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1883","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1884","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/site-list/site-list-skeleton.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1885","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/survey-loading/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1886","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/survey/advanced-settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1887","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/survey/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1888","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/survey/survey.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1889","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/welcome/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1890","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1891","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/steps/util.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1892","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/store/reducer.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1893","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/store/store.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1894","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/ui/style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1895","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/utils/add-trailing-slash.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1896","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/utils/functions.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1897","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/utils/prepend-https.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1898","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/utils/search.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1899","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/utils/strip-slashes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1900","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/utils/url-params.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1901","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/api.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1902","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/app.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1903","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1904","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/src/wordpress-rest-api-cookie-auth.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1905","static_file","/wp-content/plugins/astra-sites/inc/lib/onboarding/assets/icons.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:44","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1906","static_file","/wp-content/plugins/astra-sites/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1907","static_file","/wp-content/plugins/astra-sites/webpack.config.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:45","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1908","static_file","/wp-content/plugins/cartflows/admin-core/assets/build/editor-app-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1909","static_file","/wp-content/plugins/cartflows/admin-core/assets/build/editor-app.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1910","static_file","/wp-content/plugins/cartflows/admin-core/assets/build/settings-app-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1911","static_file","/wp-content/plugins/cartflows/admin-core/assets/build/settings-app.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1912","static_file","/wp-content/plugins/cartflows/admin-core/assets/build/editor-app.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:04","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1913","static_file","/wp-content/plugins/cartflows/admin-core/assets/build/settings-app.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1914","static_file","/wp-content/plugins/cartflows/admin-core/assets/css/common-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1915","static_file","/wp-content/plugins/cartflows/admin-core/assets/css/common.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1916","static_file","/wp-content/plugins/cartflows/admin-core/assets/css/header-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1917","static_file","/wp-content/plugins/cartflows/admin-core/assets/css/header.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1918","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/icons/cartFlows-flow-icons.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1919","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/icons/cartflows-logo-icon.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1920","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/icons/cartFlows-flow-icons.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1921","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/icons/cartflows-logo-icon.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1922","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/icons/cartFlows-flow-icons.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1923","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/icons/cartflows-logo-icon.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1924","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/icons/cartFlows-flow-icons.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1925","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/icons/cartflows-logo-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1926","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/roboto-bold-webfont.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1927","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/roboto-medium-webfont.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1928","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/roboto-regular-webfont.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1929","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/roboto-bold-webfont.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1930","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/roboto-medium-webfont.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1931","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/roboto-regular-webfont.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1932","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/roboto-bold-webfont.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1933","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/roboto-medium-webfont.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1934","static_file","/wp-content/plugins/cartflows/admin-core/assets/fonts/roboto-regular-webfont.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1935","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/arrow.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1936","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/image-placeholder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1937","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/cart.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1938","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/cartflows-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1939","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/cf-emblem.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1940","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/checkout_step.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1941","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/conditional.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1942","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/downsell_step.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1943","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/email.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1944","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/landing_step.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1945","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/optin_step.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1946","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/payment.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1947","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/store.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1948","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/thankyou_step.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1949","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/upsell_step.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1950","static_file","/wp-content/plugins/cartflows/admin-core/assets/images/wcf-loader.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:05","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1951","static_file","/wp-content/plugins/cartflows/admin-core/assets/js/common.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1952","static_file","/wp-content/plugins/cartflows/admin/assets/css/admin-embed-header-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1953","static_file","/wp-content/plugins/cartflows/admin/assets/css/admin-embed-header.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1954","static_file","/wp-content/plugins/cartflows/admin/assets/css/admin-widget-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1955","static_file","/wp-content/plugins/cartflows/admin/assets/css/admin-widget.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1956","static_file","/wp-content/plugins/cartflows/admin/assets/css/notices-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1957","static_file","/wp-content/plugins/cartflows/admin/assets/css/notices.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1958","static_file","/wp-content/plugins/cartflows/admin/assets/css/setup-wizard-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1959","static_file","/wp-content/plugins/cartflows/admin/assets/css/setup-wizard.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1960","static_file","/wp-content/plugins/cartflows/admin/assets/css/arrow.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1961","static_file","/wp-content/plugins/cartflows/admin/assets/fonts/cartflows-logo-icon.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1962","static_file","/wp-content/plugins/cartflows/admin/assets/fonts/cartflows-logo-icon.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1963","static_file","/wp-content/plugins/cartflows/admin/assets/fonts/cartflows-logo-icon.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1964","static_file","/wp-content/plugins/cartflows/admin/assets/fonts/cartflows-logo-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1965","static_file","/wp-content/plugins/cartflows/admin/assets/icons/wcf-loader.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1966","static_file","/wp-content/plugins/cartflows/admin/assets/images/cartflows-home-widget.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1967","static_file","/wp-content/plugins/cartflows/admin/assets/js/product-page.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1968","static_file","/wp-content/plugins/cartflows/admin/assets/js/setup-wizard.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1969","static_file","/wp-content/plugins/cartflows/admin/assets/js/ui-notice.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1970","static_file","/wp-content/plugins/cartflows/admin/bsf-analytics/assets/css/minified/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1971","static_file","/wp-content/plugins/cartflows/admin/bsf-analytics/assets/css/minified/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1972","static_file","/wp-content/plugins/cartflows/admin/bsf-analytics/assets/css/unminified/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1973","static_file","/wp-content/plugins/cartflows/admin/bsf-analytics/assets/css/unminified/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:03","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1974","static_file","/wp-content/plugins/cartflows/assets/css/cartflows-normalize-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1975","static_file","/wp-content/plugins/cartflows/assets/css/cartflows-normalize.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1976","static_file","/wp-content/plugins/cartflows/assets/css/checkout-template-divi-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1977","static_file","/wp-content/plugins/cartflows/assets/css/checkout-template-divi.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1978","static_file","/wp-content/plugins/cartflows/assets/css/checkout-template-flatsome-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1979","static_file","/wp-content/plugins/cartflows/assets/css/checkout-template-flatsome.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1980","static_file","/wp-content/plugins/cartflows/assets/css/checkout-template-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1981","static_file","/wp-content/plugins/cartflows/assets/css/checkout-template-the-seven-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1982","static_file","/wp-content/plugins/cartflows/assets/css/checkout-template-the-seven.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1983","static_file","/wp-content/plugins/cartflows/assets/css/checkout-template.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:32");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1984","static_file","/wp-content/plugins/cartflows/assets/css/frontend-divi-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1985","static_file","/wp-content/plugins/cartflows/assets/css/frontend-divi.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1986","static_file","/wp-content/plugins/cartflows/assets/css/frontend-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1987","static_file","/wp-content/plugins/cartflows/assets/css/frontend.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1988","static_file","/wp-content/plugins/cartflows/assets/css/import-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1989","static_file","/wp-content/plugins/cartflows/assets/css/import.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1990","static_file","/wp-content/plugins/cartflows/assets/css/optin-template-divi-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1991","static_file","/wp-content/plugins/cartflows/assets/css/optin-template-divi.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1992","static_file","/wp-content/plugins/cartflows/assets/css/optin-template-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1993","static_file","/wp-content/plugins/cartflows/assets/css/optin-template.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1994","static_file","/wp-content/plugins/cartflows/assets/elementor-assets/css/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1995","static_file","/wp-content/plugins/cartflows/assets/elementor-assets/fonts/wcf-el.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1996","static_file","/wp-content/plugins/cartflows/assets/elementor-assets/fonts/wcf-el.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1997","static_file","/wp-content/plugins/cartflows/assets/elementor-assets/fonts/wcf-el.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1998","static_file","/wp-content/plugins/cartflows/assets/elementor-assets/fonts/wcf-el.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1999","static_file","/wp-content/plugins/cartflows/assets/fonts/cartflows-icon.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2000","static_file","/wp-content/plugins/cartflows/assets/fonts/cartflows-icon.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/