
INSERT INTO `webtoffee_urls` VALUES
("6001","static_file","/wp-content/plugins/wpforms-lite/assets/images/settings-captcha-addon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6002","static_file","/wp-content/plugins/wpforms-lite/assets/images/settings-email-html.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6003","static_file","/wp-content/plugins/wpforms-lite/assets/images/settings-email-plaintext.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6004","static_file","/wp-content/plugins/wpforms-lite/assets/images/sullie-alt.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6005","static_file","/wp-content/plugins/wpforms-lite/assets/images/sullie-builder-mobile.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6006","static_file","/wp-content/plugins/wpforms-lite/assets/images/sullie-vc.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6007","static_file","/wp-content/plugins/wpforms-lite/assets/images/sullie.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6008","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-feature-icon-1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6009","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-feature-icon-10.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6010","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-feature-icon-2.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6011","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-feature-icon-3.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6012","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-feature-icon-4.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6013","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-feature-icon-5.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6014","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-feature-icon-6.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6015","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-feature-icon-7.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6016","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-feature-icon-8.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6017","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-feature-icon-9.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6018","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-video.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6019","static_file","/wp-content/plugins/wpforms-lite/assets/images/thumbnail-simple-contact-form-template.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6020","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-testimonial-bill.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6021","static_file","/wp-content/plugins/wpforms-lite/assets/images/welcome-testimonial-david.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6022","static_file","/wp-content/plugins/wpforms-lite/assets/images/brand.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6023","static_file","/wp-content/plugins/wpforms-lite/assets/images/check-circle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6024","static_file","/wp-content/plugins/wpforms-lite/assets/images/check-solid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6025","static_file","/wp-content/plugins/wpforms-lite/assets/images/cross-inverse.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6026","static_file","/wp-content/plugins/wpforms-lite/assets/images/cross.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6027","static_file","/wp-content/plugins/wpforms-lite/assets/images/exclamation-circle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6028","static_file","/wp-content/plugins/wpforms-lite/assets/images/exclamation-triangle-orange.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6029","static_file","/wp-content/plugins/wpforms-lite/assets/images/exclamation-triangle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6030","static_file","/wp-content/plugins/wpforms-lite/assets/images/file-code.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6031","static_file","/wp-content/plugins/wpforms-lite/assets/images/icon-file.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6032","static_file","/wp-content/plugins/wpforms-lite/assets/images/icon-wpforms.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6033","static_file","/wp-content/plugins/wpforms-lite/assets/images/search.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6034","static_file","/wp-content/plugins/wpforms-lite/assets/images/settings-captcha-cloudflare.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6035","static_file","/wp-content/plugins/wpforms-lite/assets/images/settings-captcha-hcaptcha.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6036","static_file","/wp-content/plugins/wpforms-lite/assets/images/settings-captcha-none.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6037","static_file","/wp-content/plugins/wpforms-lite/assets/images/settings-captcha-recaptcha.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6038","static_file","/wp-content/plugins/wpforms-lite/assets/images/spinner-white.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6039","static_file","/wp-content/plugins/wpforms-lite/assets/images/spinner.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6040","static_file","/wp-content/plugins/wpforms-lite/assets/images/step-1.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6041","static_file","/wp-content/plugins/wpforms-lite/assets/images/step-2.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6042","static_file","/wp-content/plugins/wpforms-lite/assets/images/step-3.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6043","static_file","/wp-content/plugins/wpforms-lite/assets/images/step-complete.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6044","static_file","/wp-content/plugins/wpforms-lite/assets/images/submit-spin.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6045","static_file","/wp-content/plugins/wpforms-lite/assets/images/times-circle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6046","static_file","/wp-content/plugins/wpforms-lite/assets/images/trash-red.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6047","static_file","/wp-content/plugins/wpforms-lite/assets/images/trash.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6048","static_file","/wp-content/plugins/wpforms-lite/assets/images/zoom.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6049","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin/builder/wpforms-choicesjs.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6050","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin/builder/wpforms-choicesjs.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6051","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/drag-fields.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6052","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/drag-fields.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6053","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/help.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6054","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/help.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6055","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/providers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6056","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/providers.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6057","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/search-fields.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6058","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/search-fields.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6059","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6060","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/settings.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6061","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/setup.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6062","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/setup.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6063","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/templates.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6064","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/builder/templates.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6065","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/challenge/challenge-admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6066","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/challenge/challenge-admin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6067","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/challenge/challenge-builder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6068","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/challenge/challenge-builder.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6069","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/challenge/challenge-core.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6070","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/challenge/challenge-core.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6071","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/challenge/challenge-embed.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6072","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/challenge/challenge-embed.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6073","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/education/core.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6074","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/education/core.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6075","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/fields/content-field.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6076","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/fields/content-field.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6077","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/fields/internal-information-field.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6078","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/fields/internal-information-field.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6079","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/forms/overview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6080","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/forms/overview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6081","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/gutenberg/formselector-legacy.es5.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6082","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/gutenberg/formselector-legacy.es5.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6083","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/gutenberg/formselector-legacy.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6084","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/gutenberg/formselector.es5.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6085","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/gutenberg/formselector.es5.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6086","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/gutenberg/formselector.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6087","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/logger/logger.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6088","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/logger/logger.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6089","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/pages/form-templates.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6090","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/pages/form-templates.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6091","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/pages/mi-analytics.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6092","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/pages/mi-analytics.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6093","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/pages/smtp.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6094","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/pages/smtp.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6095","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/payments/overview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6096","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/payments/overview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6097","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/payments/single.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6098","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/payments/single.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6099","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/form-embed-wizard.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6100","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/form-embed-wizard.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6101","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/form-templates.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6102","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/form-templates.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6103","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/notices.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6104","static_file","/wp-content/plugins/wpforms-lite/assets/js/components/admin/notices.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6105","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/divi/formselector.es5.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6106","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/divi/formselector.es5.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6107","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/divi/formselector.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6108","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/divi/formselector.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6109","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/elementor/editor-modern.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6110","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/elementor/editor-modern.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6111","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/elementor/editor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6112","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/elementor/editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6113","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/elementor/frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6114","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/elementor/frontend.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6115","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/stripe/admin-builder-stripe-card-field.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6116","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/stripe/admin-builder-stripe-card-field.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6117","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/stripe/admin-builder-stripe.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6118","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/stripe/admin-builder-stripe.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6119","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/stripe/admin-settings-stripe.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6120","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/stripe/admin-settings-stripe.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6121","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/stripe/wpforms-stripe-elements.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6122","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/stripe/wpforms-stripe-elements.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6123","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/stripe/wpforms-stripe-payment-element.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6124","static_file","/wp-content/plugins/wpforms-lite/assets/js/integrations/stripe/wpforms-stripe-payment-element.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6125","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin-builder-providers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6126","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin-builder-providers.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6127","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin-builder-utils.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6128","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin-builder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6129","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin-builder.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6130","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin-editor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6131","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin-editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6132","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin-notifications.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6133","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin-notifications.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6134","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin-utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6135","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin-utils.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6136","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6137","static_file","/wp-content/plugins/wpforms-lite/assets/js/admin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:07","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6138","static_file","/wp-content/plugins/wpforms-lite/assets/js/text-limit.es5.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6139","static_file","/wp-content/plugins/wpforms-lite/assets/js/text-limit.es5.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6140","static_file","/wp-content/plugins/wpforms-lite/assets/js/text-limit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6141","static_file","/wp-content/plugins/wpforms-lite/assets/js/utils.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6142","static_file","/wp-content/plugins/wpforms-lite/assets/js/utils.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6143","static_file","/wp-content/plugins/wpforms-lite/assets/js/wpforms-confirmation.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6144","static_file","/wp-content/plugins/wpforms-lite/assets/js/wpforms-confirmation.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6145","static_file","/wp-content/plugins/wpforms-lite/assets/js/wpforms-modern.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6146","static_file","/wp-content/plugins/wpforms-lite/assets/js/wpforms-modern.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6147","static_file","/wp-content/plugins/wpforms-lite/assets/js/wpforms.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6148","static_file","/wp-content/plugins/wpforms-lite/assets/js/wpforms.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6149","static_file","/wp-content/plugins/wpforms-lite/assets/lib/flatpickr/flatpickr.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6150","static_file","/wp-content/plugins/wpforms-lite/assets/lib/flatpickr/flatpickr.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6151","static_file","/wp-content/plugins/wpforms-lite/assets/lib/font-awesome/fonts/fontawesome-webfont.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:09","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6152","static_file","/wp-content/plugins/wpforms-lite/assets/lib/font-awesome/fonts/fontawesome-webfont.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:09","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6153","static_file","/wp-content/plugins/wpforms-lite/assets/lib/font-awesome/fonts/fontawesome-webfont.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:09","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6154","static_file","/wp-content/plugins/wpforms-lite/assets/lib/font-awesome/fonts/fontawesome-webfont.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:09","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6155","static_file","/wp-content/plugins/wpforms-lite/assets/lib/font-awesome/fonts/fontawesome-webfont.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:09","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6156","static_file","/wp-content/plugins/wpforms-lite/assets/lib/font-awesome/font-awesome.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6157","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.confirm/jquery-confirm.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:09","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6158","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.confirm/jquery-confirm.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:09","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6159","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.minicolors/jquery.minicolors.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6160","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.minicolors/jquery.minicolors.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6161","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.timepicker/jquery.timepicker.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6162","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.timepicker/jquery.timepicker.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6163","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.tooltipster/jquery.tooltipster.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6164","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.tooltipster/jquery.tooltipster.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6165","static_file","/wp-content/plugins/wpforms-lite/assets/lib/lity/lity.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6166","static_file","/wp-content/plugins/wpforms-lite/assets/lib/lity/lity.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6167","static_file","/wp-content/plugins/wpforms-lite/assets/lib/chart.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6168","static_file","/wp-content/plugins/wpforms-lite/assets/lib/choices.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:08","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6169","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.conditionals.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:09","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6170","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.inputmask.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6171","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.insert-at-caret.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6172","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.serialize-object.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6173","static_file","/wp-content/plugins/wpforms-lite/assets/lib/jquery.validate.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6174","static_file","/wp-content/plugins/wpforms-lite/assets/lib/list.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6175","static_file","/wp-content/plugins/wpforms-lite/assets/lib/mailcheck.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6176","static_file","/wp-content/plugins/wpforms-lite/assets/lib/md5.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6177","static_file","/wp-content/plugins/wpforms-lite/assets/lib/punycode.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6178","static_file","/wp-content/plugins/wpforms-lite/assets/lib/purify.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6179","static_file","/wp-content/plugins/wpforms-lite/assets/lite/css/admin/edit-post-education.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6180","static_file","/wp-content/plugins/wpforms-lite/assets/lite/css/admin/edit-post-education.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6181","static_file","/wp-content/plugins/wpforms-lite/assets/lite/css/admin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6182","static_file","/wp-content/plugins/wpforms-lite/assets/lite/css/admin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6183","static_file","/wp-content/plugins/wpforms-lite/assets/lite/css/builder-education.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6184","static_file","/wp-content/plugins/wpforms-lite/assets/lite/css/builder-education.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6185","static_file","/wp-content/plugins/wpforms-lite/assets/lite/css/dashboard-education.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6186","static_file","/wp-content/plugins/wpforms-lite/assets/lite/css/dashboard-education.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6187","static_file","/wp-content/plugins/wpforms-lite/assets/lite/images/edit-post-education-page-1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6188","static_file","/wp-content/plugins/wpforms-lite/assets/lite/images/edit-post-education-page-2.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6189","static_file","/wp-content/plugins/wpforms-lite/assets/lite/images/sullie-edit-post-education.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6190","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin/education/core.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6191","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin/education/core.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6192","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin/education/lite-connect.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6193","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin/education/lite-connect.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6194","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin/connect.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6195","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin/connect.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6196","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin/dashboard-widget.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6197","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin/dashboard-widget.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6198","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin/edit-post-education.es5.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6199","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin/edit-post-education.es5.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6200","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin/edit-post-education.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6201","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin-builder-lite.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6202","static_file","/wp-content/plugins/wpforms-lite/assets/lite/js/admin-builder-lite.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6203","static_file","/wp-content/plugins/wpforms-lite/vendor/woocommerce/action-scheduler/license.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:33:18","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6204","static_file","/wp-content/plugins/wpforms-lite/changelog.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:33:10","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6205","static_file","/wp-content/plugins/wpforms-lite/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:33:11","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6206","static_file","/wp-content/themes/astra/admin/assets/build/dashboard-app-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6207","static_file","/wp-content/themes/astra/admin/assets/build/dashboard-app.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6208","static_file","/wp-content/themes/astra/admin/assets/build/dashboard-app.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6209","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/page-builder/bb-plugin.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6210","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/page-builder/bb-plugin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6211","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/page-builder/vc-plugin.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6212","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/page-builder/vc-plugin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6213","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/sticky-add-to-cart.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6214","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/sticky-add-to-cart.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6215","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-grid.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6216","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-grid.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6217","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-layout-grid.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6218","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-layout-grid.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6219","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-layout.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6220","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-layout.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6221","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-smallscreen-grid.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6222","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-smallscreen-grid.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6223","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-smallscreen.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6224","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce-smallscreen.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6225","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6226","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/woocommerce/woocommerce.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6227","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/bne-flyout.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6228","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/bne-flyout.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6229","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/contact-form-7-main.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6230","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/contact-form-7-main.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6231","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/contact-form-7.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6232","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/contact-form-7.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6233","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/divi-builder.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6234","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/divi-builder.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6235","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/edd-grid.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6236","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/edd.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6237","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/edd.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6238","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/gravity-forms.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6239","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/gravity-forms.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6240","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/learndash.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6241","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/learndash.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6242","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/lifterlms-flex.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6243","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/lifterlms.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6244","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/lifterlms.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6245","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/site-origin.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6246","static_file","/wp-content/themes/astra/assets/css/minified/compatibility/site-origin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6247","static_file","/wp-content/themes/astra/assets/css/minified/customizer-controls.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6248","static_file","/wp-content/themes/astra/assets/css/minified/customizer-controls.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6249","static_file","/wp-content/themes/astra/assets/css/minified/editor-style.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6250","static_file","/wp-content/themes/astra/assets/css/minified/editor-style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6251","static_file","/wp-content/themes/astra/assets/css/minified/extend-customizer.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6252","static_file","/wp-content/themes/astra/assets/css/minified/extend-customizer.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6253","static_file","/wp-content/themes/astra/assets/css/minified/frontend.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6254","static_file","/wp-content/themes/astra/assets/css/minified/frontend.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6255","static_file","/wp-content/themes/astra/assets/css/minified/galleries.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6256","static_file","/wp-content/themes/astra/assets/css/minified/galleries.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6257","static_file","/wp-content/themes/astra/assets/css/minified/main-css.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6258","static_file","/wp-content/themes/astra/assets/css/minified/main.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6259","static_file","/wp-content/themes/astra/assets/css/minified/main.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6260","static_file","/wp-content/themes/astra/assets/css/minified/menu-animation-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6261","static_file","/wp-content/themes/astra/assets/css/minified/menu-animation.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6262","static_file","/wp-content/themes/astra/assets/css/minified/style-css.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6263","static_file","/wp-content/themes/astra/assets/css/minified/style-flex.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6264","static_file","/wp-content/themes/astra/assets/css/minified/style.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:39","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6265","static_file","/wp-content/themes/astra/assets/css/minified/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6266","static_file","/wp-content/themes/astra/assets/css/minified/stylesheet.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6267","static_file","/wp-content/themes/astra/assets/fonts/astra.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6268","static_file","/wp-content/themes/astra/assets/fonts/astra.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6269","static_file","/wp-content/themes/astra/assets/fonts/astra.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6270","static_file","/wp-content/themes/astra/assets/images/license.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6271","static_file","/wp-content/themes/astra/assets/images/astra-starter-sites.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6272","static_file","/wp-content/themes/astra/assets/js/minified/add-to-cart-quantity-btn.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6273","static_file","/wp-content/themes/astra/assets/js/minified/customizer-controls-toggle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6274","static_file","/wp-content/themes/astra/assets/js/minified/customizer-controls.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6275","static_file","/wp-content/themes/astra/assets/js/minified/customizer-dependency.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6276","static_file","/wp-content/themes/astra/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6277","static_file","/wp-content/themes/astra/assets/js/minified/extend-customizer.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6278","static_file","/wp-content/themes/astra/assets/js/minified/flexibility.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6279","static_file","/wp-content/themes/astra/assets/js/minified/frontend-pro.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6280","static_file","/wp-content/themes/astra/assets/js/minified/frontend.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6281","static_file","/wp-content/themes/astra/assets/js/minified/mobile-cart.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6282","static_file","/wp-content/themes/astra/assets/js/minified/navigation.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6283","static_file","/wp-content/themes/astra/assets/js/minified/shop-add-to-cart.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6284","static_file","/wp-content/themes/astra/assets/js/minified/skip-link-focus-fix.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6285","static_file","/wp-content/themes/astra/assets/js/minified/smooth-scroll.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6286","static_file","/wp-content/themes/astra/assets/js/minified/sticky-add-to-cart.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6287","static_file","/wp-content/themes/astra/assets/js/minified/style.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6288","static_file","/wp-content/themes/astra/assets/js/minified/wp-color-picker-alpha.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6289","static_file","/wp-content/themes/astra/assets/js/unminified/add-to-cart-quantity-btn.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6290","static_file","/wp-content/themes/astra/assets/js/unminified/customizer-controls-toggle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6291","static_file","/wp-content/themes/astra/assets/js/unminified/customizer-controls.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6292","static_file","/wp-content/themes/astra/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6293","static_file","/wp-content/themes/astra/assets/js/unminified/extend-customizer.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6294","static_file","/wp-content/themes/astra/assets/js/unminified/flexibility.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6295","static_file","/wp-content/themes/astra/assets/js/unminified/frontend-pro.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6296","static_file","/wp-content/themes/astra/assets/js/unminified/frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6297","static_file","/wp-content/themes/astra/assets/js/unminified/mobile-cart.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6298","static_file","/wp-content/themes/astra/assets/js/unminified/navigation.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6299","static_file","/wp-content/themes/astra/assets/js/unminified/shop-add-to-cart.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6300","static_file","/wp-content/themes/astra/assets/js/unminified/skip-link-focus-fix.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6301","static_file","/wp-content/themes/astra/assets/js/unminified/sticky-add-to-cart.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6302","static_file","/wp-content/themes/astra/assets/js/unminified/style.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:40","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6303","static_file","/wp-content/themes/astra/inc/addons/breadcrumbs/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6304","static_file","/wp-content/themes/astra/inc/addons/breadcrumbs/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6305","static_file","/wp-content/themes/astra/inc/addons/heading-colors/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6306","static_file","/wp-content/themes/astra/inc/addons/heading-colors/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6307","static_file","/wp-content/themes/astra/inc/addons/scroll-to-top/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6308","static_file","/wp-content/themes/astra/inc/addons/scroll-to-top/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6309","static_file","/wp-content/themes/astra/inc/addons/scroll-to-top/assets/js/unminified/scroll-to-top.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6310","static_file","/wp-content/themes/astra/inc/addons/transparent-header/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6311","static_file","/wp-content/themes/astra/inc/addons/transparent-header/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6312","static_file","/wp-content/themes/astra/inc/assets/css/ast-builder-customizer-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6313","static_file","/wp-content/themes/astra/inc/assets/css/ast-builder-customizer.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6314","static_file","/wp-content/themes/astra/inc/assets/css/ast-elementor-editor-dark-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6315","static_file","/wp-content/themes/astra/inc/assets/css/ast-elementor-editor-dark.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6316","static_file","/wp-content/themes/astra/inc/assets/css/ast-elementor-editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6317","static_file","/wp-content/themes/astra/inc/assets/css/ast-elementor-editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6318","static_file","/wp-content/themes/astra/inc/assets/css/astra-admin-menu-settings-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6319","static_file","/wp-content/themes/astra/inc/assets/css/astra-admin-menu-settings.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6320","static_file","/wp-content/themes/astra/inc/assets/css/astra-notices-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6321","static_file","/wp-content/themes/astra/inc/assets/css/astra-notices.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6322","static_file","/wp-content/themes/astra/inc/assets/css/block-editor-styles-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6323","static_file","/wp-content/themes/astra/inc/assets/css/block-editor-styles.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6324","static_file","/wp-content/themes/astra/inc/assets/css/customizer-preview-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6325","static_file","/wp-content/themes/astra/inc/assets/css/customizer-preview.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6326","static_file","/wp-content/themes/astra/inc/assets/css/font-icon-picker-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6327","static_file","/wp-content/themes/astra/inc/assets/css/font-icon-picker.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6328","static_file","/wp-content/themes/astra/inc/assets/css/wp-editor-styles-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6329","static_file","/wp-content/themes/astra/inc/assets/css/wp-editor-styles.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6330","static_file","/wp-content/themes/astra/inc/assets/fonts/ast-logo.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6331","static_file","/wp-content/themes/astra/inc/assets/fonts/ast-logo.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6332","static_file","/wp-content/themes/astra/inc/assets/fonts/ast-logo.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6333","static_file","/wp-content/themes/astra/inc/assets/fonts/ast-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6334","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/avatar.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6335","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6336","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/about-us.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6337","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/branding.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6338","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/graphic.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6339","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/web.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6340","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/blog.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6341","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/building.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6342","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/hero-img.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6343","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/passionate.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6344","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/portfolio.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6345","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/professional.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6346","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/shopping-bag.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6347","static_file","/wp-content/themes/astra/inc/assets/images/starter-content/support.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6348","static_file","/wp-content/themes/astra/inc/assets/images/astra-banner.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6349","static_file","/wp-content/themes/astra/inc/assets/images/astra-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6350","static_file","/wp-content/themes/astra/inc/assets/images/astra.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6351","static_file","/wp-content/themes/astra/inc/assets/images/custom-layout.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6352","static_file","/wp-content/themes/astra/inc/assets/images/lightning-speed.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6353","static_file","/wp-content/themes/astra/inc/assets/images/page-header.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6354","static_file","/wp-content/themes/astra/inc/assets/js/ast-parse-svg.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6355","static_file","/wp-content/themes/astra/inc/assets/js/ast-render-svg.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6356","static_file","/wp-content/themes/astra/inc/assets/js/astra-admin-menu-settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6357","static_file","/wp-content/themes/astra/inc/assets/js/block-editor-script.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6358","static_file","/wp-content/themes/astra/inc/assets/js/column-block-compatibility.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6359","static_file","/wp-content/themes/astra/inc/assets/js/custom-fields-priority.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6360","static_file","/wp-content/themes/astra/inc/assets/js/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6361","static_file","/wp-content/themes/astra/inc/builder/type/base/assets/js/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6362","static_file","/wp-content/themes/astra/inc/builder/type/footer/above-footer/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6363","static_file","/wp-content/themes/astra/inc/builder/type/footer/above-footer/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6364","static_file","/wp-content/themes/astra/inc/builder/type/footer/below-footer/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6365","static_file","/wp-content/themes/astra/inc/builder/type/footer/below-footer/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6366","static_file","/wp-content/themes/astra/inc/builder/type/footer/button/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6367","static_file","/wp-content/themes/astra/inc/builder/type/footer/button/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6368","static_file","/wp-content/themes/astra/inc/builder/type/footer/copyright/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6369","static_file","/wp-content/themes/astra/inc/builder/type/footer/copyright/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6370","static_file","/wp-content/themes/astra/inc/builder/type/footer/html/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6371","static_file","/wp-content/themes/astra/inc/builder/type/footer/html/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6372","static_file","/wp-content/themes/astra/inc/builder/type/footer/menu/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6373","static_file","/wp-content/themes/astra/inc/builder/type/footer/menu/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:42","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6374","static_file","/wp-content/themes/astra/inc/builder/type/footer/primary-footer/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6375","static_file","/wp-content/themes/astra/inc/builder/type/footer/primary-footer/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6376","static_file","/wp-content/themes/astra/inc/builder/type/footer/social-icon/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6377","static_file","/wp-content/themes/astra/inc/builder/type/footer/social-icon/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6378","static_file","/wp-content/themes/astra/inc/builder/type/footer/widget/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6379","static_file","/wp-content/themes/astra/inc/builder/type/footer/widget/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6380","static_file","/wp-content/themes/astra/inc/builder/type/header/above-header/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6381","static_file","/wp-content/themes/astra/inc/builder/type/header/above-header/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6382","static_file","/wp-content/themes/astra/inc/builder/type/header/account/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6383","static_file","/wp-content/themes/astra/inc/builder/type/header/account/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6384","static_file","/wp-content/themes/astra/inc/builder/type/header/below-header/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6385","static_file","/wp-content/themes/astra/inc/builder/type/header/below-header/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6386","static_file","/wp-content/themes/astra/inc/builder/type/header/button/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6387","static_file","/wp-content/themes/astra/inc/builder/type/header/button/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6388","static_file","/wp-content/themes/astra/inc/builder/type/header/edd-cart/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6389","static_file","/wp-content/themes/astra/inc/builder/type/header/edd-cart/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6390","static_file","/wp-content/themes/astra/inc/builder/type/header/html/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6391","static_file","/wp-content/themes/astra/inc/builder/type/header/html/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6392","static_file","/wp-content/themes/astra/inc/builder/type/header/menu/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6393","static_file","/wp-content/themes/astra/inc/builder/type/header/menu/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6394","static_file","/wp-content/themes/astra/inc/builder/type/header/mobile-menu/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6395","static_file","/wp-content/themes/astra/inc/builder/type/header/mobile-menu/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6396","static_file","/wp-content/themes/astra/inc/builder/type/header/mobile-trigger/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6397","static_file","/wp-content/themes/astra/inc/builder/type/header/mobile-trigger/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6398","static_file","/wp-content/themes/astra/inc/builder/type/header/off-canvas/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6399","static_file","/wp-content/themes/astra/inc/builder/type/header/off-canvas/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6400","static_file","/wp-content/themes/astra/inc/builder/type/header/primary-header/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6401","static_file","/wp-content/themes/astra/inc/builder/type/header/primary-header/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6402","static_file","/wp-content/themes/astra/inc/builder/type/header/search/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6403","static_file","/wp-content/themes/astra/inc/builder/type/header/search/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6404","static_file","/wp-content/themes/astra/inc/builder/type/header/site-identity/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6405","static_file","/wp-content/themes/astra/inc/builder/type/header/site-identity/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6406","static_file","/wp-content/themes/astra/inc/builder/type/header/social-icon/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6407","static_file","/wp-content/themes/astra/inc/builder/type/header/social-icon/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6408","static_file","/wp-content/themes/astra/inc/builder/type/header/widget/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6409","static_file","/wp-content/themes/astra/inc/builder/type/header/widget/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6410","static_file","/wp-content/themes/astra/inc/builder/type/header/woo-cart/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6411","static_file","/wp-content/themes/astra/inc/builder/type/header/woo-cart/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:43","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6412","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/minified/custom-controls.min-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6413","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/minified/custom-controls.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6414","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/alignment-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6415","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/alignment.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6416","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/background-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6417","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/background.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6418","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/border-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6419","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/border.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6420","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/button-link-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6421","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/button-link.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6422","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/button-presets-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6423","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/button-presets.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6424","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/color-group-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6425","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/color-group.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6426","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/color-palette-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6427","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/color-palette.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6428","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/color-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6429","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/color.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6430","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/custom-controls-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6431","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/custom-controls.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6432","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/customizer-color-palette-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6433","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/customizer-color-palette.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6434","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/customizer-global-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6435","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/customizer-global.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6436","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/customizer-link-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6437","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/customizer-link.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6438","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/customizer-style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6439","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/customizer-style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6440","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/description-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6441","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/description.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6442","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/divider-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6443","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/divider.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6444","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/font-presets-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6445","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/font-presets.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6446","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/font-varient-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6447","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/font-varient.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6448","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/group-title-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6449","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/group-title.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6450","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/heading-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6451","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/heading.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6452","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/input-with-dropdowm-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6453","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/input-with-dropdowm.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6454","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/link-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6455","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/link.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6456","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/menu-select-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6457","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/menu-select.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6458","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/multi-select-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6459","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/multi-select.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6460","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/radio-icon-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6461","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/radio-icon.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6462","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/radio-image-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6463","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/radio-image.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6464","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/responsive-background-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6465","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/responsive-background.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6466","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/responsive-color-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6467","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/responsive-color.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6468","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/responsive-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6469","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/responsive-slider-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6470","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/responsive-slider.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6471","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/responsive-spacing-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6472","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/responsive-spacing.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6473","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/responsive-toggle-control-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6474","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/responsive-toggle-control.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6475","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/responsive.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6476","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/select-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6477","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/select.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6478","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/settings-group-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6479","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/settings-group.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6480","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/slider-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6481","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/slider.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6482","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/sortable-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6483","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/sortable.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6484","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/text-input-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6485","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/text-input.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6486","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/toggle-control-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6487","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/toggle-control.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6488","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/tooltip-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6489","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/tooltip.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6490","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/typography-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6491","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/typography.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6492","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/upgrade-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6493","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/css/unminified/upgrade.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:44","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6494","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/assets/js/unminified/custom-controls-plain.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:45","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6495","static_file","/wp-content/themes/astra/inc/customizer/custom-controls/typography/selectWoo.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:45","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6496","static_file","/wp-content/themes/astra/inc/customizer/extend-custom-controls/build/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:47","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6497","static_file","/wp-content/themes/astra/inc/lib/astra-notices/notices.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:47","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6498","static_file","/wp-content/themes/astra/inc/lib/astra-notices/notices.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:47","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6499","static_file","/wp-content/themes/astra/inc/metabox/extend-metabox/build/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:48","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6500","static_file","/wp-content/themes/astra/inc/metabox/extend-metabox/css/minified/metabox-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:48","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6501","static_file","/wp-content/themes/astra/inc/metabox/extend-metabox/css/minified/metabox.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:48","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6502","static_file","/wp-content/themes/astra/inc/metabox/extend-metabox/css/unminified/metabox-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:48","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6503","static_file","/wp-content/themes/astra/inc/metabox/extend-metabox/css/unminified/metabox.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:48","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6504","static_file","/wp-content/themes/astra/inc/modules/posts-structures/assets/js/minified/customizer-preview.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:48","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6505","static_file","/wp-content/themes/astra/inc/modules/posts-structures/assets/js/unminified/customizer-preview.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:48","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6506","static_file","/wp-content/themes/astra/changelog.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-09-04 07:12:41","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6507","static_file","/wp-content/themes/astra/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-09-04 07:12:48","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6508","static_file","/wp-content/themes/astra/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:48","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6509","static_file","/wp-content/themes/astra/screenshot.jpg","","","0","1","0","","0000-00-00 00:00:00","","2023-09-04 07:12:48","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6510","static_file","/wp-content/themes/astra/wpml-config.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 07:12:48","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6511","static_file","/wp-content/themes/twentytwentyone/assets/css/custom-color-overrides.css","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6512","static_file","/wp-content/themes/twentytwentyone/assets/css/ie-editor.css","","","0","1","0","","0000-00-00 00:00:00","","2023-03-29 11:04:36","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6513","static_file","/wp-content/themes/twentytwentyone/assets/css/ie.css","","","0","1","0","","0000-00-00 00:00:00","","2023-03-29 11:04:36","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6514","static_file","/wp-content/themes/twentytwentyone/assets/css/print.css","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6515","static_file","/wp-content/themes/twentytwentyone/assets/css/style-dark-mode-rtl.css","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6516","static_file","/wp-content/themes/twentytwentyone/assets/css/style-dark-mode.css","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6517","static_file","/wp-content/themes/twentytwentyone/assets/css/style-editor-customizer.css","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6518","static_file","/wp-content/themes/twentytwentyone/assets/css/style-editor.css","","","0","1","0","","0000-00-00 00:00:00","","2023-03-29 11:04:36","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6519","static_file","/wp-content/themes/twentytwentyone/assets/images/Daffodils.jpg","","","0","1","0","","0000-00-00 00:00:00","","2020-12-09 05:29:46","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6520","static_file","/wp-content/themes/twentytwentyone/assets/images/Reading.jpg","","","0","1","0","","0000-00-00 00:00:00","","2020-12-09 05:29:46","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6521","static_file","/wp-content/themes/twentytwentyone/assets/images/in-the-bois-de-boulogne.jpg","","","0","1","0","","0000-00-00 00:00:00","","2020-12-09 05:29:46","0000-00-00 00:00:00","2023-09-07 12:54:41");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6522","static_file","/wp-content/themes/twentytwentyone/assets/images/playing-in-the-sand.jpg","","","0","1","0","","0000-00-00 00:00:00","","2020-12-09 05:29:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6523","static_file","/wp-content/themes/twentytwentyone/assets/images/roses-tremieres-hollyhocks-1884.jpg","","","0","1","0","","0000-00-00 00:00:00","","2020-12-09 05:29:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6524","static_file","/wp-content/themes/twentytwentyone/assets/images/self-portrait-1885.jpg","","","0","1","0","","0000-00-00 00:00:00","","2020-12-09 05:29:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6525","static_file","/wp-content/themes/twentytwentyone/assets/images/the-garden-at-bougival-1884.jpg","","","0","1","0","","0000-00-00 00:00:00","","2020-12-09 05:29:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6526","static_file","/wp-content/themes/twentytwentyone/assets/images/villa-with-orange-trees-nice.jpg","","","0","1","0","","0000-00-00 00:00:00","","2020-12-09 05:29:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6527","static_file","/wp-content/themes/twentytwentyone/assets/images/young-woman-in-mauve.jpg","","","0","1","0","","0000-00-00 00:00:00","","2020-12-09 05:29:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6528","static_file","/wp-content/themes/twentytwentyone/assets/js/customize-helpers.js","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6529","static_file","/wp-content/themes/twentytwentyone/assets/js/customize-preview.js","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6530","static_file","/wp-content/themes/twentytwentyone/assets/js/customize.js","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6531","static_file","/wp-content/themes/twentytwentyone/assets/js/dark-mode-toggler.js","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6532","static_file","/wp-content/themes/twentytwentyone/assets/js/editor-dark-mode-support.js","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6533","static_file","/wp-content/themes/twentytwentyone/assets/js/editor.js","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6534","static_file","/wp-content/themes/twentytwentyone/assets/js/palette-colorpicker.js","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6535","static_file","/wp-content/themes/twentytwentyone/assets/js/polyfills.js","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6536","static_file","/wp-content/themes/twentytwentyone/assets/js/primary-navigation.js","","","0","1","0","","0000-00-00 00:00:00","","2023-03-29 11:04:36","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6537","static_file","/wp-content/themes/twentytwentyone/assets/js/responsive-embeds.js","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6538","static_file","/wp-content/themes/twentytwentyone/assets/js/skip-link-focus-fix.js","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6539","static_file","/wp-content/themes/twentytwentyone/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-03-29 11:04:36","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6540","static_file","/wp-content/themes/twentytwentyone/style-rtl.css","","","0","1","0","","0000-00-00 00:00:00","","2023-03-29 11:04:36","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6541","static_file","/wp-content/themes/twentytwentyone/style.css","","","0","1","0","","0000-00-00 00:00:00","","2023-03-29 11:04:36","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6542","static_file","/wp-content/themes/twentytwentyone/postcss.config.js","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:23:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6543","static_file","/wp-content/themes/twentytwentyone/screenshot.png","","","0","1","0","","0000-00-00 00:00:00","","2020-12-09 05:29:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6544","static_file","/wp-content/themes/twentytwentythree/assets/fonts/dm-sans/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6545","static_file","/wp-content/themes/twentytwentythree/assets/fonts/dm-sans/DMSans-Bold-Italic.woff2","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6546","static_file","/wp-content/themes/twentytwentythree/assets/fonts/dm-sans/DMSans-Bold.woff2","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6547","static_file","/wp-content/themes/twentytwentythree/assets/fonts/dm-sans/DMSans-Regular-Italic.woff2","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6548","static_file","/wp-content/themes/twentytwentythree/assets/fonts/dm-sans/DMSans-Regular.woff2","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6549","static_file","/wp-content/themes/twentytwentythree/assets/fonts/ibm-plex-mono/OFL.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6550","static_file","/wp-content/themes/twentytwentythree/assets/fonts/ibm-plex-mono/IBMPlexMono-Bold.woff2","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6551","static_file","/wp-content/themes/twentytwentythree/assets/fonts/ibm-plex-mono/IBMPlexMono-Italic.woff2","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6552","static_file","/wp-content/themes/twentytwentythree/assets/fonts/ibm-plex-mono/IBMPlexMono-Light.woff2","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6553","static_file","/wp-content/themes/twentytwentythree/assets/fonts/ibm-plex-mono/IBMPlexMono-Regular.woff2","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6554","static_file","/wp-content/themes/twentytwentythree/assets/fonts/inter/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6555","static_file","/wp-content/themes/twentytwentythree/assets/fonts/inter/Inter-VariableFont_slnt,wght.ttf","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6556","static_file","/wp-content/themes/twentytwentythree/assets/fonts/source-serif-pro/SourceSerif4Variable-Italic.otf.woff2","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:52","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6557","static_file","/wp-content/themes/twentytwentythree/assets/fonts/source-serif-pro/SourceSerif4Variable-Italic.ttf.woff2","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:52","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6558","static_file","/wp-content/themes/twentytwentythree/assets/fonts/source-serif-pro/SourceSerif4Variable-Roman.otf.woff2","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:52","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6559","static_file","/wp-content/themes/twentytwentythree/assets/fonts/source-serif-pro/SourceSerif4Variable-Roman.ttf.woff2","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6560","static_file","/wp-content/themes/twentytwentythree/parts/comments.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6561","static_file","/wp-content/themes/twentytwentythree/parts/footer.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6562","static_file","/wp-content/themes/twentytwentythree/parts/header.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6563","static_file","/wp-content/themes/twentytwentythree/parts/post-meta.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6564","static_file","/wp-content/themes/twentytwentythree/templates/404.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6565","static_file","/wp-content/themes/twentytwentythree/templates/archive.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6566","static_file","/wp-content/themes/twentytwentythree/templates/blank.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6567","static_file","/wp-content/themes/twentytwentythree/templates/blog-alternative.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6568","static_file","/wp-content/themes/twentytwentythree/templates/home.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6569","static_file","/wp-content/themes/twentytwentythree/templates/index.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6570","static_file","/wp-content/themes/twentytwentythree/templates/page.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6571","static_file","/wp-content/themes/twentytwentythree/templates/search.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6572","static_file","/wp-content/themes/twentytwentythree/templates/single.html","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6573","static_file","/wp-content/themes/twentytwentythree/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6574","static_file","/wp-content/themes/twentytwentythree/style.css","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6575","static_file","/wp-content/themes/twentytwentythree/screenshot.png","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:37:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6576","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/dm-sans/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6577","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/dm-sans/DMSans-Bold.ttf","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6578","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/dm-sans/DMSans-BoldItalic.ttf","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6579","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/dm-sans/DMSans-Italic.ttf","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6580","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/dm-sans/DMSans-Regular.ttf","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6581","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/ibm-plex/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6582","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/ibm-plex/IBMPlexMono-Bold.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6583","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/ibm-plex/IBMPlexMono-BoldItalic.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6584","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/ibm-plex/IBMPlexMono-Text.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6585","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/ibm-plex/IBMPlexMono-TextItalic.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6586","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/ibm-plex/IBMPlexSans-ExtraLight.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6587","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/ibm-plex/IBMPlexSans-ExtraLightItalic.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6588","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/ibm-plex/IBMPlexSans-Light.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6589","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/ibm-plex/IBMPlexSans-LightItalic.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6590","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/inter/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6591","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/inter/Inter.ttf","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6592","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/source-serif-pro/SourceSerif4Variable-Italic.otf.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6593","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/source-serif-pro/SourceSerif4Variable-Italic.ttf.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6594","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/source-serif-pro/SourceSerif4Variable-Roman.otf.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6595","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/source-serif-pro/SourceSerif4Variable-Roman.ttf.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6596","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/SourceSerif4Variable-Italic.otf.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6597","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/SourceSerif4Variable-Italic.ttf.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6598","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/SourceSerif4Variable-Roman.otf.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6599","static_file","/wp-content/themes/twentytwentytwo/assets/fonts/SourceSerif4Variable-Roman.ttf.woff2","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6600","static_file","/wp-content/themes/twentytwentytwo/assets/images/divider-black.png","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6601","static_file","/wp-content/themes/twentytwentytwo/assets/images/divider-white.png","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6602","static_file","/wp-content/themes/twentytwentytwo/assets/images/flight-path-on-transparent-a.png","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6603","static_file","/wp-content/themes/twentytwentytwo/assets/images/flight-path-on-transparent-b.png","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6604","static_file","/wp-content/themes/twentytwentytwo/assets/images/flight-path-on-transparent-c.png","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6605","static_file","/wp-content/themes/twentytwentytwo/assets/images/flight-path-on-transparent-d.png","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6606","static_file","/wp-content/themes/twentytwentytwo/assets/images/icon-binoculars.png","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6607","static_file","/wp-content/themes/twentytwentytwo/assets/images/bird-on-black.jpg","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6608","static_file","/wp-content/themes/twentytwentytwo/assets/images/bird-on-gray.jpg","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6609","static_file","/wp-content/themes/twentytwentytwo/assets/images/bird-on-green.jpg","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6610","static_file","/wp-content/themes/twentytwentytwo/assets/images/bird-on-salmon.jpg","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6611","static_file","/wp-content/themes/twentytwentytwo/assets/images/ducks.jpg","","","0","1","0","","0000-00-00 00:00:00","","2022-02-25 10:27:50","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6612","static_file","/wp-content/themes/twentytwentytwo/assets/images/flight-path-on-gray-a.jpg","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6613","static_file","/wp-content/themes/twentytwentytwo/assets/images/flight-path-on-gray-b.jpg","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6614","static_file","/wp-content/themes/twentytwentytwo/assets/images/flight-path-on-gray-c.jpg","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6615","static_file","/wp-content/themes/twentytwentytwo/assets/images/flight-path-on-salmon.jpg","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6616","static_file","/wp-content/themes/twentytwentytwo/assets/images/icon-bird.jpg","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6617","static_file","/wp-content/themes/twentytwentytwo/assets/videos/birds.mp4","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6618","static_file","/wp-content/themes/twentytwentytwo/parts/footer.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6619","static_file","/wp-content/themes/twentytwentytwo/parts/header-large-dark.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6620","static_file","/wp-content/themes/twentytwentytwo/parts/header-small-dark.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6621","static_file","/wp-content/themes/twentytwentytwo/parts/header.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6622","static_file","/wp-content/themes/twentytwentytwo/templates/404.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6623","static_file","/wp-content/themes/twentytwentytwo/templates/archive.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6624","static_file","/wp-content/themes/twentytwentytwo/templates/blank.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6625","static_file","/wp-content/themes/twentytwentytwo/templates/home.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6626","static_file","/wp-content/themes/twentytwentytwo/templates/index.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6627","static_file","/wp-content/themes/twentytwentytwo/templates/page-large-header.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6628","static_file","/wp-content/themes/twentytwentytwo/templates/page-no-separators.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6629","static_file","/wp-content/themes/twentytwentytwo/templates/page.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6630","static_file","/wp-content/themes/twentytwentytwo/templates/search.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6631","static_file","/wp-content/themes/twentytwentytwo/templates/single-no-separators.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6632","static_file","/wp-content/themes/twentytwentytwo/templates/single.html","","","0","1","0","","0000-00-00 00:00:00","","2022-05-24 11:29:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6633","static_file","/wp-content/themes/twentytwentytwo/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-03-29 11:03:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6634","static_file","/wp-content/themes/twentytwentytwo/style.css","","","0","1","0","","0000-00-00 00:00:00","","2023-03-29 11:03:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6635","static_file","/wp-content/themes/twentytwentytwo/screenshot.png","","","0","1","0","","0000-00-00 00:00:00","","2022-01-26 03:24:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6636","static_file","/wp-content/updraft/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-04-30 07:22:17","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6637","static_file","/wp-content/updraft/log.1b4ca96ef8e3.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-07-20 12:08:03","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6638","static_file","/wp-content/updraft/log.26081a6e225d.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-01 08:06:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6639","static_file","/wp-content/updraft/log.588d148a4520.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-08-05 08:36:56","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6640","static_file","/wp-content/updraft/log.62724a5b90e8.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-07-18 02:03:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6641","static_file","/wp-content/updraft/log.94f3e433c2c1.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-07-05 11:33:19","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6642","static_file","/wp-content/updraft/log.f04b65d4ea8b.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-07-28 03:07:12","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6643","static_file","/wp-content/updraft/backup_2023-06-24-0443_TEchshop_195700c2a957-db.gz","","","0","1","1","","0000-00-00 00:00:00","","2023-06-24 06:00:10","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6644","static_file","/wp-content/updraft/backup_2023-07-18-1406_TEchshop_1b4ca96ef8e3-db.gz","","","0","1","1","","0000-00-00 00:00:00","","2023-07-20 12:08:01","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6645","static_file","/wp-content/updraft/backup_2023-07-28-1206_TEchshop_f04b65d4ea8b-db.gz","","","0","1","1","","0000-00-00 00:00:00","","2023-07-28 03:07:09","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6646","static_file","/wp-content/updraft/backup_2023-06-24-0443_TEchshop_195700c2a957-others.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-06-24 06:00:02","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6647","static_file","/wp-content/updraft/backup_2023-06-24-0443_TEchshop_195700c2a957-plugins.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-06-24 05:56:59","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6648","static_file","/wp-content/updraft/backup_2023-06-24-0443_TEchshop_195700c2a957-themes.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-06-24 05:57:48","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6649","static_file","/wp-content/updraft/backup_2023-06-24-0443_TEchshop_195700c2a957-uploads.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-06-24 06:00:01","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6650","static_file","/wp-content/updraft/backup_2023-07-18-1406_TEchshop_1b4ca96ef8e3-others.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-07-20 12:07:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6651","static_file","/wp-content/updraft/backup_2023-07-18-1406_TEchshop_1b4ca96ef8e3-plugins.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-07-20 12:04:36","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6652","static_file","/wp-content/updraft/backup_2023-07-18-1406_TEchshop_1b4ca96ef8e3-themes.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-07-20 12:05:47","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6653","static_file","/wp-content/updraft/backup_2023-07-18-1406_TEchshop_1b4ca96ef8e3-uploads.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-07-20 12:07:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6654","static_file","/wp-content/updraft/backup_2023-07-28-1206_TEchshop_f04b65d4ea8b-others.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-07-28 03:06:58","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6655","static_file","/wp-content/updraft/backup_2023-07-28-1206_TEchshop_f04b65d4ea8b-plugins.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-07-28 03:03:36","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6656","static_file","/wp-content/updraft/backup_2023-07-28-1206_TEchshop_f04b65d4ea8b-themes.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-07-28 03:04:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6657","static_file","/wp-content/updraft/backup_2023-07-28-1206_TEchshop_f04b65d4ea8b-uploads.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-07-28 03:06:57","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6658","static_file","/wp-content/uploads/2021/08/EXP-401_Fill-1-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:03","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6659","static_file","/wp-content/uploads/2021/08/EXP-401_Fill-1-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 03:32:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6660","static_file","/wp-content/uploads/2021/08/EXP-401_Fill-1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 03:32:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6661","static_file","/wp-content/uploads/2021/08/EXP-401_Fill-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6662","static_file","/wp-content/uploads/2021/08/EXP-401_Fill-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 03:31:01","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6663","static_file","/wp-content/uploads/2021/08/EXP-401_Fill.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 03:31:01","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6664","static_file","/wp-content/uploads/2021/08/ExIF-Logo_BackgroundWhite-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:26","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6665","static_file","/wp-content/uploads/2021/08/ExIF-Logo_BackgroundWhite-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:58:57","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6666","static_file","/wp-content/uploads/2021/08/ExIF-Logo_BackgroundWhite-300x212.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:58:57","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6667","static_file","/wp-content/uploads/2021/08/ExIF-Logo_BackgroundWhite-300x282.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:26","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6668","static_file","/wp-content/uploads/2021/08/ExIF-Logo_BackgroundWhite.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:58:57","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6669","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-13-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:15","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6670","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-13-1024x531.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:42","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6671","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-13-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:42","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6672","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-13-300x155.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:42","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6673","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-13-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:15","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6674","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-13-600x311.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:15","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6675","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-13-768x398.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:43","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6676","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-13.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:42","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6677","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-24-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:12","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6678","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-24-1024x531.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:50","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6679","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-24-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:50","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6680","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-24-300x155.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:50","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6681","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-24-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:12","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6682","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-24-600x311.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:12","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6683","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-24-768x398.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:50","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6684","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-24.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:50","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6685","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-30-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:11","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6686","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-30-1024x531.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:58","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6687","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-30-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:58","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6688","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-30-300x155.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:57","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6689","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-30-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:11","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6690","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-30-600x311.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:12","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6691","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-30-768x398.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:58","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6692","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-35-30.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:38:57","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6693","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-04-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:09","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6694","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-04-1024x617.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6695","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-04-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6696","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-04-300x181.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6697","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-04-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:09","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6698","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-04-600x362.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:09","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6699","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-04-768x463.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6700","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-04.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6701","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-27-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:09","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6702","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-27-1024x617.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:12","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6703","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-27-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:12","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6704","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-27-300x181.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:12","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6705","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-27-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:09","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6706","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-27-600x362.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:09","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6707","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-27-768x463.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:12","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6708","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-27.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:12","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6709","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-34-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:07","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6710","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-34-1024x617.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:17","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6711","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-34-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:17","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6712","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-34-300x181.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:17","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6713","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-34-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:07","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6714","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-34-600x362.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:07","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6715","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-34-768x463.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:17","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6716","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-34.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:17","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6717","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-49-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:06","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6718","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-49-1024x617.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:23","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6719","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-49-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:23","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6720","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-49-300x181.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:23","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6721","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-49-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:06","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6722","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-49-600x362.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:06","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6723","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-49-768x463.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6724","static_file","/wp-content/uploads/2021/08/Screenshot-from-2023-04-28-07-36-49.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 12:39:23","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6725","static_file","/wp-content/uploads/2021/08/beef-xss-logo-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:29","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6726","static_file","/wp-content/uploads/2021/08/beef-xss-logo-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:19:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6727","static_file","/wp-content/uploads/2021/08/beef-xss-logo-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:29","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6728","static_file","/wp-content/uploads/2021/08/beef-xss-logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:19:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6729","static_file","/wp-content/uploads/2021/08/cropped-site-favicon-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:38","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6730","static_file","/wp-content/uploads/2021/08/cropped-site-favicon-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:38","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6731","static_file","/wp-content/uploads/2021/08/cropped-site-favicon-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:38","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6732","static_file","/wp-content/uploads/2021/08/cropped-site-favicon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:27","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6733","static_file","/wp-content/uploads/2021/08/set3-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:17","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6734","static_file","/wp-content/uploads/2021/08/set3-1024x576.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:45:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6735","static_file","/wp-content/uploads/2021/08/set3-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:45:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6736","static_file","/wp-content/uploads/2021/08/set3-300x169.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:45:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6737","static_file","/wp-content/uploads/2021/08/set3-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:17","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6738","static_file","/wp-content/uploads/2021/08/set3-600x337.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:17","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6739","static_file","/wp-content/uploads/2021/08/set3-768x432.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:45:05","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6740","static_file","/wp-content/uploads/2021/08/set3.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:45:03","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6741","static_file","/wp-content/uploads/2021/08/shot1-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:20","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6742","static_file","/wp-content/uploads/2021/08/shot1-1024x463.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:44:58","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6743","static_file","/wp-content/uploads/2021/08/shot1-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:44:59","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6744","static_file","/wp-content/uploads/2021/08/shot1-300x136.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:44:58","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6745","static_file","/wp-content/uploads/2021/08/shot1-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:20","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6746","static_file","/wp-content/uploads/2021/08/shot1-600x271.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:20","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6747","static_file","/wp-content/uploads/2021/08/shot1-768x347.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:44:59","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6748","static_file","/wp-content/uploads/2021/08/shot1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:44:58","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6749","static_file","/wp-content/uploads/2021/08/shot2-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:22","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6750","static_file","/wp-content/uploads/2021/08/shot2-1024x576.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:44:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6751","static_file","/wp-content/uploads/2021/08/shot2-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:44:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6752","static_file","/wp-content/uploads/2021/08/shot2-300x169.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:44:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6753","static_file","/wp-content/uploads/2021/08/shot2-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:22","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6754","static_file","/wp-content/uploads/2021/08/shot2-600x337.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:22","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6755","static_file","/wp-content/uploads/2021/08/shot2-768x432.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:44:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6756","static_file","/wp-content/uploads/2021/08/shot2.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 11:44:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6757","static_file","/wp-content/uploads/2021/08/site-favicon-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:23","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6758","static_file","/wp-content/uploads/2021/08/site-favicon-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:37","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6759","static_file","/wp-content/uploads/2021/08/site-favicon-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:23","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6760","static_file","/wp-content/uploads/2021/08/site-favicon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:27","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6761","static_file","/wp-content/uploads/2021/08/woocommerce-placeholder-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:56","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6762","static_file","/wp-content/uploads/2021/08/woocommerce-placeholder-1024x1024.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:20","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6763","static_file","/wp-content/uploads/2021/08/woocommerce-placeholder-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:20","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6764","static_file","/wp-content/uploads/2021/08/woocommerce-placeholder-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:56","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6765","static_file","/wp-content/uploads/2021/08/woocommerce-placeholder-600x600.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:56","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6766","static_file","/wp-content/uploads/2021/08/woocommerce-placeholder-768x768.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:20","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6767","static_file","/wp-content/uploads/2021/08/woocommerce-placeholder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6768","static_file","/wp-content/uploads/2021/08/Group-107-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:45","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6769","static_file","/wp-content/uploads/2021/08/Group-107-1024x512.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6770","static_file","/wp-content/uploads/2021/08/Group-107-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6771","static_file","/wp-content/uploads/2021/08/Group-107-300x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6772","static_file","/wp-content/uploads/2021/08/Group-107-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:45","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6773","static_file","/wp-content/uploads/2021/08/Group-107-600x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:45","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6774","static_file","/wp-content/uploads/2021/08/Group-107-768x384.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:33","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6775","static_file","/wp-content/uploads/2021/08/Group-107.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:23","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6776","static_file","/wp-content/uploads/2021/08/footer-background-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:41","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6777","static_file","/wp-content/uploads/2021/08/footer-background-1024x576.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:56","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6778","static_file","/wp-content/uploads/2021/08/footer-background-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:56","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6779","static_file","/wp-content/uploads/2021/08/footer-background-1536x864.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:56","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6780","static_file","/wp-content/uploads/2021/08/footer-background-300x169.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:56","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6781","static_file","/wp-content/uploads/2021/08/footer-background-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:41","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6782","static_file","/wp-content/uploads/2021/08/footer-background-600x338.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:41","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6783","static_file","/wp-content/uploads/2021/08/footer-background-768x432.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:56","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6784","static_file","/wp-content/uploads/2021/08/footer-background.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:47","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6785","static_file","/wp-content/uploads/2021/08/footer-bg-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:44","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6786","static_file","/wp-content/uploads/2021/08/footer-bg-1024x576.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:55","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6787","static_file","/wp-content/uploads/2021/08/footer-bg-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:55","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6788","static_file","/wp-content/uploads/2021/08/footer-bg-1536x864.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:56","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6789","static_file","/wp-content/uploads/2021/08/footer-bg-300x169.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:54","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6790","static_file","/wp-content/uploads/2021/08/footer-bg-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:43","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6791","static_file","/wp-content/uploads/2021/08/footer-bg-600x338.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:44","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6792","static_file","/wp-content/uploads/2021/08/footer-bg-768x432.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:55","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6793","static_file","/wp-content/uploads/2021/08/footer-bg.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6794","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-1-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:06","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6795","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-1-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6796","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-1-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6797","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-1-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:06","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6798","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-1-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:06","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6799","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:43","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6800","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-2-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6801","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-2-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6802","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-2-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6803","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-2-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6804","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-2-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6805","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-2.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:42","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6806","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-3-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:13","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6807","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-3-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6808","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-3-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6809","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-3-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:13","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6810","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-3-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:13","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6811","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-3.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:42","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6812","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-4-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:09","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6813","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-4-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6814","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-4-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6815","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-4-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:09","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6816","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-4-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:09","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6817","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-4.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:43","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6818","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-5-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:03","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6819","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-5-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6820","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-5-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6821","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-5-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:03","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6822","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-5-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6823","static_file","/wp-content/uploads/2021/08/plants-ecommerce-accessories-product-featured-img-5.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:43","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6824","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-1-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:44","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6825","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-1-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:23","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6826","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-1-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:23","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6827","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-1-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:44","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6828","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-1-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:44","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6829","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:06","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6830","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-10-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:22","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6831","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-10-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:26","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6832","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-10-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:26","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6833","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-10-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:22","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6834","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-10-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:23","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6835","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-10.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6836","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-11-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:20","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6837","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-11-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:27","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6838","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-11-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:27","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6839","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-11-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:20","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6840","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-11-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:20","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6841","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-11.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6842","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-12-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6843","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-12-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:27","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6844","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-12-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:27","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6845","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-12-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6846","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-12-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6847","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-12.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6848","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-13-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6849","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-13-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:27","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6850","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-13-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:27","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6851","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-13-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6852","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-13-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:16","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6853","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-13.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:17","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6854","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-14-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:12","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6855","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-14-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:28","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6856","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-14-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:28","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6857","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-14-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:12","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6858","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-14-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:13","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6859","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-14.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:19","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6860","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-15-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:10","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6861","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-15-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:28","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6862","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-15-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:28","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6863","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-15-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:10","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6864","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-15-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:10","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6865","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-15.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:19","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6866","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-16-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:07","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6867","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-16-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:28","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6868","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-16-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:28","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6869","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-16-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:07","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6870","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-16-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:08","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6871","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-16.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:19","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6872","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-17-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6873","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-17-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:29","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6874","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-17-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:29","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6875","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-17-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6876","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-17-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:04","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6877","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-17.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:20","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6878","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-18-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:02","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6879","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-18-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:29","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6880","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-18-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:29","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6881","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-18-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:02","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6882","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-18-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:02","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6883","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-18.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:20","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6884","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-19-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:00","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6885","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-19-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6886","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-19-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:29","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6887","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-19-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:00","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6888","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-19-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:00","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6889","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-19.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:20","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6890","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-2-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:41","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6891","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-2-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6892","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-2-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6893","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-2-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:41","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6894","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-2-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:41","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6895","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-2.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:07","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6896","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-20-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:57","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6897","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-20-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6898","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-20-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6899","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-20-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:57","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6900","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-20-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:57","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6901","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-20.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:21","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6902","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-3-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:38","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6903","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-3-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6904","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-3-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6905","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-3-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:38","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6906","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-3-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:39","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6907","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-3.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:13","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6908","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-4-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:36","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6909","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-4-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6910","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-4-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:24","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6911","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-4-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:36","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6912","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-4-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:37","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6913","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-4.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:14","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6914","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-5-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:34","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6915","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-5-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:25","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6916","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-5-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:25","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6917","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-5-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:34","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6918","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-5-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:34","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6919","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-5.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:14","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6920","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-6-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6921","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-6-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:25","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6922","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-6-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:25","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6923","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-6-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6924","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-6-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6925","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-6.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:14","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6926","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-7-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:29","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6927","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-7-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:25","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6928","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-7-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:25","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6929","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-7-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:29","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6930","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-7-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:29","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6931","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-7.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:14","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6932","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-8-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:27","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6933","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-8-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:26","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6934","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-8-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:26","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6935","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-8-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:27","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6936","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-8-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:27","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6937","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-8.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:15","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6938","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-9-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:25","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6939","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-9-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:26","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6940","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-9-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:26","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6941","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-9-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:25","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6942","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-9-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:25","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6943","static_file","/wp-content/uploads/2021/08/plants-ecommerce-product-featured-img-9.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:15","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6944","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-011-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6945","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-011-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:48","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6946","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-011-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:48","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6947","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-011-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6948","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-011-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:18","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6949","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-011.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:42","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6950","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-1-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:28","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6951","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-1-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:48","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6952","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-1-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:48","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6953","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-1-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:28","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6954","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-1-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:28","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6955","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:40","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6956","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-10-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:52","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6957","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-10-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:43","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6958","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-10-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:43","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6959","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-10-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:52","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6960","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-10-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:52","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6961","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-10.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:34","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6962","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-12-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6963","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-12-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:44","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6964","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-12-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:44","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6965","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-12-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6966","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-12-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:50","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6967","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-12.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:34","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6968","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-13-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:47","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6969","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-13-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:44","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6970","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-13-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:44","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6971","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-13-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:47","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6972","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-13-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:47","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6973","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-13.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:35","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6974","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-14-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:45","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6975","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-14-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:45","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6976","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-14-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:45","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6977","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-14-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:45","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6978","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-14-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:45","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6979","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-14.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:38","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6980","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-15-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:43","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6981","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-15-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:45","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6982","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-15-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:45","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6983","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-15-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:43","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6984","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-15-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:43","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6985","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-15.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:38","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6986","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-16-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:39","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6987","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-16-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6988","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-16-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6989","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-16-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:39","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6990","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-16-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:39","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6991","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-16.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:38","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6992","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-17-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:37","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6993","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-17-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6994","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-17-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:46","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6995","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-17-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:37","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6996","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-17-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:37","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6997","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-17.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:38","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6998","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-18-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:34","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6999","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-18-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:47","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7000","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-18-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:47","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/