

DROP TABLE IF EXISTS `webtoffee_wc_order_stats` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_paid` datetime DEFAULT '0000-00-00 00:00:00',
  `date_completed` datetime DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT 0,
  `total_sales` double NOT NULL DEFAULT 0,
  `tax_total` double NOT NULL DEFAULT 0,
  `shipping_total` double NOT NULL DEFAULT 0,
  `net_total` double NOT NULL DEFAULT 0,
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wc_order_stats` VALUES
("1665","0","2023-06-25 16:57:36","2023-06-25 16:57:36","2023-06-25 16:57:36","2023-06-25 17:01:04","3","0","0","0","0","1","wc-completed","14");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1663","0","2023-06-25 04:20:17","2023-06-25 04:20:17","2023-06-25 04:20:17","2023-06-25 04:37:19","1","0","0","0","0","1","wc-completed","14");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1662","0","2023-06-25 04:16:14","2023-06-25 04:16:14","2023-06-25 04:16:15","","1","0","0","0","0","1","wc-cancelled","14");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1661","0","2023-06-24 14:43:53","2023-06-24 14:43:53","2023-06-24 14:43:53","2023-06-24 14:46:07","1","0","0","0","0","0","wc-completed","15");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1660","0","2023-06-23 15:22:34","2023-06-23 15:22:34","2023-06-23 16:14:41","2023-06-23 16:14:41","1","7","0","0","7","1","wc-completed","14");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1659","0","2023-06-23 15:20:12","2023-06-23 15:20:12","2023-06-23 15:20:13","2023-06-23 16:15:31","1","0","0","0","0","1","wc-completed","14");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1658","0","2023-06-23 15:18:01","2023-06-23 15:18:01","","","1","7","0","0","7","1","wc-cancelled","14");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1657","0","2023-06-22 17:01:23","2023-06-22 17:01:23","","","1","8","0","0","8","1","wc-cancelled","11");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1652","0","2023-06-22 16:06:37","2023-06-22 16:06:37","2023-06-22 16:06:37","","1","0","0","0","0","0","wc-processing","10");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1651","0","2023-06-22 15:30:34","2023-06-22 15:30:34","2023-06-22 15:30:34","2023-06-22 15:31:42","2","0","0","0","0","0","wc-completed","14");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1650","0","2023-06-22 09:56:09","2023-06-22 09:56:09","2023-06-22 09:56:09","2023-06-22 10:00:44","1","0","0","0","0","0","wc-completed","13");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1649","0","2023-06-22 09:39:14","2023-06-22 09:39:14","2023-06-22 09:39:15","2023-06-22 09:43:17","2","0","0","0","0","0","wc-completed","12");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1647","0","2023-06-22 09:16:13","2023-06-22 09:16:13","2023-06-22 09:16:13","2023-06-25 04:24:06","2","0","0","0","0","1","wc-completed","11");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1648","0","2023-06-22 09:21:21","2023-06-22 09:21:21","2023-06-22 09:21:21","2023-06-28 03:46:04","1","0","0","0","0","1","wc-completed","11");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1646","0","2023-06-22 09:08:46","2023-06-22 09:08:46","2023-06-22 09:08:46","2023-06-22 09:10:19","1","0","0","0","0","0","wc-completed","11");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1645","0","2023-06-22 08:38:40","2023-06-22 08:38:40","","","1","7","0","0","7","0","wc-cancelled","10");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1664","0","2023-06-25 04:25:11","2023-06-25 04:25:11","2023-06-25 04:25:11","","2","0","0","0","0","1","wc-cancelled","14");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1667","0","2023-06-27 15:10:15","2023-06-27 15:10:15","","","1","8","0","0","8","1","wc-cancelled","11");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1670","0","2023-06-28 03:05:27","2023-06-28 03:05:27","","","5","28","0","0","28","1","wc-on-hold","11");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1671","0","2023-06-28 03:10:58","2023-06-28 03:10:58","2023-06-28 03:10:58","2023-06-28 03:45:39","2","0","0","0","0","1","wc-completed","11");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1672","0","2023-06-28 03:42:42","2023-06-28 03:42:42","2023-06-28 03:42:42","2023-06-28 03:44:35","10","0","0","0","0","0","wc-completed","16");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1673","0","2023-06-30 05:57:27","2023-06-30 05:57:27","2023-06-30 05:57:27","2023-06-30 06:04:58","1","0","0","0","0","0","wc-completed","17");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1675","0","2023-08-01 08:09:07","2023-08-01 08:09:07","","","1","7","0","0","7","1","wc-cancelled","18");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1676","0","2023-08-01 08:09:56","2023-08-01 08:09:56","2023-08-01 08:09:56","","1","0","0","0","0","0","wc-processing","18");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1678","0","2023-08-05 08:43:52","2023-08-05 08:43:52","2023-08-05 08:43:52","2023-08-05 08:48:55","1","0","0","0","0","0","wc-completed","19");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1684","0","2023-08-26 10:39:46","2023-08-26 10:39:46","2023-08-26 10:39:46","","2","0","0","0","0","0","wc-processing","20");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1683","0","2023-08-17 03:20:24","2023-08-17 03:20:24","","","1","19","0","0","19","1","wc-pending","20");/*END*/
INSERT INTO `webtoffee_wc_order_stats` VALUES
("1679","0","2023-08-15 11:51:26","2023-08-15 11:51:26","2023-08-15 11:51:27","2023-08-15 11:55:36","2","0","0","0","0","0","wc-completed","21");/*END*/