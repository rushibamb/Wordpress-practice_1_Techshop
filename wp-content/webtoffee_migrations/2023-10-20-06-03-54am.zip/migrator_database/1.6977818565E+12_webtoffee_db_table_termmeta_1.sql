

DROP TABLE IF EXISTS `webtoffee_termmeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO `webtoffee_termmeta` VALUES
("1","23","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("2","23","_astra_sites_imported_term","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("3","24","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("4","24","_astra_sites_imported_term","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("5","25","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("6","25","_astra_sites_imported_term","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("7","26","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("8","26","_astra_sites_imported_term","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("9","27","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("10","27","_astra_sites_imported_term","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("11","28","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("12","28","_astra_sites_imported_term","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("13","29","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("14","29","_astra_sites_imported_term","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("15","30","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("16","30","_astra_sites_imported_term","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("17","31","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("18","31","_astra_sites_imported_term","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("19","32","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("20","32","_astra_sites_imported_term","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("21","33","_astra_sites_imported_term","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("22","23","product_count_product_cat","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("23","27","product_count_product_cat","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("24","28","product_count_product_cat","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("25","26","product_count_product_cat","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("26","29","product_count_product_cat","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("27","31","product_count_product_cat","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("28","24","product_count_product_cat","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("29","25","product_count_product_cat","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("30","32","product_count_product_cat","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("31","30","product_count_product_cat","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("32","23","thumbnail_id","309");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("33","24","thumbnail_id","306");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("34","25","thumbnail_id","305");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("35","26","thumbnail_id","310");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("36","27","thumbnail_id","741");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("37","28","thumbnail_id","308");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("38","29","thumbnail_id","742");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("39","30","thumbnail_id","743");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("40","31","thumbnail_id","307");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("41","32","thumbnail_id","744");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("42","21","product_count_product_cat","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("43","36","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("44","36","product_count_product_cat","3");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("45","37","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("46","38","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("47","39","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("48","40","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("49","41","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("50","42","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("51","41","product_count_product_cat","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("52","38","product_count_product_cat","2");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("53","37","product_count_product_cat","2");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("54","42","product_count_product_cat","1");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("55","47","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("56","48","order","0");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("57","48","product_count_product_cat","6");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("58","47","product_count_product_cat","6");/*END*/
INSERT INTO `webtoffee_termmeta` VALUES
("59","49","product_count_product_tag","1");/*END*/