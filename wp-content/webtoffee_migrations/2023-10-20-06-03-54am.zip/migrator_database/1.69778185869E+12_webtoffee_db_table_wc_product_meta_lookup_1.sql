

DROP TABLE IF EXISTS `webtoffee_wc_product_meta_lookup` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT 0,
  `downloadable` tinyint(1) DEFAULT 0,
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT 0,
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `total_sales` bigint(20) DEFAULT 0,
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("208","","0","1","99.0000","99.0000","1","","instock","0","0.00","4","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("219","","0","0","79.9000","79.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("220","","0","1","19.0000","19.0000","1","","instock","0","0.00","9","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("221","","0","0","49.9000","49.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("223","","0","0","49.0000","49.0000","1","","instock","1","5.00","2","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("224","","0","0","124.9000","124.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("229","","0","0","104.9000","104.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("230","","0","0","24.0000","24.0000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("231","","0","0","109.9000","109.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("232","","0","0","284.9000","284.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("233","","0","0","74.9000","74.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("234","","0","0","32.9000","32.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("235","","0","0","94.9000","94.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("237","","0","0","114.9000","114.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("238","","0","0","79.9000","79.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("239","","0","0","249.9000","249.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("240","","0","0","124.9000","124.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("241","","0","0","224.9000","224.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("242","","0","0","64.0000","64.0000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("243","","0","0","84.9000","84.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("683","","0","0","24.9000","24.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("688","","0","0","48.9000","48.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("690","","0","0","20.9000","20.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("691","","0","0","18.9000","18.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("698","","0","0","11.9000","11.9000","0","","instock","0","","","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("1554","","0","0","19.0000","19.0000","1","","instock","0","0.00","3","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("1620","","1","0","29.0000","29.0000","1","","instock","0","0.00","1","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("1626","","1","0","7.0000","7.0000","1","","instock","0","0.00","15","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("1630","","1","0","8.0000","8.0000","1","","instock","2","5.00","21","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("1632","","1","0","35.0000","35.0000","1","","instock","0","0.00","3","taxable","");/*END*/
INSERT INTO `webtoffee_wc_product_meta_lookup` VALUES
("1637","","1","0","29.0000","29.0000","1","","instock","0","0.00","2","taxable","");/*END*/