
INSERT INTO `webtoffee_urls` VALUES
("7001","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-18-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:34","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7002","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-18-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:35","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7003","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-18.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:39","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7004","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-19-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7005","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-19-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:47","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7006","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-19-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:47","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7007","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-19-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7008","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-19-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7009","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-19.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:39","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7010","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-2-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:25","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7011","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-2-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:48","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7012","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-2-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:48","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7013","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-2-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:25","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7014","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-2-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:26","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7015","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-2.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:40","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7016","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-20-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7017","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-20-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:47","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7018","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-20-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:47","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7019","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-20-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7020","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-20-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7021","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-20.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:40","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7022","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-3-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:21","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7023","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-3-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:48","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7024","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-3-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:48","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7025","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-3-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:21","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7026","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-3-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:21","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7027","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-3.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:41","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7028","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-4-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:10","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7029","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-4-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:40","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7030","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-4-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:40","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7031","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-4-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:10","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7032","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-4-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:10","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7033","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-4.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7034","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-5-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:07","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7035","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-5-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:41","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7036","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-5-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:40","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7037","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-5-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:07","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7038","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-5-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:07","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7039","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-5.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:31","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7040","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-6-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:05","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7041","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-6-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:41","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7042","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-6-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:41","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7043","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-6-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:05","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7044","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-6-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:05","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7045","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-6.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:31","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7046","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-7-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:03","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7047","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-7-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:42","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7048","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-7-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:42","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7049","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-7-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:03","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7050","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-7-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:03","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7051","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-7.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:33","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7052","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-8-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:58","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7053","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-8-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:42","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7054","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-8-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:42","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7055","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-8-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:58","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7056","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-8-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:58","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7057","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-8.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:33","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7058","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-9-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:55","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7059","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-9-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:43","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7060","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-9-200x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:43","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7061","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-9-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:55","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7062","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-9-600x900.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:55","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7063","static_file","/wp-content/uploads/2021/08/plants-shop-product-gallery-img-9.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:34","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7064","static_file","/wp-content/uploads/2021/08/plants-store-about-video-img-thumb-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7065","static_file","/wp-content/uploads/2021/08/plants-store-about-video-img-thumb-1024x512.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7066","static_file","/wp-content/uploads/2021/08/plants-store-about-video-img-thumb-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7067","static_file","/wp-content/uploads/2021/08/plants-store-about-video-img-thumb-300x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:31","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7068","static_file","/wp-content/uploads/2021/08/plants-store-about-video-img-thumb-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7069","static_file","/wp-content/uploads/2021/08/plants-store-about-video-img-thumb-600x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:49","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7070","static_file","/wp-content/uploads/2021/08/plants-store-about-video-img-thumb-768x384.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:32","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7071","static_file","/wp-content/uploads/2021/08/plants-store-about-video-img-thumb.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:23","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7072","static_file","/wp-content/uploads/2021/08/plants-store-blog-featured-img-1-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:55","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7073","static_file","/wp-content/uploads/2021/08/plants-store-blog-featured-img-1-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7074","static_file","/wp-content/uploads/2021/08/plants-store-blog-featured-img-1-300x201.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7075","static_file","/wp-content/uploads/2021/08/plants-store-blog-featured-img-1-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:55","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7076","static_file","/wp-content/uploads/2021/08/plants-store-blog-featured-img-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:21","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7077","static_file","/wp-content/uploads/2021/08/plants-store-blog-featured-img-2-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7078","static_file","/wp-content/uploads/2021/08/plants-store-blog-featured-img-2-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7079","static_file","/wp-content/uploads/2021/08/plants-store-blog-featured-img-2-300x201.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:30","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7080","static_file","/wp-content/uploads/2021/08/plants-store-blog-featured-img-2-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:53","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7081","static_file","/wp-content/uploads/2021/08/plants-store-blog-featured-img-2.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:22","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7082","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-1-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:50","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7083","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-1-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:52","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7084","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-1-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:50","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7085","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:45","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7086","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-2-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:01","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7087","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-2-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:50","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7088","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-2-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:30:01","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7089","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-2.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:44","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7090","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-3-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:56","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7091","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-3-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:51","0000-00-00 00:00:00","2023-09-07 12:54:42");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7092","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-3-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:56","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7093","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-3.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:45","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7094","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-4-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:58","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7095","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-4-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:51","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7096","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-4-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:58","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7097","static_file","/wp-content/uploads/2021/08/plants-store-categories-img-4.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:44","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7098","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-1-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:39","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7099","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-1-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:33","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7100","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-1-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:39","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7101","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:24","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7102","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-2-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:37","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7103","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-2-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7104","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-2-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:37","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7105","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-2.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:25","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7106","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-3-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:33","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7107","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-3-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:35","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7108","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-3-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:33","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7109","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-3.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:25","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7110","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-4-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:31","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7111","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-4-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:35","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7112","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-4-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:31","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7113","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-4.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:26","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7114","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-5-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:29","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7115","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-5-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:36","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7116","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-5-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:29","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7117","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-5.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:26","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7118","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-6-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:42","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7119","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-6-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:33","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7120","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-6-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:42","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7121","static_file","/wp-content/uploads/2021/08/plants-store-gallery-img-6.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:24","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7122","static_file","/wp-content/uploads/2021/08/plants-store-gift-card-section-img-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:15","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7123","static_file","/wp-content/uploads/2021/08/plants-store-gift-card-section-img-1024x320.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:38","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7124","static_file","/wp-content/uploads/2021/08/plants-store-gift-card-section-img-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:38","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7125","static_file","/wp-content/uploads/2021/08/plants-store-gift-card-section-img-1536x480.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:39","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7126","static_file","/wp-content/uploads/2021/08/plants-store-gift-card-section-img-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:15","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7127","static_file","/wp-content/uploads/2021/08/plants-store-gift-card-section-img-300x94.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:38","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7128","static_file","/wp-content/uploads/2021/08/plants-store-gift-card-section-img-600x188.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:15","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7129","static_file","/wp-content/uploads/2021/08/plants-store-gift-card-section-img-768x240.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:38","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7130","static_file","/wp-content/uploads/2021/08/plants-store-gift-card-section-img.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:29","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7131","static_file","/wp-content/uploads/2021/08/plants-store-hero-img-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:27","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7132","static_file","/wp-content/uploads/2021/08/plants-store-hero-img-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:36","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7133","static_file","/wp-content/uploads/2021/08/plants-store-hero-img-300x209.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:36","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7134","static_file","/wp-content/uploads/2021/08/plants-store-hero-img-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:27","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7135","static_file","/wp-content/uploads/2021/08/plants-store-hero-img-600x419.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:27","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7136","static_file","/wp-content/uploads/2021/08/plants-store-hero-img-768x536.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:36","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7137","static_file","/wp-content/uploads/2021/08/plants-store-hero-img.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:26","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7138","static_file","/wp-content/uploads/2021/08/plants-store-hero-section-img-bg-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:47","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7139","static_file","/wp-content/uploads/2021/08/plants-store-hero-section-img-bg-1024x512.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:53","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7140","static_file","/wp-content/uploads/2021/08/plants-store-hero-section-img-bg-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:53","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7141","static_file","/wp-content/uploads/2021/08/plants-store-hero-section-img-bg-1536x768.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:54","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7142","static_file","/wp-content/uploads/2021/08/plants-store-hero-section-img-bg-300x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:52","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7143","static_file","/wp-content/uploads/2021/08/plants-store-hero-section-img-bg-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:47","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7144","static_file","/wp-content/uploads/2021/08/plants-store-hero-section-img-bg-600x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:47","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7145","static_file","/wp-content/uploads/2021/08/plants-store-hero-section-img-bg-768x384.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:53","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7146","static_file","/wp-content/uploads/2021/08/plants-store-hero-section-img-bg.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:45","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7147","static_file","/wp-content/uploads/2021/08/plants-store-new-plants-section-img-bg-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:51","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7148","static_file","/wp-content/uploads/2021/08/plants-store-new-plants-section-img-bg-1024x512.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:31","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7149","static_file","/wp-content/uploads/2021/08/plants-store-new-plants-section-img-bg-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:31","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7150","static_file","/wp-content/uploads/2021/08/plants-store-new-plants-section-img-bg-1536x768.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:31","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7151","static_file","/wp-content/uploads/2021/08/plants-store-new-plants-section-img-bg-300x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:31","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7152","static_file","/wp-content/uploads/2021/08/plants-store-new-plants-section-img-bg-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:51","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7153","static_file","/wp-content/uploads/2021/08/plants-store-new-plants-section-img-bg-600x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:51","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7154","static_file","/wp-content/uploads/2021/08/plants-store-new-plants-section-img-bg-768x384.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:31","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7155","static_file","/wp-content/uploads/2021/08/plants-store-new-plants-section-img-bg.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:22","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7156","static_file","/wp-content/uploads/2021/08/plants-store-owner-avatar-img.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7157","static_file","/wp-content/uploads/2021/08/plants-store-story-section-img-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7158","static_file","/wp-content/uploads/2021/08/plants-store-story-section-img-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:39","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7159","static_file","/wp-content/uploads/2021/08/plants-store-story-section-img-300x250.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:39","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7160","static_file","/wp-content/uploads/2021/08/plants-store-story-section-img-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7161","static_file","/wp-content/uploads/2021/08/plants-store-story-section-img-600x500.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:13","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7162","static_file","/wp-content/uploads/2021/08/plants-store-story-section-img-768x640.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:40","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7163","static_file","/wp-content/uploads/2021/08/plants-store-story-section-img.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:30","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7164","static_file","/wp-content/uploads/2021/08/plants-store-testimonial-avatar-img.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:06","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7165","static_file","/wp-content/uploads/2021/08/plants-store-testimonials-avatar-img-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:29","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7166","static_file","/wp-content/uploads/2021/08/plants-store-testimonials-avatar-img-2.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:28","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7167","static_file","/wp-content/uploads/2021/08/produuct-description-bg-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:33","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7168","static_file","/wp-content/uploads/2021/08/produuct-description-bg-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:31:00","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7169","static_file","/wp-content/uploads/2021/08/produuct-description-bg-300x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:31:00","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7170","static_file","/wp-content/uploads/2021/08/produuct-description-bg-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:33","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7171","static_file","/wp-content/uploads/2021/08/produuct-description-bg-600x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:33","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7172","static_file","/wp-content/uploads/2021/08/produuct-description-bg-768x384.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:31:00","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7173","static_file","/wp-content/uploads/2021/08/produuct-description-bg.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:48","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7174","static_file","/wp-content/uploads/2021/08/EXP-401_Fill.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 10:08:06","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7175","static_file","/wp-content/uploads/2021/08/plants-store-new-plants-section-img-bg.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:04","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7176","static_file","/wp-content/uploads/2021/08/quote-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:04","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7177","static_file","/wp-content/uploads/2021/08/site-logo-white.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:05","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7178","static_file","/wp-content/uploads/2021/08/site-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:05","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7179","static_file","/wp-content/uploads/2021/09/hero-section-bg-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:38","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7180","static_file","/wp-content/uploads/2021/09/hero-section-bg-1024x576.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:57","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7181","static_file","/wp-content/uploads/2021/09/hero-section-bg-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:57","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7182","static_file","/wp-content/uploads/2021/09/hero-section-bg-1536x864.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:58","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7183","static_file","/wp-content/uploads/2021/09/hero-section-bg-300x169.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:57","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7184","static_file","/wp-content/uploads/2021/09/hero-section-bg-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:38","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7185","static_file","/wp-content/uploads/2021/09/hero-section-bg-600x338.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:38","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7186","static_file","/wp-content/uploads/2021/09/hero-section-bg-768x432.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:57","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7187","static_file","/wp-content/uploads/2021/09/hero-section-bg.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:48","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7188","static_file","/wp-content/uploads/2021/09/plant-shop-social-img-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:35","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7189","static_file","/wp-content/uploads/2021/09/plant-shop-social-img-1024x538.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:59","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7190","static_file","/wp-content/uploads/2021/09/plant-shop-social-img-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:59","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7191","static_file","/wp-content/uploads/2021/09/plant-shop-social-img-300x158.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:59","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7192","static_file","/wp-content/uploads/2021/09/plant-shop-social-img-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:35","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7193","static_file","/wp-content/uploads/2021/09/plant-shop-social-img-600x315.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:29:35","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7194","static_file","/wp-content/uploads/2021/09/plant-shop-social-img-768x403.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:31:00","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7195","static_file","/wp-content/uploads/2021/09/plant-shop-social-img.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:48","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7196","static_file","/wp-content/uploads/2022/09/modern-checkout-two-columns-template-guarantee-badge-1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:56","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7197","static_file","/wp-content/uploads/2022/09/modern-checkout-two-columns-template-guarantee-badge.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:55","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7198","static_file","/wp-content/uploads/2022/09/digital-marketing-guide-avatar-image-2-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:56","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7199","static_file","/wp-content/uploads/2022/09/digital-marketing-guide-avatar-image-2.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:54","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7200","static_file","/wp-content/uploads/2022/09/modern-checkout-two-columns-template-avatar-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:55","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7201","static_file","/wp-content/uploads/2022/09/modern-checkout-two-columns-template-avatar.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:54","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7202","static_file","/wp-content/uploads/2022/09/global-checkout-template-logo-1.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:55","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7203","static_file","/wp-content/uploads/2022/09/global-checkout-template-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:19:53","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7204","static_file","/wp-content/uploads/2023/04/42796435-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 05:13:26","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7205","static_file","/wp-content/uploads/2023/04/42796435-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 05:13:26","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7206","static_file","/wp-content/uploads/2023/04/42796435-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 05:13:26","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7207","static_file","/wp-content/uploads/2023/04/42796435.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 05:13:26","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7208","static_file","/wp-content/uploads/2023/04/PEN-200_Fill-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:59:57","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7209","static_file","/wp-content/uploads/2023/04/PEN-200_Fill-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:59:57","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7210","static_file","/wp-content/uploads/2023/04/PEN-200_Fill.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:59:57","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7211","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:51:18","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7212","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1-1024x723.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:51:17","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7213","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:51:18","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7214","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1-300x212.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:51:17","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7215","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:51:18","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7216","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1-600x424.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:51:18","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7217","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1-768x542.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:51:18","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7218","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:51:17","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7219","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:50:24","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7220","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1024x723.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:50:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7221","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:50:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7222","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-300x212.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:50:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7223","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:50:24","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7224","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-600x424.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:50:24","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7225","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-768x542.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:50:24","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7226","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:50:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7227","static_file","/wp-content/uploads/2023/04/cropped-removebackground-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:02","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7228","static_file","/wp-content/uploads/2023/04/cropped-removebackground-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:02","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7229","static_file","/wp-content/uploads/2023/04/cropped-removebackground-180x180.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:02","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7230","static_file","/wp-content/uploads/2023/04/cropped-removebackground-192x192.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:02","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7231","static_file","/wp-content/uploads/2023/04/cropped-removebackground-270x270.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:02","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7232","static_file","/wp-content/uploads/2023/04/cropped-removebackground-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:02","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7233","static_file","/wp-content/uploads/2023/04/cropped-removebackground-32x32.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:02","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7234","static_file","/wp-content/uploads/2023/04/cropped-removebackground.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:31:02","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7235","static_file","/wp-content/uploads/2023/04/modern-checkout-two-columns-template-guarantee-badge-1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:26:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7236","static_file","/wp-content/uploads/2023/04/modern-checkout-two-columns-template-guarantee-badge-2.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:14","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7237","static_file","/wp-content/uploads/2023/04/modern-checkout-two-columns-template-guarantee-badge.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:13","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7238","static_file","/wp-content/uploads/2023/04/removebackground-1-1-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:36","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7239","static_file","/wp-content/uploads/2023/04/removebackground-1-1-1024x665.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:14","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7240","static_file","/wp-content/uploads/2023/04/removebackground-1-1-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:14","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7241","static_file","/wp-content/uploads/2023/04/removebackground-1-1-300x195.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:14","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7242","static_file","/wp-content/uploads/2023/04/removebackground-1-1-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:36","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7243","static_file","/wp-content/uploads/2023/04/removebackground-1-1-600x390.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:37","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7244","static_file","/wp-content/uploads/2023/04/removebackground-1-1-768x499.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:14","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7245","static_file","/wp-content/uploads/2023/04/removebackground-1-1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:14","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7246","static_file","/wp-content/uploads/2023/04/removebackground-1-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:43","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7247","static_file","/wp-content/uploads/2023/04/removebackground-1-1024x665.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:13","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7248","static_file","/wp-content/uploads/2023/04/removebackground-1-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:13","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7249","static_file","/wp-content/uploads/2023/04/removebackground-1-300x195.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7250","static_file","/wp-content/uploads/2023/04/removebackground-1-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:43","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7251","static_file","/wp-content/uploads/2023/04/removebackground-1-600x390.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:43","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7252","static_file","/wp-content/uploads/2023/04/removebackground-1-768x499.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:13","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7253","static_file","/wp-content/uploads/2023/04/removebackground-1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7254","static_file","/wp-content/uploads/2023/04/removebackground-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:33:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7255","static_file","/wp-content/uploads/2023/04/removebackground-1024x665.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:33:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7256","static_file","/wp-content/uploads/2023/04/removebackground-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:33:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7257","static_file","/wp-content/uploads/2023/04/removebackground-185x120.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:33:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7258","static_file","/wp-content/uploads/2023/04/removebackground-300x195.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:33:22","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7259","static_file","/wp-content/uploads/2023/04/removebackground-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:33:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7260","static_file","/wp-content/uploads/2023/04/removebackground-600x390.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:33:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7261","static_file","/wp-content/uploads/2023/04/removebackground-768x499.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:33:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7262","static_file","/wp-content/uploads/2023/04/removebackground.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:14:18","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7263","static_file","/wp-content/uploads/2023/04/Group-107-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:21","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7264","static_file","/wp-content/uploads/2023/04/Group-107-1024x512.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7265","static_file","/wp-content/uploads/2023/04/Group-107-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7266","static_file","/wp-content/uploads/2023/04/Group-107-300x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7267","static_file","/wp-content/uploads/2023/04/Group-107-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:21","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7268","static_file","/wp-content/uploads/2023/04/Group-107-600x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:21","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7269","static_file","/wp-content/uploads/2023/04/Group-107-768x384.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7270","static_file","/wp-content/uploads/2023/04/Group-107.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7271","static_file","/wp-content/uploads/2023/04/davidsir-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 05:19:25","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7272","static_file","/wp-content/uploads/2023/04/davidsir-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 05:19:25","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7273","static_file","/wp-content/uploads/2023/04/davidsir.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 05:19:25","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7274","static_file","/wp-content/uploads/2023/04/digital-marketing-guide-avatar-image-2-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:26:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7275","static_file","/wp-content/uploads/2023/04/footer-background-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:45","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7276","static_file","/wp-content/uploads/2023/04/footer-background-1024x576.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7277","static_file","/wp-content/uploads/2023/04/footer-background-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7278","static_file","/wp-content/uploads/2023/04/footer-background-1536x864.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7279","static_file","/wp-content/uploads/2023/04/footer-background-300x169.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7280","static_file","/wp-content/uploads/2023/04/footer-background-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:45","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7281","static_file","/wp-content/uploads/2023/04/footer-background-600x338.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:46","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7282","static_file","/wp-content/uploads/2023/04/footer-background-768x432.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7283","static_file","/wp-content/uploads/2023/04/footer-background.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7284","static_file","/wp-content/uploads/2023/04/hero-section-bg-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:19:00","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7285","static_file","/wp-content/uploads/2023/04/hero-section-bg-1024x576.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:11","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7286","static_file","/wp-content/uploads/2023/04/hero-section-bg-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:11","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7287","static_file","/wp-content/uploads/2023/04/hero-section-bg-1536x864.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:11","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7288","static_file","/wp-content/uploads/2023/04/hero-section-bg-300x169.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:10","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7289","static_file","/wp-content/uploads/2023/04/hero-section-bg-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:19:00","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7290","static_file","/wp-content/uploads/2023/04/hero-section-bg-600x338.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:19:00","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7291","static_file","/wp-content/uploads/2023/04/hero-section-bg-768x432.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:11","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7292","static_file","/wp-content/uploads/2023/04/hero-section-bg.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:10","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7293","static_file","/wp-content/uploads/2023/04/kali-cubism-16x9-1-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:30:32","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7294","static_file","/wp-content/uploads/2023/04/kali-cubism-16x9-1-1024x576.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:30:29","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7295","static_file","/wp-content/uploads/2023/04/kali-cubism-16x9-1-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:30:30","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7296","static_file","/wp-content/uploads/2023/04/kali-cubism-16x9-1-1536x864.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:30:30","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7297","static_file","/wp-content/uploads/2023/04/kali-cubism-16x9-1-2048x1152.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:30:31","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7298","static_file","/wp-content/uploads/2023/04/kali-cubism-16x9-1-300x169.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:30:29","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7299","static_file","/wp-content/uploads/2023/04/kali-cubism-16x9-1-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:30:31","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7300","static_file","/wp-content/uploads/2023/04/kali-cubism-16x9-1-600x338.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:30:31","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7301","static_file","/wp-content/uploads/2023/04/kali-cubism-16x9-1-768x432.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:30:30","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7302","static_file","/wp-content/uploads/2023/04/kali-cubism-16x9-1-scaled.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:30:29","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7303","static_file","/wp-content/uploads/2023/04/kali-cubism-16x9-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:30:28","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7304","static_file","/wp-content/uploads/2023/04/modern-checkout-two-columns-template-avatar-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:26:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7305","static_file","/wp-content/uploads/2023/04/modern-checkout-two-columns-template-avatar-2.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:14","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7306","static_file","/wp-content/uploads/2023/04/modern-checkout-two-columns-template-avatar.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:13","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7307","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-1-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:14","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7308","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-1-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7309","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-1-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:14","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7310","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7311","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-2-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7312","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-2-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7313","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-2-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7314","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-2.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7315","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-3-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:10","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7316","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-3-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7317","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-3-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:10","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7318","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-3.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7319","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-4-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:08","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7320","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-4-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7321","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-4-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:08","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7322","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-4.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7323","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-5-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:19:04","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7324","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-5-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:21","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7325","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-5-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:19:04","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7326","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-5.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7327","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-6-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:17","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7328","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-6-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7329","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-6-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:17","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7330","static_file","/wp-content/uploads/2023/04/plants-store-gallery-img-6.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7331","static_file","/wp-content/uploads/2023/04/plants-store-owner-avatar-img.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7332","static_file","/wp-content/uploads/2023/04/plants-store-story-section-img-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:57","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7333","static_file","/wp-content/uploads/2023/04/plants-store-story-section-img-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:11","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7334","static_file","/wp-content/uploads/2023/04/plants-store-story-section-img-300x250.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:11","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7335","static_file","/wp-content/uploads/2023/04/plants-store-story-section-img-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:57","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7336","static_file","/wp-content/uploads/2023/04/plants-store-story-section-img-600x500.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:18:57","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7337","static_file","/wp-content/uploads/2023/04/plants-store-story-section-img-768x640.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:11","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7338","static_file","/wp-content/uploads/2023/04/plants-store-story-section-img.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:11","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7339","static_file","/wp-content/uploads/2023/04/plants-store-testimonial-avatar-img.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:11","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7340","static_file","/wp-content/uploads/2023/04/plants-store-testimonials-avatar-img-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7341","static_file","/wp-content/uploads/2023/04/plants-store-testimonials-avatar-img-2.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:12","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7342","static_file","/wp-content/uploads/2023/04/produuct-description-bg-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7343","static_file","/wp-content/uploads/2023/04/produuct-description-bg-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:28:03","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7344","static_file","/wp-content/uploads/2023/04/produuct-description-bg-300x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:28:03","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7345","static_file","/wp-content/uploads/2023/04/produuct-description-bg-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7346","static_file","/wp-content/uploads/2023/04/produuct-description-bg-600x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:24:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7347","static_file","/wp-content/uploads/2023/04/produuct-description-bg-768x384.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:28:03","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7348","static_file","/wp-content/uploads/2023/04/produuct-description-bg.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:28:03","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7349","static_file","/wp-content/uploads/2023/04/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-100x100.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:29:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7350","static_file","/wp-content/uploads/2023/04/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-150x150.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:29:33","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7351","static_file","/wp-content/uploads/2023/04/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-161x300.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:29:33","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7352","static_file","/wp-content/uploads/2023/04/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-300x300.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:29:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7353","static_file","/wp-content/uploads/2023/04/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-548x1024.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:29:33","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7354","static_file","/wp-content/uploads/2023/04/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-600x1120.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:29:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7355","static_file","/wp-content/uploads/2023/04/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-768x1434.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:29:33","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7356","static_file","/wp-content/uploads/2023/04/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-823x1536.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:29:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7357","static_file","/wp-content/uploads/2023/04/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:29:33","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7358","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1-100x100.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:32:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7359","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1-150x150.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:32:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7360","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1-300x212.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:32:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7361","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1-300x300.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:32:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7362","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1-600x424.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:32:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7363","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-1.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:32:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7364","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-100x100.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:32:30","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7365","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-150x150.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:32:30","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7366","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-300x212.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:32:30","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7367","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-300x300.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:32:30","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7368","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-600x424.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:32:30","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7369","static_file","/wp-content/uploads/2023/04/Premium-Vector-Circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:32:30","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7370","static_file","/wp-content/uploads/2023/04/AT-3.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 06:08:10","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7371","static_file","/wp-content/uploads/2023/04/WEB-300_Fill.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:57:11","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7372","static_file","/wp-content/uploads/2023/04/global-checkout-template-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:14","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7373","static_file","/wp-content/uploads/2023/04/l1.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 07:59:38","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7374","static_file","/wp-content/uploads/2023/05/buy-instagram-followers-from-likes-io-site-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:27:21","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7375","static_file","/wp-content/uploads/2023/05/buy-instagram-followers-from-likes-io-site-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:27:19","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7376","static_file","/wp-content/uploads/2023/05/buy-instagram-followers-from-likes-io-site-300x225.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:27:19","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7377","static_file","/wp-content/uploads/2023/05/buy-instagram-followers-from-likes-io-site-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:27:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7378","static_file","/wp-content/uploads/2023/05/buy-instagram-followers-from-likes-io-site-600x450.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:27:21","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7379","static_file","/wp-content/uploads/2023/05/buy-instagram-followers-from-likes-io-site-768x576.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:27:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7380","static_file","/wp-content/uploads/2023/05/buy-instagram-followers-from-likes-io-site.png","","","0","1","1","","0000-00-00 00:00:00","","2023-05-22 05:27:19","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7381","static_file","/wp-content/uploads/2023/06/social-social-network-social-network-service-1206610-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:39:07","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7382","static_file","/wp-content/uploads/2023/06/social-social-network-social-network-service-1206610-1024x796.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:39:07","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7383","static_file","/wp-content/uploads/2023/06/social-social-network-social-network-service-1206610-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:39:07","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7384","static_file","/wp-content/uploads/2023/06/social-social-network-social-network-service-1206610-300x233.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:39:06","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7385","static_file","/wp-content/uploads/2023/06/social-social-network-social-network-service-1206610-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:39:07","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7386","static_file","/wp-content/uploads/2023/06/social-social-network-social-network-service-1206610-600x466.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:39:07","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7387","static_file","/wp-content/uploads/2023/06/social-social-network-social-network-service-1206610-768x597.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:39:07","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7388","static_file","/wp-content/uploads/2023/06/social-social-network-social-network-service-1206610.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:39:06","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7389","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-1-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:45","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7390","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-1-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:45","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7391","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-1-300x267.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:45","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7392","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-1-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:45","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7393","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:45","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7394","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-2-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:46","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7395","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-2-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:46","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7396","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-2-300x267.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:46","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7397","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-2-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:46","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7398","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-2.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:46","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7399","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-3-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:46","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7400","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-3-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:46","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7401","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-3-300x267.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:46","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7402","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-3-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:46","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7403","static_file","/wp-content/uploads/2023/06/web3-crash-course-benefits-3.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:46","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7404","static_file","/wp-content/uploads/2023/06/website-parts-social-media-2084779-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:38:09","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7405","static_file","/wp-content/uploads/2023/06/website-parts-social-media-2084779-1024x682.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:38:08","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7406","static_file","/wp-content/uploads/2023/06/website-parts-social-media-2084779-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:38:08","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7407","static_file","/wp-content/uploads/2023/06/website-parts-social-media-2084779-300x200.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:38:07","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7408","static_file","/wp-content/uploads/2023/06/website-parts-social-media-2084779-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:38:09","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7409","static_file","/wp-content/uploads/2023/06/website-parts-social-media-2084779-600x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:38:09","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7410","static_file","/wp-content/uploads/2023/06/website-parts-social-media-2084779-768x512.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:38:09","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7411","static_file","/wp-content/uploads/2023/06/website-parts-social-media-2084779.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-21 03:38:07","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7412","static_file","/wp-content/uploads/2023/06/quatam-comp-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:25:01","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7413","static_file","/wp-content/uploads/2023/06/quatam-comp-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:25:01","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7414","static_file","/wp-content/uploads/2023/06/quatam-comp-300x169.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:25:01","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7415","static_file","/wp-content/uploads/2023/06/quatam-comp-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:25:01","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7416","static_file","/wp-content/uploads/2023/06/quatam-comp-600x338.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:25:01","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7417","static_file","/wp-content/uploads/2023/06/quatam-comp-768x432.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:25:01","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7418","static_file","/wp-content/uploads/2023/06/quatam-comp.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:25:01","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7419","static_file","/wp-content/uploads/2023/06/web3-crash-course-avatar-1.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:47","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7420","static_file","/wp-content/uploads/2023/06/web3-crash-course-avatar-2.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:48","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7421","static_file","/wp-content/uploads/2023/06/web3-crash-course-avatar-3.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:49","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7422","static_file","/wp-content/uploads/2023/06/web3-crash-course-avatar-4.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:48","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7423","static_file","/wp-content/uploads/2023/06/web3-crash-course-avatar-5.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:49","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7424","static_file","/wp-content/uploads/2023/06/web3-crash-course-avatar-6.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:50","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7425","static_file","/wp-content/uploads/2023/06/web3-crash-course-hero-image-bg-100x100.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:44","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7426","static_file","/wp-content/uploads/2023/06/web3-crash-course-hero-image-bg-1024x384.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:44","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7427","static_file","/wp-content/uploads/2023/06/web3-crash-course-hero-image-bg-150x150.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:44","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7428","static_file","/wp-content/uploads/2023/06/web3-crash-course-hero-image-bg-1536x576.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:44","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7429","static_file","/wp-content/uploads/2023/06/web3-crash-course-hero-image-bg-300x113.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:44","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7430","static_file","/wp-content/uploads/2023/06/web3-crash-course-hero-image-bg-300x300.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:44","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7431","static_file","/wp-content/uploads/2023/06/web3-crash-course-hero-image-bg-600x225.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:44","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7432","static_file","/wp-content/uploads/2023/06/web3-crash-course-hero-image-bg-768x288.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:44","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7433","static_file","/wp-content/uploads/2023/06/web3-crash-course-hero-image-bg.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:44","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7434","static_file","/wp-content/uploads/2023/06/web3-crash-course-instructor.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:47","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7435","static_file","/wp-content/uploads/2023/06/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-100x100.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:27:28","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7436","static_file","/wp-content/uploads/2023/06/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-150x150.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:27:27","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7437","static_file","/wp-content/uploads/2023/06/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-161x300.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:27:27","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7438","static_file","/wp-content/uploads/2023/06/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-300x300.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:27:27","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7439","static_file","/wp-content/uploads/2023/06/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-548x1024.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:27:27","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7440","static_file","/wp-content/uploads/2023/06/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-600x1120.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:27:28","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7441","static_file","/wp-content/uploads/2023/06/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-768x1434.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:27:27","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7442","static_file","/wp-content/uploads/2023/06/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service-823x1536.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:27:27","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7443","static_file","/wp-content/uploads/2023/06/Alibaba-Launches-11-Qubit-Quantum-Computing-Cloud-Service.jpeg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:27:26","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7444","static_file","/wp-content/uploads/2023/06/icons8-instagram-240.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 06:51:07","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7445","static_file","/wp-content/uploads/2023/06/icons8-instagram-48.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 06:45:42","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7446","static_file","/wp-content/uploads/2023/06/icons8-instagram-96.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 06:46:57","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7447","static_file","/wp-content/uploads/2023/06/web3-crash-course-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-12 04:08:43","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7448","static_file","/wp-content/uploads/astra-sites/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:54:23","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7449","static_file","/wp-content/uploads/cartflows-logs/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:41","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7450","static_file","/wp-content/uploads/rsssl/test.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 06:23:52","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7451","static_file","/wp-content/uploads/wc-logs/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7452","static_file","/wp-content/uploads/woocommerce_uploads/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7453","static_file","/wp-content/uploads/wp-file-manager-pro/fm_backup/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 06:03:20","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7454","static_file","/wp-content/uploads/wp-file-manager-pro/fm_backup/backup_2023_09_04_18_57_04-100-db.sql.gz","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 06:57:19","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7455","static_file","/wp-content/uploads/wp-file-manager-pro/fm_backup/backup_2023_09_04_18_57_04-100-plugins.zip","","","0","1","1","","0000-00-00 00:00:00","","2023-09-04 06:57:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7456","static_file","/wp-content/uploads/wp-staging/logs/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-09 10:38:31","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7457","static_file","/wp-content/uploads/wp-staging/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-09 10:38:31","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7458","static_file","/wp-content/uploads/wpforms/cache/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:45","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7459","static_file","/wp-content/uploads/woocommerce-placeholder-100x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:58","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7460","static_file","/wp-content/uploads/woocommerce-placeholder-1024x1024.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:18","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7461","static_file","/wp-content/uploads/woocommerce-placeholder-150x150.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:18","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7462","static_file","/wp-content/uploads/woocommerce-placeholder-300x300.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:58","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7463","static_file","/wp-content/uploads/woocommerce-placeholder-600x600.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-29 02:32:58","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7464","static_file","/wp-content/uploads/woocommerce-placeholder-768x768.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:30:19","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7465","static_file","/wp-content/uploads/woocommerce-placeholder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:18:34","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7466","seo_files","/robots.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:54:29","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7467","seo_files","/sitemap.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:54:29","0000-00-00 00:00:00","2023-09-07 12:54:43");/*END*/