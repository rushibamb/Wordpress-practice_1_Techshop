

DROP TABLE IF EXISTS `webtoffee_cartflows_ca_email_templates_meta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_cartflows_ca_email_templates_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email_template_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email_template_id` (`email_template_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("1","1","override_global_coupon","");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("2","1","discount_type","percent");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("3","1","coupon_amount","10");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("4","1","coupon_expiry_date","");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("5","1","coupon_expiry_unit","hours");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("6","1","use_woo_email_style","");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("7","2","override_global_coupon","");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("8","2","discount_type","percent");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("9","2","coupon_amount","10");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("10","2","coupon_expiry_date","");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("11","2","coupon_expiry_unit","hours");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("12","2","use_woo_email_style","");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("13","3","override_global_coupon","");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("14","3","discount_type","percent");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("15","3","coupon_amount","10");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("16","3","coupon_expiry_date","");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("17","3","coupon_expiry_unit","hours");/*END*/
INSERT INTO `webtoffee_cartflows_ca_email_templates_meta` VALUES
("18","3","use_woo_email_style","");/*END*/