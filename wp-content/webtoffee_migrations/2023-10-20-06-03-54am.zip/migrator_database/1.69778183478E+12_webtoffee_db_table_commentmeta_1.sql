

DROP TABLE IF EXISTS `webtoffee_commentmeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO `webtoffee_commentmeta` VALUES
("1","8","rating","5");/*END*/
INSERT INTO `webtoffee_commentmeta` VALUES
("2","8","verified","0");/*END*/
INSERT INTO `webtoffee_commentmeta` VALUES
("3","52","rating","5");/*END*/
INSERT INTO `webtoffee_commentmeta` VALUES
("4","52","verified","0");/*END*/
INSERT INTO `webtoffee_commentmeta` VALUES
("5","53","rating","5");/*END*/
INSERT INTO `webtoffee_commentmeta` VALUES
("6","53","verified","0");/*END*/