

DROP TABLE IF EXISTS `webtoffee_wc_admin_note_actions` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonce_action` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `nonce_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21285 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("1","1","connect","Connect","?page=wc-addons&section=helper","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("658","54","woopay-beta-existingmerchants-noaction-documentation-27APR23-test2","Documentation","https://woocommerce.com/document/woopay-merchant-documentation/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-existingmerchants-noaction-documentation-27APR23-test2","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("659","54","woopay-beta-existingmerchants-noaction-documentation-27APR23-dismiss-test2","Dismiss","http://aryanshop.me/wp-admin/#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("660","55","woopay-beta-existingmerchants-update-WCPay-27APR23-test","Update WooCommerce Payments","http://aryanshop.me/wp-admin/plugins.php?plugin_status=all","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("661","55","woopay-beta-existingmerchants-update-WCPay-27APR23-dismiss-test","Dismiss","http://aryanshop.me/wp-admin/#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("662","56","visit-the-theme-marketplace","Visit the theme marketplace","https://woocommerce.com/product-category/themes/?utm_source=inbox&utm_medium=product","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("663","57","day-after-first-product","Learn more","https://woocommerce.com/document/woocommerce-customizer/?utm_source=inbox&utm_medium=product","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("1160","58","learn-more","Learn more","https://woocommerce.com/mobile/?utm_medium=product","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("4937","84","browse","Browse","https://woocommerce.com/success-stories/?utm_source=inbox&utm_medium=product","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("1596","60","view-payment-gateways","Learn more","https://woocommerce.com/product-category/woocommerce-extensions/payment-gateways/?utm_medium=product","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("1721","61","tracking-opt-in","Activate usage tracking","","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21280","108","wc_com_in_person_payments_card_sale_US_inbox_note_q4_23","Save 35%","https://woocommerce.com/products/m2-card-reader/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_com_in_person_payments_card_sale_US_inbox_note_q4_23","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("2469","36","wc-admin-BNPL-WCPay-coming-soon","Sign up now","https://woocommerce.com/buy-now-pay-later-for-woocommerce-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-BNPL-WCPay-coming-soon","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("2588","73","payoneer_q2_2023","Get started with Payoneer","https://woocommerce.com/products/payoneer-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=payoneer_q2_2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("2759","77","remove-legacy-coupon-menu","Remove legacy coupon menu","http://aryanshop.me/wp-admin/admin.php?page=wc-admin&action=remove-coupon-menu","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("2799","33","google_listings_ads_pmax_i1_q1_2023_no_gla","Boost my business with Google","https://woocommerce.com/products/google-listings-and-ads/?utm_source=inbox_note&utm_medium=product&utm_campaign=google_listings_ads_pmax_i1_q1_2023_no_gla","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("2800","34","google_listings_ads_pmax_i1_q1_2023_with_gla","Create a new ad","https://woocommerce.com/products/google-listings-and-ads/?utm_source=inbox_note&utm_medium=product&utm_campaign=google_listings_ads_pmax_i1_q1_2023_with_gla","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("2926","78","learn-more","Learn more","https://woocommerce.com/posts/pre-launch-checklist-the-essentials/?utm_source=inbox&utm_medium=product","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3056","40","wc-admin-wcpay-denmark-Q2-2023","Simplify my payments","https://woocommerce.com/payments/denmark/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-denmark-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3057","41","wc-admin-wcpay-greece-Q2-2023","Simplify my payments","https://woocommerce.com/payments/greece/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-greece-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3058","42","wc-admin-wcpay-norway-Q2-2023","Simplify my payments","https://woocommerce.com/payments/norway/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-norway-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3059","43","wc-admin-wcpay-slovakia-Q2-2023","Simplify my payments","https://woocommerce.com/payments/slovakia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-slovakia-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3060","44","wc-admin-wcpay-finland-Q2-2023","Simplify my payments","https://woocommerce.com/payments/finland/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-finland-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3061","45","wc-admin-wcpay-estonia-Q2-2023","Simplify my payments","https://woocommerce.com/payments/estonia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-estonia-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3062","46","wc-admin-wcpay-lithuania-Q2-2023","Simplify my payments","https://woocommerce.com/payments/lithuania/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-lithuania-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3063","47","wc-admin-wcpay-slovenia-Q2-2023","Simplify my payments","https://woocommerce.com/payments/slovenia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-slovenia-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3064","48","wc-admin-wcpay-latvia-Q2-2023","Simplify my payments","https://woocommerce.com/payments/latvia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-latvia-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3065","49","wc-admin-wcpay-cyprus-Q2-2023","Simplify my payments","https://woocommerce.com/payments/cyprus/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-cyprus-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3066","50","wc-admin-wcpay-malta-Q2-2023","Simplify my payments","https://woocommerce.com/payments/malta/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-malta-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3067","51","wc-admin-wcpay-luxembourg-Q2-2023","Simplify my payments","https://woocommerce.com/payments/luxembourg/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-luxembourg-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("3090","76","product_management_card_sorting","Get started","https://t.maze.co/163892579","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21192","3","wayflyer_bnpl_q4_2021","Level up with funding","https://woocommerce.com/products/wayflyer/?utm_source=inbox_note&utm_medium=product&utm_campaign=wayflyer_bnpl_q4_2021","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21193","4","wc_shipping_mobile_app_usps_q4_2021","Get WooCommerce Shipping","https://woocommerce.com/woocommerce-shipping/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_usps_q4_2021","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21194","5","learn-more","Learn more","https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21195","6","learn-more","Learn more","https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21196","7","optimizing-the-checkout-flow","Learn more","https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=optimizing-the-checkout-flow","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21197","8","qualitative-feedback-from-new-users","Share feedback","https://automattic.survey.fm/wc-pay-new","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21198","9","share-feedback","Share feedback","http://automattic.survey.fm/paypal-feedback","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21199","10","get-started","Get started","https://woocommerce.com/products/google-listings-and-ads?utm_source=inbox_note&utm_medium=product&utm_campaign=get-started","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21200","11","update-wc-subscriptions-3-0-15","View latest version","https://aryanshop.me/wp-admin/&page=wc-addons&section=helper","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21201","12","update-wc-core-5-4-0","How to update WooCommerce","https://docs.woocommerce.com/document/how-to-update-woocommerce/","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21202","15","ppxo-pps-install-paypal-payments-1","View upgrade guide","https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21203","16","ppxo-pps-install-paypal-payments-2","View upgrade guide","https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21204","17","learn-more","Learn more","https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21205","17","dismiss","Dismiss","","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21206","18","learn-more","Learn more","https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21207","18","dismiss","Dismiss","","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21208","19","learn-more","Learn more","https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21209","19","dismiss","Dismiss","","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21210","20","learn-more","Learn more","https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21211","20","dismiss","Dismiss","","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21212","21","share-feedback","Share feedback","https://automattic.survey.fm/store-management","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21214","22","woocommerce-core-paypal-march-2022-dismiss","Dismiss","","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21213","22","learn-more","Learn more","https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21215","23","learn-more","Learn more","https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21216","23","dismiss","Dismiss","","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21217","24","pinterest_03_2022_update","Update Instructions","https://woocommerce.com/document/pinterest-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=pinterest_03_2022_update#section-3","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21218","25","store_setup_survey_survey_q2_2022_share_your_thoughts","Tell us how it’s going","https://automattic.survey.fm/store-setup-survey-2022","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("9451","26","wc-admin-wisepad3","Grow my business offline","https://woocommerce.com/products/wisepad3-card-reader/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wisepad3","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21219","27","learn-more","Find out more","https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21220","27","dismiss","Dismiss","","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21221","28","learn-more","Find out more","https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21222","28","dismiss","Dismiss","","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("9634","29","google_listings_ads_custom_attribute_mapping_q4_2022","Learn more","https://woocommerce.com/document/google-listings-and-ads/?utm_source=inbox_note&utm_medium=product&utm_campaign=google_listings_ads_custom_attribute_mapping_q4_2022#attribute-mapping","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21224","30","needs-update-eway-payment-gateway-rin-dismiss-button-2022-12-20","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21226","31","updated-eway-payment-gateway-rin-dismiss-button-2022-12-20","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21225","31","updated-eway-payment-gateway-rin-action-button-2022-12-20","See all updates","https://aryanshop.me/wp-admin/update-core.php","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21227","32","share-navigation-survey-feedback","Share feedback","https://automattic.survey.fm/new-ecommerce-plan-navigation","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21228","62","woopay-beta-merchantrecruitment-activate-04MAY23","Activate WooPay","https://aryanshop.me/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21231","35","woocommerce-wcpay-march-2023-update-needed-dismiss-button","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21230","35","woocommerce-wcpay-march-2023-update-needed-button","See Blog Post","https://developer.woocommerce.com/2023/03/23/critical-vulnerability-detected-in-woocommerce-payments-what-you-need-to-know","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21232","37","tap_to_pay_iphone_q2_2023_no_wcpay","Simplify my payments","https://woocommerce.com/products/woocommerce-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=tap_to_pay_iphone_q2_2023_no_wcpay","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("10632","38","tap_to_pay_iphone_q2_2023_with_wcpay","Set up Tap to Pay on iPhone","https://woocommerce.com/document/woocommerce-payments/in-person-payments/woocommerce-in-person-payments-tap-to-pay-on-iphone-quick-start-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=tap_to_pay_iphone_q2_2023_with_wcpay","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21233","39","extension-settings","See available updates","https://aryanshop.me/wp-admin/update-core.php","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21234","39","dismiss","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("6187","85","om-note-seconday","Learn more","admin.php?page=optin-monster-about&selectedTab=getting-started","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21237","52","woopay-beta-existingmerchants-noaction-documentation-27APR23","Documentation","https://woocommerce.com/document/woopay-merchant-documentation/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-existingmerchants-noaction-documentation-27APR23","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21238","53","woopay-beta-existingmerchants-update-WCPay-27APR23","Update WooCommerce Payments","https://aryanshop.me/wp-admin/plugins.php?plugin_status=all","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21240","64","woopay-beta-merchantrecruitment-short-activate-learnmore-04MAY23","Learn More","https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-04MAY23","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21241","65","woopay-beta-merchantrecruitment-short-update-WCPay-04MAY23","Update WooCommerce Payments","https://aryanshop.me/wp-admin/plugins.php?plugin_status=all","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21242","65","woopay-beta-merchantrecruitment-short-update-activate-04MAY23","Activate WooPay","https://aryanshop.me/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21256","79","woocommerce-WCStripe-May-2023-updated-needed-Plugin-Settings-dismiss","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21243","66","woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTA","Activate WooPay Test A","https://aryanshop.me/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21245","67","woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTB","Activate WooPay Test B","https://aryanshop.me/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21247","68","woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTC","Activate WooPay Test C","https://aryanshop.me/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21249","69","woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTD","Activate WooPay Test D","https://aryanshop.me/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21251","70","woopay-beta-merchantrecruitment-short-activate-button-09MAY23","Activate WooPay","https://aryanshop.me/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21252","70","woopay-beta-merchantrecruitment-short-activate-learnmore-button2-09MAY23","Learn More","https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-button2-09MAY23","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("6186","85","om-note-primary","Create a campaign","admin.php?page=optin-monster-templates","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21253","71","woopay-beta-merchantrecruitment-short-update-WCPay-09MAY23","Update WooCommerce Payments","https://aryanshop.me/wp-admin/plugins.php?plugin_status=all","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("11539","74","ipp_refresh_q2_2023_us_inbox_notification","Grow my business on the go","https://woocommerce.com/in-person-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=ipp_refresh_q2_2023_us_inbox_notification","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("11540","75","ipp_refresh_q2_2023_ca_inbox_notification","Grow my business on the go","https://woocommerce.com/in-person-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=ipp_refresh_q2_2023_ca_inbox_notification","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21255","79","woocommerce-WCStripe-May-2023-updated-needed-Plugin-Settings","See available updates","https://aryanshop.me/wp-admin/plugins.php?plugin_status=all","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21258","81","woocommerce-WCPayments-June-2023-updated-needed-Dismiss","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21257","81","woocommerce-WCPayments-June-2023-updated-needed-Plugin-Settings","See available updates","https://aryanshop.me/wp-admin/plugins.php?plugin_status=all","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21260","82","woocommerce-WCSubscriptions-June-2023-updated-needed-dismiss","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21262","80","woocommerce-WCReturnsWarranty-June-2023-updated-needed","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21261","80","woocommerce-WCReturnsWarranty-June-2023-updated-needed","See available updates","https://aryanshop.me/wp-admin/plugins.php?plugin_status=all","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("10123","83","woocommerce_hpos_1st_notification_q2_2023","Learn more about HPOS","https://woocommerce.com/posts/platform-update-high-performance-order-storage-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=woocommerce_hpos_1st_notification_q2_2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("10670","88","wc-admin-wcpay-czechia-Q2-2023","Simplify my payments","https://woocommerce.com/payments/czechia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-czechia-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21223","30","needs-update-eway-payment-gateway-rin-action-button-2022-12-20","See available updates","https://aryanshop.me/wp-admin/update-core.php","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21229","62","woopay-beta-merchantrecruitment-activate-learnmore-04MAY23","Learn More","https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-activate-learnmore-04MAY23","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21259","82","woocommerce-WCSubscriptions-June-2023-updated-needed-Plugin-Settings","See available updates","https://aryanshop.me/wp-admin/plugins.php?plugin_status=all","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("9246","2","browse_extensions","Browse extensions","https://aryanshop.me/wp-admin/admin.php?page=wc-addons","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21244","66","woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA","Learn More","https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21246","67","woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA","Learn More","https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21248","68","woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTC","Learn More","https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTC","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21250","69","woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTD","Learn More","https://woocommerce.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTD","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21254","71","woopay-beta-merchantrecruitment-short-update-activate-09MAY23","Activate WooPay","https://aryanshop.me/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21239","64","woopay-beta-merchantrecruitment-short-activate-04MAY23","Activate WooPay","https://aryanshop.me/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21235","63","woopay-beta-merchantrecruitment-update-WCPay-04MAY23","Update WooCommerce Payments","https://aryanshop.me/wp-admin/plugins.php?plugin_status=all","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21236","63","woopay-beta-merchantrecruitment-update-activate-04MAY23","Activate WooPay","https://aryanshop.me/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21264","86","woocommerce-WCOPC-June-2023-updated-needed","Dismiss","https://aryanshop.me/wp-admin/#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("10669","87","wc-admin-wcpay-bulgaria-Q2-2023","Simplify my payments","https://woocommerce.com/payments/bulgaria/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-bulgaria-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21263","86","woocommerce-WCOPC-June-2023-updated-needed","See available updates","https://aryanshop.me/wp-admin/plugins.php?plugin_status=all","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("10671","89","wc-admin-wcpay-croatia-Q2-2023","Simplify my payments","https://woocommerce.com/payments/croatia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-croatia-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("10672","90","wc-admin-wcpay-hungary-Q2-2023","Simplify my payments","https://woocommerce.com/payments/hungary/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-hungary-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("10673","91","wc-admin-wcpay-romania-Q2-2023","Simplify my payments","https://woocommerce.com/payments/romania/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-romania-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("10674","92","wc-admin-wcpay-sweden-Q2-2023","Simplify my payments","https://woocommerce.com/payments/sweden/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-sweden-Q2-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("9157","93","tiktok-spc_june-2023","Optimize my advertising","https://woocommerce.com/products/tiktok-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=tiktok-spc_june-2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21266","94","woocommerce-WCGC-July-2023-update-needed","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21265","94","woocommerce-WCGC-July-2023-update-needed","See available updates","https://aryanshop.me/wp-admin/plugins.php?plugin_status=all","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21267","95","learn-more","Learn more","https://woocommerce.com/document/fedex/?utm_medium=product&utm_source=inbox_note&utm_campaign=learn-more#july-2023-api-outage","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21269","96","dismiss","Dismiss","https://aryanshop.me/wp-admin/admin.php?page=wc-admin","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21268","96","plugin-list","See available updates","https://aryanshop.me/wp-admin/plugins.php?plugin_status=all","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("10223","97","square_button_q3_2023","Get started with Square","https://woocommerce.com/products/square/?utm_source=inbox_note&utm_medium=product&utm_campaign=square_button_q3_2023","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21271","100","dismiss","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21270","100","woocommerce-WCStripe-Aug-2023-update-needed","See available updates","https://aryanshop.me/wp-admin/update-core.php?","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("10048","98","learn-more","Learn more","https://woocommerce.com/mobile/?utm_source=inbox&utm_medium=product","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("10402","99","wc-admin-woopayments-rebrand","Learn more about WooPayments","https://woocommerce.com/payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-woopayments-rebrand","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21272","101","dismiss","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21273","102","woocommerce-WooPayments-Aug-2023-update-needed","See available updates","https://aryanshop.me/wp-admin/update-core.php?","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21274","102","dismiss","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21275","103","dismiss","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("10590","104","tiktok-apac-webinar-2023","RSVP today","https://unlockingtiktokwithwoocommerce.splashthat.com/","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21276","105","avalara_q3-2023_noAvaTax","Automate my sales tax","https://woocommerce.com/products/woocommerce-avatax/?utm_source=inbox_note&utm_medium=product&utm_campaign=avalara_q3-2023_noAvaTax","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21277","106","woo-activation-survey-blockers-survey-button-22AUG23","Take our short survey","https://woocommerce.survey.fm/getting-started-with-woo","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("18687","72","update-db_done","Thanks!","https://aryanshop.me/wp-admin/plugins.php?activate=true&plugin_status=all&paged=1&s&wc-hide-notice=update","actioned","woocommerce_hide_notices_nonce","woocommerce_hide_notices_nonce","_wc_notice_nonce");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21279","107","dismiss","Dismiss","https://aryanshop.me/wp-admin/#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21278","107","woocommerce-usermeta-Sept2023-productvendors","See available updates","https://aryanshop.me/wp-admin/plugins.php","unactioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21284","111","dismiss","Dismiss","#","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21281","109","wc_com_in_person_payments_card_sale_UK_inbox_note_q4_23","Save 35%","https://woocommerce.com/products/wisepad3-card-reader/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_com_in_person_payments_card_sale_UK_inbox_note_q4_23","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21282","110","wc_com_in_person_payments_card_sale_CA_inbox_note_q4_23","Save 35%","https://woocommerce.com/products/wisepad3-card-reader/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_com_in_person_payments_card_sale_CA_inbox_note_q4_23","actioned","","","");/*END*/
INSERT INTO `webtoffee_wc_admin_note_actions` VALUES
("21283","111","woocommerce-STRIPE-Oct-2023-update-needed","See available updates","https://aryanshop.me/wp-admin/update-core.php","unactioned","","","");/*END*/