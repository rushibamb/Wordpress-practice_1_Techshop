

DROP TABLE IF EXISTS `webtoffee_wc_product_download_directories` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wc_product_download_directories` (
  `url_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`url_id`),
  KEY `url` (`url`(191))
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wc_product_download_directories` VALUES
("1","file:///home/vol17_1/unaux.com/unaux_34393270/htdocs/wp-content/uploads/woocommerce_uploads/","1");/*END*/
INSERT INTO `webtoffee_wc_product_download_directories` VALUES
("2","http://aryanshop.me/wp-content/uploads/woocommerce_uploads/","1");/*END*/
INSERT INTO `webtoffee_wc_product_download_directories` VALUES
("3","https://github.com/AryanVBW/","1");/*END*/