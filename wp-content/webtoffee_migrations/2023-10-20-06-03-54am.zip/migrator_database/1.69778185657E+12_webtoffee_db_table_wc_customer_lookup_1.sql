

DROP TABLE IF EXISTS `webtoffee_wc_customer_lookup` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wc_customer_lookup` VALUES
("18","","","Sanket","Thorat","tsanket463@gmail.com","2023-08-01 08:09:56","","","","","");/*END*/
INSERT INTO `webtoffee_wc_customer_lookup` VALUES
("13","","","Gautam","Gupta","gautamgupta211204@gmail.com","2023-06-22 09:56:09","","","","","");/*END*/
INSERT INTO `webtoffee_wc_customer_lookup` VALUES
("14","","","Aditya","Dhome","adityadhome156@gmail.com","2023-06-25 16:57:36","","","","","");/*END*/
INSERT INTO `webtoffee_wc_customer_lookup` VALUES
("15","","","Vaibhav","Dere","kailasdere225@gmail.com","2023-06-24 14:43:53","","","","","");/*END*/
INSERT INTO `webtoffee_wc_customer_lookup` VALUES
("16","","","Kiran","Dhome","kirandhome1985+vivek@gmail.com","2023-06-28 03:42:42","","","","","");/*END*/
INSERT INTO `webtoffee_wc_customer_lookup` VALUES
("17","","","Aryan","w","dipakthorat7262@gmail.com","2023-06-30 05:57:27","","","","","");/*END*/
INSERT INTO `webtoffee_wc_customer_lookup` VALUES
("11","","","vivek","wagadare","vivekwagadare@gmail.com","2023-06-28 03:10:58","","","","","");/*END*/
INSERT INTO `webtoffee_wc_customer_lookup` VALUES
("12","","","Mf","Sob","uj413882@gmail.com","2023-06-22 09:39:14","","","","","");/*END*/
INSERT INTO `webtoffee_wc_customer_lookup` VALUES
("10","1","vivek","sw","dsdad","vivekwagadare+mysite@gmail.com","2023-06-22 16:06:37","2023-04-28 07:02:26","","","","");/*END*/
INSERT INTO `webtoffee_wc_customer_lookup` VALUES
("19","","","Gsjjsja","Hajaha","gaikwadvedant971@gmail.com","2023-08-05 08:43:52","","","","","");/*END*/
INSERT INTO `webtoffee_wc_customer_lookup` VALUES
("20","","","Yhx","Dvbdbd","hsbshshsg@gmail.com","2023-08-26 10:39:46","","","","","");/*END*/
INSERT INTO `webtoffee_wc_customer_lookup` VALUES
("21","","","Ashish","Kumar","ram4458bhakt@gmail.com","2023-08-15 11:51:26","","","","","");/*END*/