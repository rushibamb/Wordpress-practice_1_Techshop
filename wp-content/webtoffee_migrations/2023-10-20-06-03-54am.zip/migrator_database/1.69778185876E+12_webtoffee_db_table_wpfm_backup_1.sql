

DROP TABLE IF EXISTS `webtoffee_wpfm_backup` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wpfm_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_name` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `backup_date` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wpfm_backup` VALUES
("1","backup_2023_09_04_18_57_04-100","2023-09-04 18:57:04");/*END*/
INSERT INTO `webtoffee_wpfm_backup` VALUES
("2","backup_2023_09_09_21_03_20-9108","2023-09-09 21:03:20");/*END*/
INSERT INTO `webtoffee_wpfm_backup` VALUES
("3","backup_2023_10_03_20_01_12-3225","2023-10-03 20:01:12");/*END*/