
INSERT INTO `webtoffee_urls` VALUES
("2001","static_file","/wp-content/plugins/cartflows/assets/fonts/cartflows-icon.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2002","static_file","/wp-content/plugins/cartflows/assets/fonts/cartflows-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2003","static_file","/wp-content/plugins/cartflows/assets/images/cartflows-email-logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2004","static_file","/wp-content/plugins/cartflows/assets/images/facebook2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2005","static_file","/wp-content/plugins/cartflows/assets/images/lock.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2006","static_file","/wp-content/plugins/cartflows/assets/images/twitter2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2007","static_file","/wp-content/plugins/cartflows/assets/images/youtube2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2008","static_file","/wp-content/plugins/cartflows/assets/images/400x400.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2009","static_file","/wp-content/plugins/cartflows/assets/images/cartflows-logo-small.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2010","static_file","/wp-content/plugins/cartflows/assets/images/start-scratch.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2011","static_file","/wp-content/plugins/cartflows/assets/images/cartflows-check-circle-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2012","static_file","/wp-content/plugins/cartflows/assets/images/cartflows-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2013","static_file","/wp-content/plugins/cartflows/assets/images/cartflows-logo-.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2014","static_file","/wp-content/plugins/cartflows/assets/images/cartflows-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2015","static_file","/wp-content/plugins/cartflows/assets/images/cartflows-payment-section-loader.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2016","static_file","/wp-content/plugins/cartflows/assets/images/cartflows-small.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2017","static_file","/wp-content/plugins/cartflows/assets/images/cf-emblem.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2018","static_file","/wp-content/plugins/cartflows/assets/images/order-review-skeleton.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2019","static_file","/wp-content/plugins/cartflows/assets/js/lib/jquery-cookie/jquery.cookie.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2020","static_file","/wp-content/plugins/cartflows/assets/js/lib/jquery-cookie/jquery.cookie.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2021","static_file","/wp-content/plugins/cartflows/assets/js/checkout-template.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2022","static_file","/wp-content/plugins/cartflows/assets/js/frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2023","static_file","/wp-content/plugins/cartflows/assets/js/google-auto-fields.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2024","static_file","/wp-content/plugins/cartflows/assets/js/optin-template.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2025","static_file","/wp-content/plugins/cartflows/assets/js/rest-api.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2026","static_file","/wp-content/plugins/cartflows/assets/min-css/cartflows-normalize-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2027","static_file","/wp-content/plugins/cartflows/assets/min-css/cartflows-normalize.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2028","static_file","/wp-content/plugins/cartflows/assets/min-css/checkout-template-divi-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2029","static_file","/wp-content/plugins/cartflows/assets/min-css/checkout-template-divi.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2030","static_file","/wp-content/plugins/cartflows/assets/min-css/checkout-template-flatsome-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2031","static_file","/wp-content/plugins/cartflows/assets/min-css/checkout-template-flatsome.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:06","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2032","static_file","/wp-content/plugins/cartflows/assets/min-css/checkout-template-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2033","static_file","/wp-content/plugins/cartflows/assets/min-css/checkout-template-the-seven-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2034","static_file","/wp-content/plugins/cartflows/assets/min-css/checkout-template-the-seven.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2035","static_file","/wp-content/plugins/cartflows/assets/min-css/checkout-template.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2036","static_file","/wp-content/plugins/cartflows/assets/min-css/frontend-divi-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2037","static_file","/wp-content/plugins/cartflows/assets/min-css/frontend-divi.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2038","static_file","/wp-content/plugins/cartflows/assets/min-css/frontend-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2039","static_file","/wp-content/plugins/cartflows/assets/min-css/frontend.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2040","static_file","/wp-content/plugins/cartflows/assets/min-css/import-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2041","static_file","/wp-content/plugins/cartflows/assets/min-css/import.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2042","static_file","/wp-content/plugins/cartflows/assets/min-css/optin-template-divi-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2043","static_file","/wp-content/plugins/cartflows/assets/min-css/optin-template-divi.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2044","static_file","/wp-content/plugins/cartflows/assets/min-css/optin-template-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2045","static_file","/wp-content/plugins/cartflows/assets/min-css/optin-template.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2046","static_file","/wp-content/plugins/cartflows/assets/min-js/checkout-template.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2047","static_file","/wp-content/plugins/cartflows/assets/min-js/frontend.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2048","static_file","/wp-content/plugins/cartflows/assets/min-js/google-auto-fields.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2049","static_file","/wp-content/plugins/cartflows/assets/min-js/import.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2050","static_file","/wp-content/plugins/cartflows/assets/min-js/optin-template.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2051","static_file","/wp-content/plugins/cartflows/assets/min-js/rest-api.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2052","static_file","/wp-content/plugins/cartflows/compatibilities/themes/astra/css/astra-compatibility.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:08","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2053","static_file","/wp-content/plugins/cartflows/libraries/action-scheduler/changelog.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:30:08","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2054","static_file","/wp-content/plugins/cartflows/libraries/action-scheduler/license.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:30:08","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2055","static_file","/wp-content/plugins/cartflows/libraries/action-scheduler/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:30:08","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2056","static_file","/wp-content/plugins/cartflows/libraries/astra-notices/notices.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:08","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2057","static_file","/wp-content/plugins/cartflows/libraries/astra-notices/notices.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:08","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2058","static_file","/wp-content/plugins/cartflows/libraries/cartflows-plugin-update-notifications/update-notifications.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:08","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2059","static_file","/wp-content/plugins/cartflows/modules/beaver-builder/cartflows-bb-checkout-form/icon/bb-checkout-form.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:08","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2060","static_file","/wp-content/plugins/cartflows/modules/beaver-builder/cartflows-bb-checkout-form/js/settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:08","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2061","static_file","/wp-content/plugins/cartflows/modules/beaver-builder/cartflows-bb-next-step/css/frontend.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:09","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2062","static_file","/wp-content/plugins/cartflows/modules/beaver-builder/cartflows-bb-next-step/icon/bb-next-step.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:09","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2063","static_file","/wp-content/plugins/cartflows/modules/beaver-builder/cartflows-bb-next-step/js/settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:09","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2064","static_file","/wp-content/plugins/cartflows/modules/beaver-builder/cartflows-bb-optin-form/icon/bb-optin-form.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:09","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2065","static_file","/wp-content/plugins/cartflows/modules/beaver-builder/cartflows-bb-order-details/css/frontend.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:09","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2066","static_file","/wp-content/plugins/cartflows/modules/beaver-builder/cartflows-bb-order-details/icon/bb-order-details.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:09","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2067","static_file","/wp-content/plugins/cartflows/modules/beaver-builder/cartflows-bb-order-details/js/settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:09","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2068","static_file","/wp-content/plugins/cartflows/modules/elementor/widgets-css/frontend.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:09","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2069","static_file","/wp-content/plugins/cartflows/modules/gutenberg/assets/css/blocks/checkout-form.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:09","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2070","static_file","/wp-content/plugins/cartflows/modules/gutenberg/assets/css/blocks/next-step-button.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:09","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2071","static_file","/wp-content/plugins/cartflows/modules/gutenberg/assets/css/blocks/optin-form.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:09","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2072","static_file","/wp-content/plugins/cartflows/modules/gutenberg/assets/css/blocks/order-detail-form.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:09","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2073","static_file","/wp-content/plugins/cartflows/modules/gutenberg/build/blocks.style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:10","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2074","static_file","/wp-content/plugins/cartflows/modules/gutenberg/build/style-blocks.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:10","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2075","static_file","/wp-content/plugins/cartflows/modules/gutenberg/build/blocks-placeholder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:10","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2076","static_file","/wp-content/plugins/cartflows/modules/gutenberg/build/blocks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:10","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2077","static_file","/wp-content/plugins/cartflows/modules/gutenberg/dist/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2078","static_file","/wp-content/plugins/cartflows/modules/gutenberg/dist/blocks.build.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2079","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/blocks-attributes/getBlocksDefaultAttributes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2080","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/advanced-panel-body/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2081","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/background/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2082","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/box-shadow/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2083","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/color-control/advanced-pop-color-control.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2084","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/color-control/hex-to-rgba.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2085","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/color-control/uagb-color-icons.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2086","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/color-switch-control/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2087","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/gradient-settings/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2088","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/gutter-options/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2089","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/icon-picker/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2090","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/image-size-control/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2091","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/image-size-control/use-dimension-handler.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2092","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/image/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2093","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/inspector-tabs/InspectorTab.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2094","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/inspector-tabs/InspectorTabs.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2095","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/multi-buttons-control/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2096","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/number-control/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2097","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/presets/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2098","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/range/Range.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2099","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/reset/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2100","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/responsive-border/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2101","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/responsive-focal-point-picker/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2102","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/responsive-icons/device-icons.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2103","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/responsive-icons/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2104","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/responsive-image/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2105","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/responsive-select/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2106","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/responsive-slider/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2107","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/responsive-toggle/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2108","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/select-control/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2109","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/separator/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2110","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/spacing-control/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2111","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/tabs/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2112","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/text-shadow/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2113","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/typography/font-typography.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2114","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/typography/fontloader.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2115","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/typography/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2116","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/typography/inline-styles.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2117","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/components/typography/range-typography.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2118","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/addBlockEditorDynamicStyles.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2119","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/addBlockEditorResponsiveStyles.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2120","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/autoBlockRecovery.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2121","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/block-icons.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2122","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/deprecatedRenderIcon.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2123","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/fonts.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2124","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/generateAttributes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2125","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/generateBackgroundCSS.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2126","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/generateBorderCSS.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2127","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/generateCSS.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2128","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/generateCSSUnit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2129","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/getAttributeFallback.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2130","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/getPreviewType.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2131","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/getUAGEditorStateLocalStorage.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2132","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/hexToRgba.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2133","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/isInvalid.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2134","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/maybeGetColorForVariable.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2135","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/parseIcon.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2136","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/renderCustomIcon.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:13","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2137","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/renderIcon.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:13","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2138","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/scrollBlockToView.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:13","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2139","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/controls/unitWiseMinMaxOption.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2140","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/utils/Helpers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2141","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/utils/getBlocksDefaultAttributes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2142","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/block-icons.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2143","static_file","/wp-content/plugins/cartflows/modules/gutenberg/src/blocks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2144","static_file","/wp-content/plugins/cartflows/modules/gutenberg/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2145","static_file","/wp-content/plugins/cartflows/modules/gutenberg/gutenberg-webpack.config.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:12","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2146","static_file","/wp-content/plugins/cartflows/wizard/assets/build/images/block-editor.e2b7f39c.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2147","static_file","/wp-content/plugins/cartflows/wizard/assets/build/wizard-app.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2148","static_file","/wp-content/plugins/cartflows/wizard/assets/build/wizard-app.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2149","static_file","/wp-content/plugins/cartflows/wizard/assets/images/block-editor.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2150","static_file","/wp-content/plugins/cartflows/wizard/assets/images/divi.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2151","static_file","/wp-content/plugins/cartflows/wizard/assets/images/beaver-builder.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2152","static_file","/wp-content/plugins/cartflows/wizard/assets/images/cartflows-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2153","static_file","/wp-content/plugins/cartflows/wizard/assets/images/cartflows-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2154","static_file","/wp-content/plugins/cartflows/wizard/assets/images/check-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2155","static_file","/wp-content/plugins/cartflows/wizard/assets/images/elementor.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2156","static_file","/wp-content/plugins/cartflows/wizard/assets/images/other.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2157","static_file","/wp-content/plugins/cartflows/wizard/assets/images/others.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2158","static_file","/wp-content/plugins/cartflows/wizard/assets/js/helper.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2159","static_file","/wp-content/plugins/cartflows/wizard/assets/src/fields/ColorPickerField.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2160","static_file","/wp-content/plugins/cartflows/wizard/assets/src/fields/FooterNavigationBar.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2161","static_file","/wp-content/plugins/cartflows/wizard/assets/src/fields/NavigationBar.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2162","static_file","/wp-content/plugins/cartflows/wizard/assets/src/fields/TextField.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2163","static_file","/wp-content/plugins/cartflows/wizard/assets/src/fields/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2164","static_file","/wp-content/plugins/cartflows/wizard/assets/src/utils/SettingsProvider/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2165","static_file","/wp-content/plugins/cartflows/wizard/assets/src/utils/SettingsProvider/initialData.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2166","static_file","/wp-content/plugins/cartflows/wizard/assets/src/utils/Helpers.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2167","static_file","/wp-content/plugins/cartflows/wizard/assets/src/utils/StateProvider.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2168","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/components/GlobalFlowHeader.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2169","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/components/GlobalFlowItem.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2170","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/components/NoFlowsFound.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2171","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/components/UploadSiteLogo.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2172","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/skeletons/GlobalFlowLibrarySkeleton.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2173","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/skeletons/TemplateLoadingSkeleton.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:20","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2174","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/GlobalCheckout.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2175","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/OptinStep.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2176","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/PageBuilderStep.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2177","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/PluginsInstallStep.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2178","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/ReadyStep.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2179","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/WelcomeStep.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:20","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2180","static_file","/wp-content/plugins/cartflows/wizard/assets/src/wizard-steps/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2181","static_file","/wp-content/plugins/cartflows/wizard/assets/src/WizardApp.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2182","static_file","/wp-content/plugins/cartflows/wizard/assets/src/WizardMain.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2183","static_file","/wp-content/plugins/cartflows/wizard/assets/src/WizardRoute.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2184","static_file","/wp-content/plugins/cartflows/changelog.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:30:07","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2185","static_file","/wp-content/plugins/cartflows/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-15 05:30:19","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2186","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/admin/assets/css/admin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2187","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/admin/assets/images/stripe-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2188","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/admin/assets/images/stripe-s-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2189","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/admin/assets/js/admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2190","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/admin/assets/js/express-checkout.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2191","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/admin/assets/js/stripe-elements.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2192","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/css/express-checkout.css","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2193","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/css/stripe-elements.css","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2194","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/alipay.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2195","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/apple-pay-gray.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2196","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/apple-pay-light.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2197","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/bancontact.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2198","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/credit-card.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2199","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/express-checkout.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2200","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/gpay_gray.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2201","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/gpay_light.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2202","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/ideal.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2203","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/klarna.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2204","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/p24.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2205","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/payment-request-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2206","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/sepa.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2207","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/icon/wechat.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2208","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/js/payment-request.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2209","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/assets/js/stripe-elements.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:42","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2210","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/lib/stripe-php/phpdoc.dist.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2211","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/build/app.css","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2212","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/build/app.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2213","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/images/apple-pay.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2214","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/images/cpsw-logo-light.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2215","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/images/cpsw-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2216","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/images/gpay.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2217","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/js/helper.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2218","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/src/components/Logo.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2219","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/src/components/Spinner.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2220","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/src/pages/ExpressCheckout.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2221","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/src/pages/Failed.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2222","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/src/pages/HomePage.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2223","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/src/pages/Success.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2224","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/src/pages/ThankYou.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2225","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/src/pages/Webhooks.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2226","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/src/pages/WooCommerce.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2227","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/src/App.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2228","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/wizard/src/Settings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2229","static_file","/wp-content/plugins/checkout-plugins-stripe-woo/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-04-28 07:16:43","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2230","static_file","/wp-content/plugins/contact-form-7/admin/css/styles-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2231","static_file","/wp-content/plugins/contact-form-7/admin/css/styles.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2232","static_file","/wp-content/plugins/contact-form-7/admin/js/scripts.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2233","static_file","/wp-content/plugins/contact-form-7/admin/js/tag-generator.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2234","static_file","/wp-content/plugins/contact-form-7/assets/icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2235","static_file","/wp-content/plugins/contact-form-7/assets/icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2236","static_file","/wp-content/plugins/contact-form-7/includes/block-editor/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2237","static_file","/wp-content/plugins/contact-form-7/includes/css/styles-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2238","static_file","/wp-content/plugins/contact-form-7/includes/css/styles.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2239","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/images/ui-bg_glass_55_fbf9ee_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2240","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/images/ui-bg_glass_65_ffffff_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2241","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/images/ui-bg_glass_75_dadada_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2242","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/images/ui-bg_glass_75_e6e6e6_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2243","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/images/ui-bg_glass_95_fef1ec_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2244","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/images/ui-bg_highlight-soft_75_cccccc_1x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2245","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/images/ui-icons_222222_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2246","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/images/ui-icons_2e83ff_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2247","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/images/ui-icons_454545_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2248","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/images/ui-icons_888888_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2249","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/images/ui-icons_cd0a0a_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2250","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/jquery-ui.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2251","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/jquery-ui.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2252","static_file","/wp-content/plugins/contact-form-7/includes/js/jquery-ui/themes/smoothness/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2253","static_file","/wp-content/plugins/contact-form-7/includes/js/html5-fallback.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2254","static_file","/wp-content/plugins/contact-form-7/includes/js/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2255","static_file","/wp-content/plugins/contact-form-7/includes/swv/js/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2256","static_file","/wp-content/plugins/contact-form-7/languages/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2257","static_file","/wp-content/plugins/contact-form-7/modules/recaptcha/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2258","static_file","/wp-content/plugins/contact-form-7/modules/stripe/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2259","static_file","/wp-content/plugins/contact-form-7/modules/stripe/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2260","static_file","/wp-content/plugins/contact-form-7/license.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2261","static_file","/wp-content/plugins/contact-form-7/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-06 09:02:46","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2262","static_file","/wp-content/plugins/elementor-beta/modules/developer-edition/assets/css/developer-edition.css","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:29:54","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2263","static_file","/wp-content/plugins/elementor-beta/modules/developer-edition/assets/js/developer-edition.js","","","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:29:54","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2264","static_file","/wp-content/plugins/elementor-beta/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-04-28 07:29:54","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2265","static_file","/wp-content/plugins/elementor/assets/css/modules/ai/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2266","static_file","/wp-content/plugins/elementor/assets/css/modules/ai/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2267","static_file","/wp-content/plugins/elementor/assets/css/modules/announcements/announcements.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2268","static_file","/wp-content/plugins/elementor/assets/css/modules/announcements/announcements.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2269","static_file","/wp-content/plugins/elementor/assets/css/modules/apps/admin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2270","static_file","/wp-content/plugins/elementor/assets/css/modules/apps/admin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2271","static_file","/wp-content/plugins/elementor/assets/css/modules/container-converter/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2272","static_file","/wp-content/plugins/elementor/assets/css/modules/container-converter/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2273","static_file","/wp-content/plugins/elementor/assets/css/modules/lazyload/frontend.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2274","static_file","/wp-content/plugins/elementor/assets/css/modules/lazyload/frontend.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2275","static_file","/wp-content/plugins/elementor/assets/css/modules/notes/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2276","static_file","/wp-content/plugins/elementor/assets/css/modules/notes/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2277","static_file","/wp-content/plugins/elementor/assets/css/modules/styleguide/styleguide.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2278","static_file","/wp-content/plugins/elementor/assets/css/modules/styleguide/styleguide.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2279","static_file","/wp-content/plugins/elementor/assets/css/templates/frontend-legacy-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2280","static_file","/wp-content/plugins/elementor/assets/css/templates/frontend-legacy-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2281","static_file","/wp-content/plugins/elementor/assets/css/templates/frontend-legacy.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2282","static_file","/wp-content/plugins/elementor/assets/css/templates/frontend-legacy.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2283","static_file","/wp-content/plugins/elementor/assets/css/templates/frontend-lite-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2284","static_file","/wp-content/plugins/elementor/assets/css/templates/frontend-lite-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2285","static_file","/wp-content/plugins/elementor/assets/css/templates/frontend-lite.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2286","static_file","/wp-content/plugins/elementor/assets/css/templates/frontend-lite.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2287","static_file","/wp-content/plugins/elementor/assets/css/templates/frontend-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2288","static_file","/wp-content/plugins/elementor/assets/css/templates/frontend-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2289","static_file","/wp-content/plugins/elementor/assets/css/templates/frontend.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2290","static_file","/wp-content/plugins/elementor/assets/css/templates/frontend.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2291","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-accordion-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2292","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-accordion.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2293","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-alert-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2294","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-alert.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2295","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-icon-box-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2296","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-icon-box.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2297","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-icon-list-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2298","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-icon-list.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2299","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-image-box-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2300","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-image-box.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2301","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-image-gallery-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2302","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-image-gallery.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2303","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-progress-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2304","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-progress.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2305","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-star-rating-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2306","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-star-rating.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2307","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-tabs-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2308","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-tabs.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2309","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-toggle-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2310","static_file","/wp-content/plugins/elementor/assets/css/templates/widget-toggle.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2311","static_file","/wp-content/plugins/elementor/assets/css/admin-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2312","static_file","/wp-content/plugins/elementor/assets/css/admin-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2313","static_file","/wp-content/plugins/elementor/assets/css/admin-top-bar-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2314","static_file","/wp-content/plugins/elementor/assets/css/admin-top-bar-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2315","static_file","/wp-content/plugins/elementor/assets/css/admin-top-bar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2316","static_file","/wp-content/plugins/elementor/assets/css/admin-top-bar.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2317","static_file","/wp-content/plugins/elementor/assets/css/admin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2318","static_file","/wp-content/plugins/elementor/assets/css/admin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2319","static_file","/wp-content/plugins/elementor/assets/css/app-base-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2320","static_file","/wp-content/plugins/elementor/assets/css/app-base-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2321","static_file","/wp-content/plugins/elementor/assets/css/app-base.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2322","static_file","/wp-content/plugins/elementor/assets/css/app-base.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2323","static_file","/wp-content/plugins/elementor/assets/css/app-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2324","static_file","/wp-content/plugins/elementor/assets/css/app-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2325","static_file","/wp-content/plugins/elementor/assets/css/app.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2326","static_file","/wp-content/plugins/elementor/assets/css/app.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2327","static_file","/wp-content/plugins/elementor/assets/css/common-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2328","static_file","/wp-content/plugins/elementor/assets/css/common-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2329","static_file","/wp-content/plugins/elementor/assets/css/common.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2330","static_file","/wp-content/plugins/elementor/assets/css/common.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2331","static_file","/wp-content/plugins/elementor/assets/css/editor-preview-legacy-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2332","static_file","/wp-content/plugins/elementor/assets/css/editor-preview-legacy-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2333","static_file","/wp-content/plugins/elementor/assets/css/editor-preview-legacy.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2334","static_file","/wp-content/plugins/elementor/assets/css/editor-preview-legacy.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2335","static_file","/wp-content/plugins/elementor/assets/css/editor-preview-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2336","static_file","/wp-content/plugins/elementor/assets/css/editor-preview-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2337","static_file","/wp-content/plugins/elementor/assets/css/editor-preview.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2338","static_file","/wp-content/plugins/elementor/assets/css/editor-preview.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2339","static_file","/wp-content/plugins/elementor/assets/css/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2340","static_file","/wp-content/plugins/elementor/assets/css/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2341","static_file","/wp-content/plugins/elementor/assets/css/editor-v2-overrides.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2342","static_file","/wp-content/plugins/elementor/assets/css/editor-v2-overrides.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2343","static_file","/wp-content/plugins/elementor/assets/css/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2344","static_file","/wp-content/plugins/elementor/assets/css/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2345","static_file","/wp-content/plugins/elementor/assets/css/frontend-legacy-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2346","static_file","/wp-content/plugins/elementor/assets/css/frontend-legacy-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2347","static_file","/wp-content/plugins/elementor/assets/css/frontend-legacy.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2348","static_file","/wp-content/plugins/elementor/assets/css/frontend-legacy.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2349","static_file","/wp-content/plugins/elementor/assets/css/frontend-lite-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2350","static_file","/wp-content/plugins/elementor/assets/css/frontend-lite-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2351","static_file","/wp-content/plugins/elementor/assets/css/frontend-lite.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2352","static_file","/wp-content/plugins/elementor/assets/css/frontend-lite.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2353","static_file","/wp-content/plugins/elementor/assets/css/frontend-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2354","static_file","/wp-content/plugins/elementor/assets/css/frontend-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2355","static_file","/wp-content/plugins/elementor/assets/css/frontend.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:30","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2356","static_file","/wp-content/plugins/elementor/assets/css/frontend.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2357","static_file","/wp-content/plugins/elementor/assets/css/responsive-bar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2358","static_file","/wp-content/plugins/elementor/assets/css/responsive-bar.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2359","static_file","/wp-content/plugins/elementor/assets/css/theme-dark.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2360","static_file","/wp-content/plugins/elementor/assets/css/theme-dark.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2361","static_file","/wp-content/plugins/elementor/assets/css/theme-light.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2362","static_file","/wp-content/plugins/elementor/assets/css/theme-light.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2363","static_file","/wp-content/plugins/elementor/assets/css/widget-accordion-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2364","static_file","/wp-content/plugins/elementor/assets/css/widget-accordion.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2365","static_file","/wp-content/plugins/elementor/assets/css/widget-alert-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2366","static_file","/wp-content/plugins/elementor/assets/css/widget-alert.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2367","static_file","/wp-content/plugins/elementor/assets/css/widget-counter-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2368","static_file","/wp-content/plugins/elementor/assets/css/widget-counter.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2369","static_file","/wp-content/plugins/elementor/assets/css/widget-divider-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2370","static_file","/wp-content/plugins/elementor/assets/css/widget-divider.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2371","static_file","/wp-content/plugins/elementor/assets/css/widget-google_maps-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2372","static_file","/wp-content/plugins/elementor/assets/css/widget-google_maps.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2373","static_file","/wp-content/plugins/elementor/assets/css/widget-heading-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2374","static_file","/wp-content/plugins/elementor/assets/css/widget-heading.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2375","static_file","/wp-content/plugins/elementor/assets/css/widget-icon-box-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2376","static_file","/wp-content/plugins/elementor/assets/css/widget-icon-box.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2377","static_file","/wp-content/plugins/elementor/assets/css/widget-icon-list-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2378","static_file","/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2379","static_file","/wp-content/plugins/elementor/assets/css/widget-image-box-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2380","static_file","/wp-content/plugins/elementor/assets/css/widget-image-box.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2381","static_file","/wp-content/plugins/elementor/assets/css/widget-image-carousel-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2382","static_file","/wp-content/plugins/elementor/assets/css/widget-image-carousel.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2383","static_file","/wp-content/plugins/elementor/assets/css/widget-image-gallery-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2384","static_file","/wp-content/plugins/elementor/assets/css/widget-image-gallery.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2385","static_file","/wp-content/plugins/elementor/assets/css/widget-image-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2386","static_file","/wp-content/plugins/elementor/assets/css/widget-image.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2387","static_file","/wp-content/plugins/elementor/assets/css/widget-menu-anchor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2388","static_file","/wp-content/plugins/elementor/assets/css/widget-menu-anchor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2389","static_file","/wp-content/plugins/elementor/assets/css/widget-progress-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2390","static_file","/wp-content/plugins/elementor/assets/css/widget-progress.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2391","static_file","/wp-content/plugins/elementor/assets/css/widget-social-icons-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2392","static_file","/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2393","static_file","/wp-content/plugins/elementor/assets/css/widget-spacer-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2394","static_file","/wp-content/plugins/elementor/assets/css/widget-spacer.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:31","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2395","static_file","/wp-content/plugins/elementor/assets/css/widget-star-rating-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2396","static_file","/wp-content/plugins/elementor/assets/css/widget-star-rating.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2397","static_file","/wp-content/plugins/elementor/assets/css/widget-tabs-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2398","static_file","/wp-content/plugins/elementor/assets/css/widget-tabs.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2399","static_file","/wp-content/plugins/elementor/assets/css/widget-testimonial-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2400","static_file","/wp-content/plugins/elementor/assets/css/widget-testimonial.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2401","static_file","/wp-content/plugins/elementor/assets/css/widget-text-editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2402","static_file","/wp-content/plugins/elementor/assets/css/widget-text-editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2403","static_file","/wp-content/plugins/elementor/assets/css/widget-toggle-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2404","static_file","/wp-content/plugins/elementor/assets/css/widget-toggle.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2405","static_file","/wp-content/plugins/elementor/assets/css/widget-video-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2406","static_file","/wp-content/plugins/elementor/assets/css/widget-video.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2407","static_file","/wp-content/plugins/elementor/assets/images/app/onboarding/Blank_Preview.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2408","static_file","/wp-content/plugins/elementor/assets/images/app/onboarding/Blank_Canvas.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2409","static_file","/wp-content/plugins/elementor/assets/images/app/onboarding/Illustration_Account.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2410","static_file","/wp-content/plugins/elementor/assets/images/app/onboarding/Illustration_Hello.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2411","static_file","/wp-content/plugins/elementor/assets/images/app/onboarding/Illustration_Setup.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2412","static_file","/wp-content/plugins/elementor/assets/images/app/onboarding/Library.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2413","static_file","/wp-content/plugins/elementor/assets/images/app/site-editor/archive.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2414","static_file","/wp-content/plugins/elementor/assets/images/app/site-editor/error-404.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2415","static_file","/wp-content/plugins/elementor/assets/images/app/site-editor/footer.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2416","static_file","/wp-content/plugins/elementor/assets/images/app/site-editor/header.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2417","static_file","/wp-content/plugins/elementor/assets/images/app/site-editor/product.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2418","static_file","/wp-content/plugins/elementor/assets/images/app/site-editor/products.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2419","static_file","/wp-content/plugins/elementor/assets/images/app/site-editor/search-results.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2420","static_file","/wp-content/plugins/elementor/assets/images/app/site-editor/single-page.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2421","static_file","/wp-content/plugins/elementor/assets/images/app/site-editor/single-post.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2422","static_file","/wp-content/plugins/elementor/assets/images/library-connect/left-1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2423","static_file","/wp-content/plugins/elementor/assets/images/library-connect/left-2.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2424","static_file","/wp-content/plugins/elementor/assets/images/library-connect/right-1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2425","static_file","/wp-content/plugins/elementor/assets/images/library-connect/right-2.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2426","static_file","/wp-content/plugins/elementor/assets/images/ajax-loader.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2427","static_file","/wp-content/plugins/elementor/assets/images/announcement.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2428","static_file","/wp-content/plugins/elementor/assets/images/blur.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2429","static_file","/wp-content/plugins/elementor/assets/images/containers-announcement.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2430","static_file","/wp-content/plugins/elementor/assets/images/contrast.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2431","static_file","/wp-content/plugins/elementor/assets/images/logo-icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2432","static_file","/wp-content/plugins/elementor/assets/images/placeholder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2433","static_file","/wp-content/plugins/elementor/assets/images/eyedropper.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2434","static_file","/wp-content/plugins/elementor/assets/images/go-pro-wp-dashboard.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2435","static_file","/wp-content/plugins/elementor/assets/images/go-pro.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2436","static_file","/wp-content/plugins/elementor/assets/images/information.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2437","static_file","/wp-content/plugins/elementor/assets/images/logo-panel.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2438","static_file","/wp-content/plugins/elementor/assets/images/logo-platform.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2439","static_file","/wp-content/plugins/elementor/assets/images/no-search-results.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2440","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-app-bar/editor-app-bar.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2441","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-app-bar/editor-app-bar.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2442","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-app-bar/editor-app-bar.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2443","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-documents/editor-documents.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2444","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-documents/editor-documents.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2445","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-documents/editor-documents.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2446","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-panels/editor-panels.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2447","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-panels/editor-panels.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2448","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-panels/editor-panels.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2449","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-responsive/editor-responsive.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2450","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-responsive/editor-responsive.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2451","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-responsive/editor-responsive.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2452","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-site-navigation/editor-site-navigation.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2453","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-site-navigation/editor-site-navigation.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2454","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-site-navigation/editor-site-navigation.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2455","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-v1-adapters/editor-v1-adapters.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2456","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-v1-adapters/editor-v1-adapters.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2457","static_file","/wp-content/plugins/elementor/assets/js/packages/editor-v1-adapters/editor-v1-adapters.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2458","static_file","/wp-content/plugins/elementor/assets/js/packages/editor/editor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2459","static_file","/wp-content/plugins/elementor/assets/js/packages/editor/editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2460","static_file","/wp-content/plugins/elementor/assets/js/packages/editor/editor.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2461","static_file","/wp-content/plugins/elementor/assets/js/packages/env/env.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2462","static_file","/wp-content/plugins/elementor/assets/js/packages/env/env.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2463","static_file","/wp-content/plugins/elementor/assets/js/packages/env/env.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2464","static_file","/wp-content/plugins/elementor/assets/js/packages/icons/icons.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2465","static_file","/wp-content/plugins/elementor/assets/js/packages/icons/icons.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2466","static_file","/wp-content/plugins/elementor/assets/js/packages/icons/icons.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2467","static_file","/wp-content/plugins/elementor/assets/js/packages/locations/locations.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2468","static_file","/wp-content/plugins/elementor/assets/js/packages/locations/locations.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2469","static_file","/wp-content/plugins/elementor/assets/js/packages/locations/locations.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2470","static_file","/wp-content/plugins/elementor/assets/js/packages/query/query.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2471","static_file","/wp-content/plugins/elementor/assets/js/packages/query/query.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2472","static_file","/wp-content/plugins/elementor/assets/js/packages/query/query.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2473","static_file","/wp-content/plugins/elementor/assets/js/packages/query/query.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2474","static_file","/wp-content/plugins/elementor/assets/js/packages/store/store.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2475","static_file","/wp-content/plugins/elementor/assets/js/packages/store/store.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2476","static_file","/wp-content/plugins/elementor/assets/js/packages/store/store.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2477","static_file","/wp-content/plugins/elementor/assets/js/packages/store/store.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2478","static_file","/wp-content/plugins/elementor/assets/js/packages/ui/ui.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2479","static_file","/wp-content/plugins/elementor/assets/js/packages/ui/ui.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2480","static_file","/wp-content/plugins/elementor/assets/js/packages/ui/ui.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2481","static_file","/wp-content/plugins/elementor/assets/js/packages/ui/ui.strings.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2482","static_file","/wp-content/plugins/elementor/assets/js/081ef1d595d61b745bca.bundle.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2483","static_file","/wp-content/plugins/elementor/assets/js/admin-modules.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2484","static_file","/wp-content/plugins/elementor/assets/js/admin.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2485","static_file","/wp-content/plugins/elementor/assets/js/ai-admin.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:33","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2486","static_file","/wp-content/plugins/elementor/assets/js/ai.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:34","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2487","static_file","/wp-content/plugins/elementor/assets/js/announcements-app.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:34","0000-00-00 00:00:00","2023-09-07 12:54:33");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2488","static_file","/wp-content/plugins/elementor/assets/js/app-packages.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2489","static_file","/wp-content/plugins/elementor/assets/js/app.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2490","static_file","/wp-content/plugins/elementor/assets/js/common.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2491","static_file","/wp-content/plugins/elementor/assets/js/editor-modules.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2492","static_file","/wp-content/plugins/elementor/assets/js/editor.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2493","static_file","/wp-content/plugins/elementor/assets/js/kit-elements-defaults-editor.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2494","static_file","/wp-content/plugins/elementor/assets/js/nested-accordion.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2495","static_file","/wp-content/plugins/elementor/assets/js/nested-tabs.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2496","static_file","/wp-content/plugins/elementor/assets/js/styleguide-app-initiator.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2497","static_file","/wp-content/plugins/elementor/assets/js/web-cli.min.js.LICENSE.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2498","static_file","/wp-content/plugins/elementor/assets/js/081ef1d595d61b745bca.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2499","static_file","/wp-content/plugins/elementor/assets/js/1bef795bdeaafc779b19.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2500","static_file","/wp-content/plugins/elementor/assets/js/46e544e5863270fc32f2.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2501","static_file","/wp-content/plugins/elementor/assets/js/4fdaa70e951ad90db2f2.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2502","static_file","/wp-content/plugins/elementor/assets/js/6dc72ebebb42e6117899.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2503","static_file","/wp-content/plugins/elementor/assets/js/6ed74dd3befaff90b65c.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2504","static_file","/wp-content/plugins/elementor/assets/js/79d91b3af4aa6bc1c967.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2505","static_file","/wp-content/plugins/elementor/assets/js/906cf49fecec599e1a67.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2506","static_file","/wp-content/plugins/elementor/assets/js/a493d490206d9432cc8b.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2507","static_file","/wp-content/plugins/elementor/assets/js/a730ee9caa710006b307.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2508","static_file","/wp-content/plugins/elementor/assets/js/ab59172d5784d868ebd9.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2509","static_file","/wp-content/plugins/elementor/assets/js/accordion.8799675460c73eb48972.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2510","static_file","/wp-content/plugins/elementor/assets/js/accordion.c16b88b2e8a0c50189bc.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2511","static_file","/wp-content/plugins/elementor/assets/js/admin-feedback.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2512","static_file","/wp-content/plugins/elementor/assets/js/admin-feedback.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2513","static_file","/wp-content/plugins/elementor/assets/js/admin-modules.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2514","static_file","/wp-content/plugins/elementor/assets/js/admin-modules.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2515","static_file","/wp-content/plugins/elementor/assets/js/admin-top-bar.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2516","static_file","/wp-content/plugins/elementor/assets/js/admin-top-bar.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2517","static_file","/wp-content/plugins/elementor/assets/js/admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2518","static_file","/wp-content/plugins/elementor/assets/js/admin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2519","static_file","/wp-content/plugins/elementor/assets/js/ai-admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:33","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2520","static_file","/wp-content/plugins/elementor/assets/js/ai-admin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:33","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2521","static_file","/wp-content/plugins/elementor/assets/js/ai.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:34","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2522","static_file","/wp-content/plugins/elementor/assets/js/ai.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:34","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2523","static_file","/wp-content/plugins/elementor/assets/js/alert.c3c6a3fdf4745bd26b7f.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:34","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2524","static_file","/wp-content/plugins/elementor/assets/js/alert.cbc2a0fee74ee3ed0419.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:34","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2525","static_file","/wp-content/plugins/elementor/assets/js/announcements-app.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:34","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2526","static_file","/wp-content/plugins/elementor/assets/js/announcements-app.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:34","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2527","static_file","/wp-content/plugins/elementor/assets/js/app-loader.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2528","static_file","/wp-content/plugins/elementor/assets/js/app-loader.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2529","static_file","/wp-content/plugins/elementor/assets/js/app-packages.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2530","static_file","/wp-content/plugins/elementor/assets/js/app-packages.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2531","static_file","/wp-content/plugins/elementor/assets/js/app.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2532","static_file","/wp-content/plugins/elementor/assets/js/app.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2533","static_file","/wp-content/plugins/elementor/assets/js/be69c0d71c69e96d6a96.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2534","static_file","/wp-content/plugins/elementor/assets/js/beta-tester.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2535","static_file","/wp-content/plugins/elementor/assets/js/beta-tester.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2536","static_file","/wp-content/plugins/elementor/assets/js/c1dd514ac8d43fbb6919.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2537","static_file","/wp-content/plugins/elementor/assets/js/common-modules.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2538","static_file","/wp-content/plugins/elementor/assets/js/common-modules.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2539","static_file","/wp-content/plugins/elementor/assets/js/common.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:35","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2540","static_file","/wp-content/plugins/elementor/assets/js/common.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2541","static_file","/wp-content/plugins/elementor/assets/js/container-converter.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2542","static_file","/wp-content/plugins/elementor/assets/js/container-converter.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2543","static_file","/wp-content/plugins/elementor/assets/js/container.284c9bf9b36eadd05080.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2544","static_file","/wp-content/plugins/elementor/assets/js/container.dfea7c883442d5ae61c8.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2545","static_file","/wp-content/plugins/elementor/assets/js/counter.02cef29c589e742d4c8c.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2546","static_file","/wp-content/plugins/elementor/assets/js/counter.3f74a246dff765f39aea.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2547","static_file","/wp-content/plugins/elementor/assets/js/d3bdd130eb38d3b07f85.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2548","static_file","/wp-content/plugins/elementor/assets/js/d6220da5189e9a2aac43.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2549","static_file","/wp-content/plugins/elementor/assets/js/dev-tools.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2550","static_file","/wp-content/plugins/elementor/assets/js/dev-tools.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2551","static_file","/wp-content/plugins/elementor/assets/js/e8a7573e654d921656ab.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2552","static_file","/wp-content/plugins/elementor/assets/js/editor-document.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2553","static_file","/wp-content/plugins/elementor/assets/js/editor-document.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2554","static_file","/wp-content/plugins/elementor/assets/js/editor-environment-v2.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2555","static_file","/wp-content/plugins/elementor/assets/js/editor-environment-v2.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2556","static_file","/wp-content/plugins/elementor/assets/js/editor-loader-v1.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:37","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2557","static_file","/wp-content/plugins/elementor/assets/js/editor-loader-v1.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:37","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2558","static_file","/wp-content/plugins/elementor/assets/js/editor-loader-v2.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:37","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2559","static_file","/wp-content/plugins/elementor/assets/js/editor-loader-v2.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:37","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2560","static_file","/wp-content/plugins/elementor/assets/js/editor-modules.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2561","static_file","/wp-content/plugins/elementor/assets/js/editor-modules.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2562","static_file","/wp-content/plugins/elementor/assets/js/editor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:37","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2563","static_file","/wp-content/plugins/elementor/assets/js/editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2564","static_file","/wp-content/plugins/elementor/assets/js/elementor-admin-bar.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2565","static_file","/wp-content/plugins/elementor/assets/js/elementor-admin-bar.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2566","static_file","/wp-content/plugins/elementor/assets/js/f9b37afff6a65f7b9541.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2567","static_file","/wp-content/plugins/elementor/assets/js/frontend-modules.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2568","static_file","/wp-content/plugins/elementor/assets/js/frontend-modules.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2569","static_file","/wp-content/plugins/elementor/assets/js/frontend.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2570","static_file","/wp-content/plugins/elementor/assets/js/frontend.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2571","static_file","/wp-content/plugins/elementor/assets/js/gutenberg.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2572","static_file","/wp-content/plugins/elementor/assets/js/gutenberg.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2573","static_file","/wp-content/plugins/elementor/assets/js/image-carousel.4455c6362492d9067512.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2574","static_file","/wp-content/plugins/elementor/assets/js/image-carousel.9399f19d95d7300cbc2e.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2575","static_file","/wp-content/plugins/elementor/assets/js/import-export-admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2576","static_file","/wp-content/plugins/elementor/assets/js/import-export-admin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2577","static_file","/wp-content/plugins/elementor/assets/js/kit-elements-defaults-editor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2578","static_file","/wp-content/plugins/elementor/assets/js/kit-elements-defaults-editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2579","static_file","/wp-content/plugins/elementor/assets/js/kit-library.26f1573ff46203710889.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2580","static_file","/wp-content/plugins/elementor/assets/js/kit-library.b4cf9f541e44f7bbc972.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2581","static_file","/wp-content/plugins/elementor/assets/js/lightbox.1b6e05e0607040eb8929.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2582","static_file","/wp-content/plugins/elementor/assets/js/lightbox.c35dbfc7181d730b570c.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2583","static_file","/wp-content/plugins/elementor/assets/js/nested-accordion.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2584","static_file","/wp-content/plugins/elementor/assets/js/nested-accordion.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2585","static_file","/wp-content/plugins/elementor/assets/js/nested-elements.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2586","static_file","/wp-content/plugins/elementor/assets/js/nested-elements.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2587","static_file","/wp-content/plugins/elementor/assets/js/nested-tabs.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2588","static_file","/wp-content/plugins/elementor/assets/js/nested-tabs.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2589","static_file","/wp-content/plugins/elementor/assets/js/new-template.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2590","static_file","/wp-content/plugins/elementor/assets/js/new-template.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2591","static_file","/wp-content/plugins/elementor/assets/js/notes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2592","static_file","/wp-content/plugins/elementor/assets/js/notes.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:38","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2593","static_file","/wp-content/plugins/elementor/assets/js/onboarding.c7161864bbc938281940.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2594","static_file","/wp-content/plugins/elementor/assets/js/onboarding.d1f3b86a6e269191f707.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:39","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2595","static_file","/wp-content/plugins/elementor/assets/js/preloaded-modules.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2596","static_file","/wp-content/plugins/elementor/assets/js/preloaded-modules.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2597","static_file","/wp-content/plugins/elementor/assets/js/progress.553d43a5b3903206bedc.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2598","static_file","/wp-content/plugins/elementor/assets/js/progress.ca55d33bb06cee4e6f02.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2599","static_file","/wp-content/plugins/elementor/assets/js/responsive-bar.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2600","static_file","/wp-content/plugins/elementor/assets/js/responsive-bar.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2601","static_file","/wp-content/plugins/elementor/assets/js/styleguide-app-initiator.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2602","static_file","/wp-content/plugins/elementor/assets/js/styleguide-app-initiator.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2603","static_file","/wp-content/plugins/elementor/assets/js/styleguide.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2604","static_file","/wp-content/plugins/elementor/assets/js/styleguide.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2605","static_file","/wp-content/plugins/elementor/assets/js/tabs.520bc2ed4560c561029e.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2606","static_file","/wp-content/plugins/elementor/assets/js/tabs.c2af5be7f9cb3cdcf3d5.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2607","static_file","/wp-content/plugins/elementor/assets/js/text-editor.2c35aafbe5bf0e127950.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2608","static_file","/wp-content/plugins/elementor/assets/js/text-editor.2f2f7e0ea1e16387a004.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2609","static_file","/wp-content/plugins/elementor/assets/js/text-path.b50b3e74488a4e302613.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2610","static_file","/wp-content/plugins/elementor/assets/js/text-path.bfa8a1f6fcf6c803aaa9.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2611","static_file","/wp-content/plugins/elementor/assets/js/toggle.31881477c45ff5cf9d4d.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2612","static_file","/wp-content/plugins/elementor/assets/js/toggle.d79746a764407a0828ee.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2613","static_file","/wp-content/plugins/elementor/assets/js/video.bb330f394f46f2666bc1.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2614","static_file","/wp-content/plugins/elementor/assets/js/video.fea4f8dfdf17262f23e8.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2615","static_file","/wp-content/plugins/elementor/assets/js/web-cli.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2616","static_file","/wp-content/plugins/elementor/assets/js/web-cli.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:41","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2617","static_file","/wp-content/plugins/elementor/assets/js/webpack.runtime.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2618","static_file","/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2619","static_file","/wp-content/plugins/elementor/assets/js/wp-audio.75f0ced143febb8cd31a.bundle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2620","static_file","/wp-content/plugins/elementor/assets/js/wp-audio.b8efdc046bc9df72a075.bundle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2621","static_file","/wp-content/plugins/elementor/assets/lib/animate.css/animate.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2622","static_file","/wp-content/plugins/elementor/assets/lib/animate.css/animate.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2623","static_file","/wp-content/plugins/elementor/assets/lib/animations/animations.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2624","static_file","/wp-content/plugins/elementor/assets/lib/backbone/backbone.marionette.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2625","static_file","/wp-content/plugins/elementor/assets/lib/backbone/backbone.marionette.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2626","static_file","/wp-content/plugins/elementor/assets/lib/backbone/backbone.radio.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2627","static_file","/wp-content/plugins/elementor/assets/lib/backbone/backbone.radio.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2628","static_file","/wp-content/plugins/elementor/assets/lib/color-thief/color-thief.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2629","static_file","/wp-content/plugins/elementor/assets/lib/dialog/dialog.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2630","static_file","/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2631","static_file","/wp-content/plugins/elementor/assets/lib/e-gallery/css/e-gallery.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2632","static_file","/wp-content/plugins/elementor/assets/lib/e-gallery/css/e-gallery.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2633","static_file","/wp-content/plugins/elementor/assets/lib/e-gallery/js/e-gallery.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2634","static_file","/wp-content/plugins/elementor/assets/lib/e-gallery/js/e-gallery.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2635","static_file","/wp-content/plugins/elementor/assets/lib/e-select2/css/e-select2.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2636","static_file","/wp-content/plugins/elementor/assets/lib/e-select2/css/e-select2.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2637","static_file","/wp-content/plugins/elementor/assets/lib/e-select2/js/e-select2.full.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2638","static_file","/wp-content/plugins/elementor/assets/lib/e-select2/js/e-select2.full.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2639","static_file","/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2640","static_file","/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2641","static_file","/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2642","static_file","/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2643","static_file","/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2644","static_file","/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2645","static_file","/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2646","static_file","/wp-content/plugins/elementor/assets/lib/flatpickr/flatpickr.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2647","static_file","/wp-content/plugins/elementor/assets/lib/flatpickr/flatpickr.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2648","static_file","/wp-content/plugins/elementor/assets/lib/flatpickr/flatpickr.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2649","static_file","/wp-content/plugins/elementor/assets/lib/flatpickr/flatpickr.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2650","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2651","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2652","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2653","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2654","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2655","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2656","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2657","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2658","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2659","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2660","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2661","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2662","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/svg-with-js.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2663","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/svg-with-js.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2664","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2665","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2666","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/fonts/fontawesome-webfont.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2667","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/fonts/fontawesome-webfont.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2668","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/fonts/fontawesome-webfont.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2669","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/fonts/FontAwesome.otf","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2670","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/fonts/fontawesome-webfont.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2671","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/fonts/fontawesome-webfont.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2672","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/js/brands.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2673","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/js/regular.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:44","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2674","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/js/solid.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:44","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2675","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:44","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2676","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:44","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2677","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/migration/mapping.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:44","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2678","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-brands-400.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:44","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2679","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-regular-400.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2680","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-solid-900.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2681","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-brands-400.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2682","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-regular-400.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2683","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-solid-900.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2684","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-brands-400.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2685","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-regular-400.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2686","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-solid-900.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2687","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-brands-400.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:44","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2688","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-regular-400.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2689","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-solid-900.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2690","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-brands-400.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:44","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2691","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-regular-400.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2692","static_file","/wp-content/plugins/elementor/assets/lib/font-awesome/webfonts/fa-solid-900.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2693","static_file","/wp-content/plugins/elementor/assets/lib/hover/hover.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2694","static_file","/wp-content/plugins/elementor/assets/lib/hover/hover.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2695","static_file","/wp-content/plugins/elementor/assets/lib/imagesloaded/imagesloaded.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2696","static_file","/wp-content/plugins/elementor/assets/lib/imagesloaded/imagesloaded.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2697","static_file","/wp-content/plugins/elementor/assets/lib/inline-editor/js/inline-editor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2698","static_file","/wp-content/plugins/elementor/assets/lib/inline-editor/js/inline-editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2699","static_file","/wp-content/plugins/elementor/assets/lib/jquery-easing/jquery-easing.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2700","static_file","/wp-content/plugins/elementor/assets/lib/jquery-easing/jquery-easing.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2701","static_file","/wp-content/plugins/elementor/assets/lib/jquery-hover-intent/jquery-hover-intent.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2702","static_file","/wp-content/plugins/elementor/assets/lib/jquery-hover-intent/jquery-hover-intent.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2703","static_file","/wp-content/plugins/elementor/assets/lib/jquery-numerator/jquery-numerator.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2704","static_file","/wp-content/plugins/elementor/assets/lib/jquery-numerator/jquery-numerator.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:45","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2705","static_file","/wp-content/plugins/elementor/assets/lib/nouislider/nouislider.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2706","static_file","/wp-content/plugins/elementor/assets/lib/nouislider/nouislider.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2707","static_file","/wp-content/plugins/elementor/assets/lib/nprogress/nprogress.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2708","static_file","/wp-content/plugins/elementor/assets/lib/nprogress/nprogress.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2709","static_file","/wp-content/plugins/elementor/assets/lib/perfect-scrollbar/js/perfect-scrollbar.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2710","static_file","/wp-content/plugins/elementor/assets/lib/perfect-scrollbar/js/perfect-scrollbar.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2711","static_file","/wp-content/plugins/elementor/assets/lib/pickr/themes/monolith.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2712","static_file","/wp-content/plugins/elementor/assets/lib/pickr/pickr.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2713","static_file","/wp-content/plugins/elementor/assets/lib/share-link/share-link.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2714","static_file","/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2715","static_file","/wp-content/plugins/elementor/assets/lib/swiper/css/swiper.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2716","static_file","/wp-content/plugins/elementor/assets/lib/swiper/css/swiper.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2717","static_file","/wp-content/plugins/elementor/assets/lib/swiper/v8/css/swiper.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2718","static_file","/wp-content/plugins/elementor/assets/lib/swiper/v8/css/swiper.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2719","static_file","/wp-content/plugins/elementor/assets/lib/swiper/v8/swiper.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2720","static_file","/wp-content/plugins/elementor/assets/lib/swiper/v8/swiper.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2721","static_file","/wp-content/plugins/elementor/assets/lib/swiper/swiper.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2722","static_file","/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2723","static_file","/wp-content/plugins/elementor/assets/lib/tipsy/tipsy.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2724","static_file","/wp-content/plugins/elementor/assets/lib/tipsy/tipsy.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2725","static_file","/wp-content/plugins/elementor/assets/lib/waypoints/waypoints-for-editor.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2726","static_file","/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2727","static_file","/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2728","static_file","/wp-content/plugins/elementor/assets/lib/animate.css","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2729","static_file","/wp-content/plugins/elementor/assets/mask-shapes/blob.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2730","static_file","/wp-content/plugins/elementor/assets/mask-shapes/circle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2731","static_file","/wp-content/plugins/elementor/assets/mask-shapes/flower.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2732","static_file","/wp-content/plugins/elementor/assets/mask-shapes/hexagon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2733","static_file","/wp-content/plugins/elementor/assets/mask-shapes/sketch.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2734","static_file","/wp-content/plugins/elementor/assets/mask-shapes/triangle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2735","static_file","/wp-content/plugins/elementor/assets/shapes/arrow-negative.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2736","static_file","/wp-content/plugins/elementor/assets/shapes/arrow.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:46","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2737","static_file","/wp-content/plugins/elementor/assets/shapes/book-negative.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2738","static_file","/wp-content/plugins/elementor/assets/shapes/book.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2739","static_file","/wp-content/plugins/elementor/assets/shapes/clouds-negative.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2740","static_file","/wp-content/plugins/elementor/assets/shapes/clouds.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2741","static_file","/wp-content/plugins/elementor/assets/shapes/curve-asymmetrical-negative.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2742","static_file","/wp-content/plugins/elementor/assets/shapes/curve-asymmetrical.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2743","static_file","/wp-content/plugins/elementor/assets/shapes/curve-negative.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2744","static_file","/wp-content/plugins/elementor/assets/shapes/curve.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2745","static_file","/wp-content/plugins/elementor/assets/shapes/drops-negative.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2746","static_file","/wp-content/plugins/elementor/assets/shapes/drops.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2747","static_file","/wp-content/plugins/elementor/assets/shapes/mountains.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2748","static_file","/wp-content/plugins/elementor/assets/shapes/opacity-fan.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2749","static_file","/wp-content/plugins/elementor/assets/shapes/opacity-tilt.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2750","static_file","/wp-content/plugins/elementor/assets/shapes/pyramids-negative.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2751","static_file","/wp-content/plugins/elementor/assets/shapes/pyramids.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2752","static_file","/wp-content/plugins/elementor/assets/shapes/split-negative.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2753","static_file","/wp-content/plugins/elementor/assets/shapes/split.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2754","static_file","/wp-content/plugins/elementor/assets/shapes/tilt.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2755","static_file","/wp-content/plugins/elementor/assets/shapes/triangle-asymmetrical-negative.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2756","static_file","/wp-content/plugins/elementor/assets/shapes/triangle-asymmetrical.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2757","static_file","/wp-content/plugins/elementor/assets/shapes/triangle-negative.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2758","static_file","/wp-content/plugins/elementor/assets/shapes/triangle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2759","static_file","/wp-content/plugins/elementor/assets/shapes/wave-brush.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2760","static_file","/wp-content/plugins/elementor/assets/shapes/waves-negative.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2761","static_file","/wp-content/plugins/elementor/assets/shapes/waves-pattern.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2762","static_file","/wp-content/plugins/elementor/assets/shapes/waves.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2763","static_file","/wp-content/plugins/elementor/assets/shapes/zigzag.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2764","static_file","/wp-content/plugins/elementor/assets/svg-paths/arc.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2765","static_file","/wp-content/plugins/elementor/assets/svg-paths/circle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2766","static_file","/wp-content/plugins/elementor/assets/svg-paths/line.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2767","static_file","/wp-content/plugins/elementor/assets/svg-paths/oval.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2768","static_file","/wp-content/plugins/elementor/assets/svg-paths/spiral.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2769","static_file","/wp-content/plugins/elementor/assets/svg-paths/wave.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2770","static_file","/wp-content/plugins/elementor/core/editor/loader/v1/js/editor-loader-v1.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2771","static_file","/wp-content/plugins/elementor/core/editor/loader/v2/js/editor-environment-v2.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2772","static_file","/wp-content/plugins/elementor/core/editor/loader/v2/js/editor-loader-v2.js","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:47","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2773","static_file","/wp-content/plugins/elementor/modules/apps/images/element-pack.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:48","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2774","static_file","/wp-content/plugins/elementor/modules/apps/images/unlimited-elements.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:48","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2775","static_file","/wp-content/plugins/elementor/modules/apps/images/activity-log.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:48","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2776","static_file","/wp-content/plugins/elementor/modules/apps/images/crocoblock.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:48","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2777","static_file","/wp-content/plugins/elementor/modules/apps/images/one-click-accessibility.png","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:48","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2778","static_file","/wp-content/plugins/elementor/modules/apps/images/elementor.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:48","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2779","static_file","/wp-content/plugins/elementor/modules/apps/images/essential-addons.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:48","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2780","static_file","/wp-content/plugins/elementor/modules/apps/images/fiverr.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:48","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2781","static_file","/wp-content/plugins/elementor/modules/apps/images/hover.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:48","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2782","static_file","/wp-content/plugins/elementor/modules/apps/images/uae.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:48","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2783","static_file","/wp-content/plugins/elementor/license.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-09-07 12:32:48","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2784","static_file","/wp-content/plugins/elementor/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-09-07 12:32:49","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2785","static_file","/wp-content/plugins/elementor/phpcs.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-09-07 12:32:49","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2786","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/tmp/bad_bots.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:23","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2787","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/tmp/cookie_ips.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:23","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2788","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/tmp/custom_rules.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:23","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2789","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/tmp/ips.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:23","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2790","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/tmp/phpids_log.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:23","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2791","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.AllowedClasses.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2792","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.AllowedFrameTargets.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2793","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.AllowedRel.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2794","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.AllowedRev.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2795","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.ClassUseCDATA.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2796","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.DefaultImageAlt.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2797","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.DefaultInvalidImage.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2798","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.DefaultInvalidImageAlt.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2799","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.DefaultTextDir.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2800","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.EnableID.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2801","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.ForbiddenClasses.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2802","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.IDBlacklist.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2803","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.IDBlacklistRegexp.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2804","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.IDPrefix.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2805","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.IDPrefixLocal.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2806","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Attr.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2807","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormat.AutoParagraph.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2808","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormat.Custom.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2809","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormat.DisplayLinkURI.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2810","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormat.Linkify.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2811","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormat.PurifierLinkify.DocURL.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2812","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormat.PurifierLinkify.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2813","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormat.RemoveEmpty.RemoveNbsp.Exceptions.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2814","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormat.RemoveEmpty.RemoveNbsp.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2815","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormat.RemoveEmpty.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2816","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormat.RemoveSpansWithoutAttributes.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2817","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormat.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2818","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormatParam.PurifierLinkifyDocURL.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2819","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/AutoFormatParam.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2820","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/CSS.AllowImportant.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2821","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/CSS.AllowTricky.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2822","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/CSS.AllowedFonts.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2823","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/CSS.AllowedProperties.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2824","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/CSS.DefinitionRev.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2825","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/CSS.ForbiddenProperties.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2826","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/CSS.MaxImgLength.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2827","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/CSS.Proprietary.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2828","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/CSS.Trusted.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2829","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/CSS.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2830","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Cache.DefinitionImpl.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2831","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Cache.SerializerPath.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2832","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Cache.SerializerPermissions.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2833","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Cache.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2834","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.AggressivelyFixLt.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2835","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.CollectErrors.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2836","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.ColorKeywords.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2837","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.ConvertDocumentToFragment.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2838","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.DirectLexLineNumberSyncInterval.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2839","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.Encoding.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2840","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.EscapeInvalidChildren.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2841","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.EscapeInvalidTags.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2842","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.EscapeNonASCIICharacters.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2843","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.HiddenElements.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2844","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.Language.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2845","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.LexerImpl.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2846","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.MaintainLineNumbers.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2847","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.NormalizeNewlines.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2848","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.RemoveInvalidImg.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2849","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.RemoveProcessingInstructions.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2850","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.RemoveScriptContents.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2851","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Core.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2852","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Filter.Custom.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2853","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Filter.ExtractStyleBlocks.Escaping.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2854","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Filter.ExtractStyleBlocks.Scope.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2855","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Filter.ExtractStyleBlocks.TidyImpl.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2856","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Filter.ExtractStyleBlocks.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2857","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Filter.YouTube.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2858","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Filter.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2859","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/FilterParam.ExtractStyleBlocksEscaping.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2860","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/FilterParam.ExtractStyleBlocksScope.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2861","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/FilterParam.ExtractStyleBlocksTidyImpl.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2862","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/FilterParam.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2863","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.Allowed.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2864","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.AllowedAttributes.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2865","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.AllowedElements.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2866","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.AllowedModules.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2867","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.Attr.Name.UseCDATA.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2868","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.BlockWrapper.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2869","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.CoreModules.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2870","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.CustomDoctype.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2871","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.DefinitionID.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2872","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.DefinitionRev.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2873","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.Doctype.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2874","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.FlashAllowFullScreen.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2875","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.ForbiddenAttributes.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2876","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.ForbiddenElements.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2877","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.MaxImgLength.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2878","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.Nofollow.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2879","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.Parent.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2880","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.Proprietary.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2881","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.SafeEmbed.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2882","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.SafeObject.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2883","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.Strict.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2884","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.TidyAdd.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2885","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.TidyLevel.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2886","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.TidyRemove.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2887","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.Trusted.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2888","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.XHTML.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2889","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/HTML.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2890","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Output.CommentScriptContents.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2891","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Output.FixInnerHTML.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2892","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Output.FlashCompat.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2893","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Output.Newline.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2894","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Output.SortAttr.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2895","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Output.TidyFormat.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2896","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Output.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2897","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Test.ForceNoIconv.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2898","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/Test.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2899","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.AllowedSchemes.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2900","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.Base.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2901","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.DefaultScheme.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2902","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.DefinitionID.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2903","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.DefinitionRev.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2904","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.Disable.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2905","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.DisableExternal.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2906","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.DisableExternalResources.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2907","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.DisableResources.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2908","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.Host.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2909","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.HostBlacklist.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2910","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.MakeAbsolute.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2911","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.Munge.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2912","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.MungeResources.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2913","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.MungeSecretKey.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2914","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.OverrideAllowedSchemes.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2915","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/ConfigSchema/schema/URI.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:21","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2916","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/Printer/ConfigForm.css","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:22","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2917","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/vendors/htmlpurifier/HTMLPurifier/Printer/ConfigForm.js","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:22","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2918","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-06-11 01:13:23","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2919","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/default_filter.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:23","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2920","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/IDS/default_filter_orig.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:23","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2921","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/var/cache/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2922","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/var/db/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2923","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/var/logs/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:43","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2924","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/container-interop/container-interop/docs/images/interoperating_containers.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2925","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/container-interop/container-interop/docs/images/priority.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2926","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/container-interop/container-interop/docs/images/side_by_side_containers.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:42","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2927","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/danielstjules/stringy/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-06-11 01:13:25","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2928","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/nikic/fast-route/phpunit.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:26","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2929","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/nikic/fast-route/psalm.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:26","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2930","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/respect/validation/tests/fixtures/valid-image.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:37","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2931","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/respect/validation/tests/fixtures/invalid-image.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2932","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/respect/validation/tests/fixtures/valid-image.png","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2933","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/respect/validation/tests/fixtures/valid-image.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:36","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2934","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/config/Tests/Fixtures/Again/foo.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:31","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2935","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/config/Tests/Fixtures/Util/document_type.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:31","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2936","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/config/Tests/Fixtures/Util/invalid.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:31","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2937","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/config/Tests/Fixtures/Util/invalid_schema.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:31","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2938","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/config/Tests/Fixtures/Util/valid.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:31","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2939","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/config/Tests/Fixtures/foo.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:31","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2940","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_0.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2941","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_1.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2942","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_10.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2943","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_11.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2944","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_12.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2945","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_13.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2946","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_14.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2947","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_15.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2948","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_16.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2949","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_17.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2950","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_2.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2951","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_3.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2952","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_4.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2953","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_5.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2954","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_6.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2955","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_7.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2956","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_8.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2957","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/Style/SymfonyStyle/output/output_9.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2958","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_1.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2959","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_2.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2960","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_astext1.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2961","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_astext2.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2962","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_asxml1.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2963","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_asxml2.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2964","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_gethelp.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2965","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_mbstring.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2966","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_renderexception1.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2967","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_renderexception2.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2968","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_renderexception3.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2969","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_renderexception3decorated.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2970","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_renderexception4.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2971","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_renderexception_doublewidth1.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2972","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_renderexception_doublewidth1decorated.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2973","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_renderexception_doublewidth2.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2974","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_renderexception_escapeslines.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2975","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_renderexception_linebreaks.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2976","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_run1.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2977","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_run2.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2978","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_run3.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2979","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/application_run4.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2980","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/command_1.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2981","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/command_2.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2982","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/command_astext.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2983","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/command_asxml.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2984","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/command_mbstring.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2985","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/definition_astext.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2986","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/definition_asxml.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2987","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_argument_1.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2988","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_argument_2.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2989","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_argument_3.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:34");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2990","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_argument_4.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2991","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_argument_with_default_inf_value.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2992","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_argument_with_style.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2993","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_definition_1.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2994","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_definition_2.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2995","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_definition_3.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2996","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_definition_4.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2997","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_1.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2998","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_2.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2999","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_3.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3000","static_file","/wp-content/plugins/getastra/astra/libraries/plugins/astra-gk/vendor/symfony/console/Tests/Fixtures/input_option_4.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-11 01:13:32","0000-00-00 00:00:00","2023-09-07 12:54:35");/*END*/