

DROP TABLE IF EXISTS `webtoffee_terms` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO `webtoffee_terms` VALUES
("1","Uncategorized","uncategorized","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("2","Landing","landing","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("3","Optin (Woo)","optin","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("4","Checkout (Woo)","checkout","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("5","Thank You (Woo)","thankyou","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("6","Upsell (Woo)","upsell","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("7","Downsell (Woo)","downsell","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("8","simple","simple","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("9","grouped","grouped","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("10","variable","variable","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("11","external","external","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("12","exclude-from-search","exclude-from-search","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("13","exclude-from-catalog","exclude-from-catalog","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("14","featured","featured","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("15","outofstock","outofstock","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("16","rated-1","rated-1","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("17","rated-2","rated-2","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("18","rated-3","rated-3","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("19","rated-4","rated-4","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("20","rated-5","rated-5","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("21","Uncategorized","uncategorized","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("22","flow-8","flow-8","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("23","Air purifying","air-purifying","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("24","Ceramic pots","ceramic-pots","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("25","Herbs seeds","herbs-seeds","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("26","Indoor Plants","indoor-plants","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("27","Large Plants","large-plants","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("28","Low maintenance","low-maintenance","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("29","Medium Plants","medium-plants","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("30","Plant accessories","plant-accessories","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("31","Plant bundle","plant-bundle","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("32","Small Plants","small-plants","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("33","Primary","primary","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("34","astra","astra","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("35","flow-1325","flow-1325","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("36","Information Gathering","information-gathering","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("37","Vulnerability Analysis","vulnerability-analysis","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("38","Exploitation Tools","exploitation-tools","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("39","Forensics Tools","forensics-tools","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("40","Wireless Attacks","wireless-attacks","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("41","Reverse Engineering","reverse-engineering","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("42","Social Engineering","social-engineering","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("43","flow-1601","flow-1601","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("44","Website Updates","website-updates","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("45","Blog Post","blog-post","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("46","Promotion","promotion","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("47","skyrocket your Instagram","skyrocket-your-instagram","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("48","Powerhouse of Influencer","powerhouse-of-influencer","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("49","skyrocket your Instagram","skyrocket-your-instagram","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("50","update_non_node_root_field","update_non_node_root_field","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("51","update_non_node_root_field","update_non_node_root_field","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("52","update_non_node_root_field","update_non_node_root_field","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("53","NON_NODE_ROOT_FIELDS","non_node_root_fields","0");/*END*/
INSERT INTO `webtoffee_terms` VALUES
("54","CONTENT","content","0");/*END*/