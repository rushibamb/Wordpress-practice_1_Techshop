

DROP TABLE IF EXISTS `webtoffee_wc_category_lookup` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wc_category_lookup` (
  `category_tree_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wc_category_lookup` VALUES
("21","21");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("23","23");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("24","24");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("25","25");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("26","26");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("27","27");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("28","28");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("29","29");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("30","30");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("31","31");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("32","32");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("36","36");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("37","37");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("38","38");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("39","39");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("40","40");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("41","41");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("42","42");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("47","47");/*END*/
INSERT INTO `webtoffee_wc_category_lookup` VALUES
("48","48");/*END*/