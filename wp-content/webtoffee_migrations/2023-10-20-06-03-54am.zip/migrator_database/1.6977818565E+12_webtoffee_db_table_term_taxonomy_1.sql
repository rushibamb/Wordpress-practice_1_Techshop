

DROP TABLE IF EXISTS `webtoffee_term_taxonomy` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO `webtoffee_term_taxonomy` VALUES
("1","1","category","","0","1");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("2","2","cartflows_step_type","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("3","3","cartflows_step_type","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("4","4","cartflows_step_type","","0","3");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("5","5","cartflows_step_type","","0","3");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("6","6","cartflows_step_type","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("7","7","cartflows_step_type","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("8","8","product_type","","0","9");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("9","9","product_type","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("10","10","product_type","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("11","11","product_type","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("12","12","product_visibility","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("13","13","product_visibility","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("14","14","product_visibility","","0","1");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("15","15","product_visibility","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("16","16","product_visibility","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("17","17","product_visibility","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("18","18","product_visibility","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("19","19","product_visibility","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("20","20","product_visibility","","0","2");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("21","21","product_cat","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("22","22","cartflows_step_flow","","0","2");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("23","23","product_cat","Quisque nulla egestas integer mauris, vestibulum mattis fames lobortis sed sollicitudin suscipit lobortis magna suspendisse fames","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("24","24","product_cat","Quisque nulla egestas integer mauris, vestibulum mattis fames lobortis sed sollicitudin suscipit lobortis magna suspendisse fames","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("25","25","product_cat","Quisque nulla egestas integer mauris, vestibulum mattis fames lobortis sed sollicitudin suscipit lobortis magna suspendisse fames","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("26","26","product_cat","Quisque nulla egestas integer mauris, vestibulum mattis fames lobortis sed sollicitudin suscipit lobortis magna suspendisse fames","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("27","27","product_cat","Quisque nulla egestas integer mauris, vestibulum mattis fames lobortis sed sollicitudin suscipit lobortis magna suspendisse fames","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("28","28","product_cat","Quisque nulla egestas integer mauris, vestibulum mattis fames lobortis sed sollicitudin suscipit lobortis magna suspendisse fames","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("29","29","product_cat","Quisque nulla egestas integer mauris, vestibulum mattis fames lobortis sed sollicitudin suscipit lobortis magna suspendisse fames","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("30","30","product_cat","Quisque nulla egestas integer mauris, vestibulum mattis fames lobortis sed sollicitudin suscipit lobortis magna suspendisse fames","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("31","31","product_cat","Quisque nulla egestas integer mauris, vestibulum mattis fames lobortis sed sollicitudin suscipit lobortis magna suspendisse fames","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("32","32","product_cat","Quisque nulla egestas integer mauris, vestibulum mattis fames lobortis sed sollicitudin suscipit lobortis magna suspendisse fames","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("33","33","nav_menu","","0","3");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("37","37","product_cat","","0","2");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("36","36","product_cat","","0","3");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("34","34","wp_theme","","0","1");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("35","35","cartflows_step_flow","","0","2");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("38","38","product_cat","","0","2");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("39","39","product_cat","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("40","40","product_cat","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("41","41","product_cat","","0","1");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("42","42","product_cat","","0","1");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("43","43","cartflows_step_flow","","0","2");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("44","44","monsterinsights_note_category","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("45","45","monsterinsights_note_category","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("46","46","monsterinsights_note_category","","0","0");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("47","47","product_cat","","0","6");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("48","48","product_cat","","0","6");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("49","49","product_tag","","0","1");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("50","50","gatsby_action_ref_node_dbid","","0","1");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("51","51","gatsby_action_ref_node_type","","0","1");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("52","52","gatsby_action_ref_node_id","","0","1");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("53","53","gatsby_action_type","","0","1");/*END*/
INSERT INTO `webtoffee_term_taxonomy` VALUES
("54","54","gatsby_action_stream_type","","0","1");/*END*/