
INSERT INTO `webtoffee_urls` VALUES
("5001","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/sparql/sparql.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5002","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/spreadsheet/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5003","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/spreadsheet/spreadsheet.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5004","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/sql/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5005","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/sql/sql.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5006","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/stex/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5007","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/stex/stex.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5008","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/stex/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5009","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/stylus/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5010","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/stylus/stylus.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5011","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/swift/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5012","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/swift/swift.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5013","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/tcl/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5014","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/tcl/tcl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5015","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/textile/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5016","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/textile/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5017","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/textile/textile.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5018","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/tiddlywiki/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5019","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/tiddlywiki/tiddlywiki.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5020","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/tiddlywiki/tiddlywiki.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5021","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/tiki/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5022","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/tiki/tiki.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5023","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/tiki/tiki.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5024","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/toml/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5025","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/toml/toml.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5026","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/tornado/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5027","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/tornado/tornado.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5028","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/troff/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5029","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/troff/troff.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5030","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ttcn-cfg/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5031","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ttcn-cfg/ttcn-cfg.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5032","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ttcn/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5033","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/ttcn/ttcn.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5034","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/turtle/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5035","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/turtle/turtle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5036","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/twig/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5037","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/twig/twig.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5038","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/vb/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5039","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/vb/vb.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5040","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/vbscript/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5041","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/vbscript/vbscript.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5042","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/velocity/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5043","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/velocity/velocity.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5044","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/verilog/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5045","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/verilog/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5046","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/verilog/verilog.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5047","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/vhdl/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5048","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/vhdl/vhdl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5049","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/vue/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5050","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/vue/vue.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5051","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/webidl/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5052","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/webidl/webidl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5053","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/xml/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5054","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/xml/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5055","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/xml/xml.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5056","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/xquery/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5057","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/xquery/test.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5058","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/xquery/xquery.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5059","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/yacas/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5060","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/yacas/yacas.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5061","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/yaml-frontmatter/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5062","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/yaml-frontmatter/yaml-frontmatter.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5063","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/yaml/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5064","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/yaml/yaml.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5065","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/z80/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5066","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/z80/z80.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5067","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/index.html","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5068","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/mode/meta.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:29","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5069","static_file","/wp-content/plugins/wp-file-manager/lib/codemirror/theme/3024-day.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5070","static_file","/wp-content/plugins/wp-file-manager/lib/css/commands.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5071","static_file","/wp-content/plugins/wp-file-manager/lib/css/common.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5072","static_file","/wp-content/plugins/wp-file-manager/lib/css/contextmenu.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5073","static_file","/wp-content/plugins/wp-file-manager/lib/css/cwd.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5074","static_file","/wp-content/plugins/wp-file-manager/lib/css/dialog.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5075","static_file","/wp-content/plugins/wp-file-manager/lib/css/elfinder.full.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5076","static_file","/wp-content/plugins/wp-file-manager/lib/css/elfinder.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5077","static_file","/wp-content/plugins/wp-file-manager/lib/css/fonts.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5078","static_file","/wp-content/plugins/wp-file-manager/lib/css/navbar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5079","static_file","/wp-content/plugins/wp-file-manager/lib/css/places.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5080","static_file","/wp-content/plugins/wp-file-manager/lib/css/quicklook.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5081","static_file","/wp-content/plugins/wp-file-manager/lib/css/statusbar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5082","static_file","/wp-content/plugins/wp-file-manager/lib/css/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5083","static_file","/wp-content/plugins/wp-file-manager/lib/css/toast.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5084","static_file","/wp-content/plugins/wp-file-manager/lib/css/toolbar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5085","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/notosans/stylesheet.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5086","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/notosans/NotoSans-Regular.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5087","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/notosans/NotoSans-Regular.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5088","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/notosans/NotoSans-Regular.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5089","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/notosans/NotoSans-Regular.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:30","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5090","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/raleway/stylesheet.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5091","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/raleway/Raleway-Bold.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5092","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/raleway/Raleway-Regular.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5093","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/raleway/Raleway-Bold.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5094","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/raleway/Raleway-Regular.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5095","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/raleway/Raleway-Bold.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5096","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/raleway/Raleway-Regular.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5097","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/raleway/Raleway-Bold.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5098","static_file","/wp-content/plugins/wp-file-manager/lib/fonts/raleway/Raleway-Regular.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5099","static_file","/wp-content/plugins/wp-file-manager/lib/img/src/icons-big.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5100","static_file","/wp-content/plugins/wp-file-manager/lib/img/crop.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5101","static_file","/wp-content/plugins/wp-file-manager/lib/img/progress.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5102","static_file","/wp-content/plugins/wp-file-manager/lib/img/spinner-mini-bk.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5103","static_file","/wp-content/plugins/wp-file-manager/lib/img/spinner-mini.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5104","static_file","/wp-content/plugins/wp-file-manager/lib/img/arrows-active.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5105","static_file","/wp-content/plugins/wp-file-manager/lib/img/arrows-normal.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5106","static_file","/wp-content/plugins/wp-file-manager/lib/img/black-close.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5107","static_file","/wp-content/plugins/wp-file-manager/lib/img/black-search.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5108","static_file","/wp-content/plugins/wp-file-manager/lib/img/dialogs.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5109","static_file","/wp-content/plugins/wp-file-manager/lib/img/edit_aceeditor.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5110","static_file","/wp-content/plugins/wp-file-manager/lib/img/edit_ckeditor.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5111","static_file","/wp-content/plugins/wp-file-manager/lib/img/edit_ckeditor5.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5112","static_file","/wp-content/plugins/wp-file-manager/lib/img/edit_codemirror.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5113","static_file","/wp-content/plugins/wp-file-manager/lib/img/edit_creativecloud.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5114","static_file","/wp-content/plugins/wp-file-manager/lib/img/edit_onlineconvert.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5115","static_file","/wp-content/plugins/wp-file-manager/lib/img/edit_pixlreditor.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5116","static_file","/wp-content/plugins/wp-file-manager/lib/img/edit_pixlrexpress.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5117","static_file","/wp-content/plugins/wp-file-manager/lib/img/edit_simplemde.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5118","static_file","/wp-content/plugins/wp-file-manager/lib/img/edit_tinymce.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5119","static_file","/wp-content/plugins/wp-file-manager/lib/img/edit_tuiimgedit.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5120","static_file","/wp-content/plugins/wp-file-manager/lib/img/edit_zohooffice.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5121","static_file","/wp-content/plugins/wp-file-manager/lib/img/editor-icons.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5122","static_file","/wp-content/plugins/wp-file-manager/lib/img/fm_close_icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5123","static_file","/wp-content/plugins/wp-file-manager/lib/img/icons-big.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5124","static_file","/wp-content/plugins/wp-file-manager/lib/img/icons-small.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5125","static_file","/wp-content/plugins/wp-file-manager/lib/img/logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5126","static_file","/wp-content/plugins/wp-file-manager/lib/img/quicklook-bg.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5127","static_file","/wp-content/plugins/wp-file-manager/lib/img/quicklook-icons.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5128","static_file","/wp-content/plugins/wp-file-manager/lib/img/resize.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5129","static_file","/wp-content/plugins/wp-file-manager/lib/img/toolbar.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5130","static_file","/wp-content/plugins/wp-file-manager/lib/img/trashmesh.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5131","static_file","/wp-content/plugins/wp-file-manager/lib/img/ui-icons_ffffff_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5132","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_box.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5133","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_dropbox.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5134","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_ftp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5135","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_googledrive.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5136","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_local.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5137","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_network.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5138","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_onedrive.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5139","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_sql.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5140","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_trash.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5141","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_zip.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5142","static_file","/wp-content/plugins/wp-file-manager/lib/img/win_10_sprite_icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5143","static_file","/wp-content/plugins/wp-file-manager/lib/img/icons-big.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:31","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5144","static_file","/wp-content/plugins/wp-file-manager/lib/img/tui-icon-a.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5145","static_file","/wp-content/plugins/wp-file-manager/lib/img/tui-icon-b.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5146","static_file","/wp-content/plugins/wp-file-manager/lib/img/tui-icon-c.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5147","static_file","/wp-content/plugins/wp-file-manager/lib/img/tui-icon-d.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5148","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_box.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5149","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_dropbox.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5150","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_ftp.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5151","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_googledrive.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5152","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_local.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5153","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_network.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5154","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_onedrive.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5155","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_sql.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5156","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_trash.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5157","static_file","/wp-content/plugins/wp-file-manager/lib/img/volume_icon_zip.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5158","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/images/ui-bg_glass_55_fbf9ee_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5159","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/images/ui-bg_glass_65_ffffff_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5160","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/images/ui-bg_glass_75_dadada_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5161","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/images/ui-bg_glass_75_e6e6e6_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5162","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/images/ui-bg_glass_95_fef1ec_1x400.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5163","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/images/ui-bg_highlight-soft_75_cccccc_1x100.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5164","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/images/ui-icons_222222_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5165","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/images/ui-icons_2e83ff_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5166","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/images/ui-icons_454545_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5167","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/images/ui-icons_888888_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5168","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/images/ui-icons_cd0a0a_256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5169","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/jquery-ui-1.11.4.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5170","static_file","/wp-content/plugins/wp-file-manager/lib/jquery/jquery-ui-1.12.1.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5171","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/archive.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5172","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/back.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5173","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/chmod.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5174","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/colwidth.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5175","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/copy.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5176","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/cut.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5177","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/download.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5178","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/duplicate.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5179","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5180","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/empty.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5181","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/extract.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5182","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/forward.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5183","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/fullscreen.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5184","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/getfile.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5185","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/help.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5186","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/hidden.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5187","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/hide.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5188","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/home.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5189","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/info.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5190","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/mkdir.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5191","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/mkfile.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5192","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/netmount.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5193","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/open.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5194","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/opendir.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:32","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5195","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/opennew.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5196","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/paste.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5197","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/places.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5198","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/preference.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5199","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/quicklook.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5200","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/quicklook.plugins.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5201","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/reload.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5202","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/rename.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5203","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/resize.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5204","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/restore.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5205","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/rm.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5206","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/search.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5207","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/selectall.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5208","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/selectinvert.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5209","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/selectnone.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5210","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/sort.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5211","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/undo.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5212","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/up.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5213","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/upload.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5214","static_file","/wp-content/plugins/wp-file-manager/lib/js/commands/view.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5215","static_file","/wp-content/plugins/wp-file-manager/lib/js/extras/editors.default.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5216","static_file","/wp-content/plugins/wp-file-manager/lib/js/extras/editors.default.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5217","static_file","/wp-content/plugins/wp-file-manager/lib/js/extras/encoding-japanese.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5218","static_file","/wp-content/plugins/wp-file-manager/lib/js/extras/quicklook.googledocs.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5219","static_file","/wp-content/plugins/wp-file-manager/lib/js/extras/quicklook.googledocs.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5220","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/help/cs.html.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5221","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/help/de.html.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5222","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/help/en.html.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5223","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/help/es.html.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5224","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/help/ja.html.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5225","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/help/ko.html.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5226","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/help/pl.html.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5227","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/help/ru.html.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5228","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/help/sk.html.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5229","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/help/tr.html.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5230","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.LANG.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5231","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.ar.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5232","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.bg.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5233","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.ca.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5234","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.cs.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5235","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.da.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5236","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.de.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5237","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.el.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5238","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.en.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5239","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.es.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5240","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.fa.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5241","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.fallback.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5242","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.fo.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5243","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.fr.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5244","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.fr_CA.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5245","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.he.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5246","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.hr.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5247","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.hu.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5248","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.id.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5249","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.it.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5250","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.ja.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5251","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.ko.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5252","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.nl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5253","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.no.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5254","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.pl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5255","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.pt_BR.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5256","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.ro.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5257","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.ru.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5258","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.si.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5259","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.sk.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5260","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.sl.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5261","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.sr.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5262","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.sv.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5263","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.tr.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5264","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.ug_CN.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5265","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.uk.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5266","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.vi.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5267","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.zh_CN.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5268","static_file","/wp-content/plugins/wp-file-manager/lib/js/i18n/elfinder.zh_TW.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5269","static_file","/wp-content/plugins/wp-file-manager/lib/js/proxy/elFinderSupportVer1.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5270","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/button.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5271","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/contextmenu.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5272","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/cwd.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5273","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/dialog.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5274","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/fullscreenbutton.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5275","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/navbar.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5276","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/navdock.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5277","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/overlay.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5278","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/panel.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5279","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/path.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5280","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/places.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5281","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/searchbutton.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5282","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/sortbutton.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5283","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/stat.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5284","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/toast.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5285","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/toolbar.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5286","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/tree.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5287","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/uploadButton.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5288","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/viewbutton.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5289","static_file","/wp-content/plugins/wp-file-manager/lib/js/ui/workzone.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5290","static_file","/wp-content/plugins/wp-file-manager/lib/js/worker/calcfilehash.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5291","static_file","/wp-content/plugins/wp-file-manager/lib/js/worker/quicklook.tiff.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5292","static_file","/wp-content/plugins/wp-file-manager/lib/js/worker/quicklook.unzip.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5293","static_file","/wp-content/plugins/wp-file-manager/lib/js/elFinder.command.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5294","static_file","/wp-content/plugins/wp-file-manager/lib/js/elFinder.history.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5295","static_file","/wp-content/plugins/wp-file-manager/lib/js/elFinder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5296","static_file","/wp-content/plugins/wp-file-manager/lib/js/elFinder.mimetypes.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5297","static_file","/wp-content/plugins/wp-file-manager/lib/js/elFinder.options.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5298","static_file","/wp-content/plugins/wp-file-manager/lib/js/elFinder.options.netmount.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5299","static_file","/wp-content/plugins/wp-file-manager/lib/js/elFinder.resources.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5300","static_file","/wp-content/plugins/wp-file-manager/lib/js/elFinder.version.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5301","static_file","/wp-content/plugins/wp-file-manager/lib/js/elfinder.full.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:33","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5302","static_file","/wp-content/plugins/wp-file-manager/lib/js/elfinder.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5303","static_file","/wp-content/plugins/wp-file-manager/lib/js/jquery.dialogelfinder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5304","static_file","/wp-content/plugins/wp-file-manager/lib/js/jquery.elfinder.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:34","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5305","static_file","/wp-content/plugins/wp-file-manager/lib/php/plugins/Watermark/logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5306","static_file","/wp-content/plugins/wp-file-manager/lib/php/resources/image.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5307","static_file","/wp-content/plugins/wp-file-manager/lib/php/resources/video.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5308","static_file","/wp-content/plugins/wp-file-manager/lib/themes/dark/css/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5309","static_file","/wp-content/plugins/wp-file-manager/lib/themes/dark/css/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5310","static_file","/wp-content/plugins/wp-file-manager/lib/themes/dark/icons/material.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5311","static_file","/wp-content/plugins/wp-file-manager/lib/themes/dark/icons/material.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5312","static_file","/wp-content/plugins/wp-file-manager/lib/themes/dark/icons/material.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5313","static_file","/wp-content/plugins/wp-file-manager/lib/themes/dark/icons/material.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5314","static_file","/wp-content/plugins/wp-file-manager/lib/themes/dark/icons/material.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5315","static_file","/wp-content/plugins/wp-file-manager/lib/themes/dark/images/hide.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5316","static_file","/wp-content/plugins/wp-file-manager/lib/themes/dark/images/icon-new-window.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5317","static_file","/wp-content/plugins/wp-file-manager/lib/themes/dark/images/icons-big.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5318","static_file","/wp-content/plugins/wp-file-manager/lib/themes/dark/images/icons-small.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5319","static_file","/wp-content/plugins/wp-file-manager/lib/themes/dark/images/loading.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5320","static_file","/wp-content/plugins/wp-file-manager/lib/themes/gray/css/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5321","static_file","/wp-content/plugins/wp-file-manager/lib/themes/gray/css/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5322","static_file","/wp-content/plugins/wp-file-manager/lib/themes/gray/icons/material.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5323","static_file","/wp-content/plugins/wp-file-manager/lib/themes/gray/icons/material.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5324","static_file","/wp-content/plugins/wp-file-manager/lib/themes/gray/icons/material.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5325","static_file","/wp-content/plugins/wp-file-manager/lib/themes/gray/icons/material.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5326","static_file","/wp-content/plugins/wp-file-manager/lib/themes/gray/icons/material.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5327","static_file","/wp-content/plugins/wp-file-manager/lib/themes/gray/images/hide.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5328","static_file","/wp-content/plugins/wp-file-manager/lib/themes/gray/images/icon-new-window.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5329","static_file","/wp-content/plugins/wp-file-manager/lib/themes/gray/images/icons-big.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5330","static_file","/wp-content/plugins/wp-file-manager/lib/themes/gray/images/icons-small.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5331","static_file","/wp-content/plugins/wp-file-manager/lib/themes/gray/images/loading.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5332","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/css/contextmenu.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5333","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/css/dialog.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5334","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/css/icons.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5335","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/css/main.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5336","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/css/navbar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5337","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/css/reset.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5338","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/css/statusbar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5339","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/css/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5340","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/css/toolbar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5341","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/css/view-list.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5342","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/css/view-thumbnail.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5343","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/archive.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5344","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/arrow_down.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5345","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/arrow_right.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5346","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/back.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5347","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/clear_folder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5348","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/copy.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5349","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/cut.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5350","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/deselect_all.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5351","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/directory.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5352","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/directory_opened.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5353","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/download.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5354","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/duplicate.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5355","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/edit.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5356","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/extract.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5357","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/file.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5358","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/forward.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5359","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/fullscreen.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5360","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/getfile.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5361","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/help.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5362","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/home.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5363","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/info.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5364","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/invert_selection.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5365","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/netmount.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5366","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/open.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5367","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/paste.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5368","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/preview.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5369","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/redo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5370","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/reload.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5371","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/rename.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5372","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/resize.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5373","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/rm.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5374","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/search.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5375","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/select_all.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5376","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/sort.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5377","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/undo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5378","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/up.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5379","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/upload.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5380","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/view-list.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5381","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/view.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5382","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/add_file.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5383","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/add_folder.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5384","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/archive.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5385","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/arrow_down.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5386","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/arrow_right.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5387","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/back.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5388","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/clear_folder.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5389","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/copy.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5390","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/cut.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5391","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/deselect_all.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5392","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/directory.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5393","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/directory_opened.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5394","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/download.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5395","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/duplicate.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5396","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/edit.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5397","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/extract.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5398","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/file.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5399","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/forward.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5400","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/fullscreen.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5401","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/getfile.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5402","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/help.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5403","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/html_file.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5404","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/info.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5405","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/invert_selection.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5406","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/netmount.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5407","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/open.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5408","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/paste.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5409","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/pdf.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5410","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/php_file.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5411","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/preview.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5412","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/redo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5413","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/rename.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5414","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/resize.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5415","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/rm.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5416","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/search-default.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5417","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/search.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5418","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/select_all.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5419","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/sort.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5420","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/text_file.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5421","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/undo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5422","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/up.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5423","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/upload.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5424","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/view-list.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5425","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/16px/view.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5426","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/48px/directory.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5427","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/48px/directory.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5428","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/48px/html_file.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5429","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/48px/pdf.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5430","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/48px/php_file.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5431","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/48px/text_file.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5432","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/close-hover.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5433","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/close.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5434","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/icons-small_new.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5435","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/search-default.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5436","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/selectshape.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5437","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/toolbar-lokhal.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5438","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/ui-icons_default_theme256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5439","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/win_10_sprite_icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5440","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/directory_opened.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5441","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/search-default.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5442","static_file","/wp-content/plugins/wp-file-manager/lib/themes/light/images/upload.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5443","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/css/contextmenu.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5444","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/css/dialog.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5445","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/css/icons.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5446","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/css/main.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5447","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/css/navbar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5448","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/css/reset.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5449","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/css/statusbar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5450","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/css/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5451","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/css/toolbar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5452","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/css/view-list.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5453","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/css/view-thumbnail.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5454","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/archive.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5455","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/arrow_down.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5456","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/arrow_right.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5457","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/back.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5458","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/clear_folder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5459","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/copy.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5460","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/cut.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5461","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/deselect_all.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5462","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/directory.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5463","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/directory_opened.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5464","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/download.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5465","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/duplicate.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5466","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/edit.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5467","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/extract.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5468","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/file.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5469","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/forward.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5470","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/full-screen-icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5471","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/getfile.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5472","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/help.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5473","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/info.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5474","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/invert_selection.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5475","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/netmount.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5476","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/open.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5477","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/paste.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5478","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/preview.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5479","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/redo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5480","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/rename.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5481","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/resize.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5482","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/rm.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5483","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/search.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5484","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/select_all.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5485","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/sort.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5486","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/undo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5487","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/up.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5488","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/upload.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5489","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/view-list.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5490","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/16px/view.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5491","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/48px/directory.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5492","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/close-hover.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5493","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/close.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5494","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/ui-icons_default_theme256x240.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5495","static_file","/wp-content/plugins/wp-file-manager/lib/themes/windows - 10/images/win_10_sprite_icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5496","static_file","/wp-content/plugins/wp-file-manager/lib/main.default.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:14:35","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5497","static_file","/wp-content/plugins/wp-file-manager/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-24 06:14:36","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5498","static_file","/wp-content/plugins/wp-mail-smtp/assets/css/emails/summary-report-email.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5499","static_file","/wp-content/plugins/wp-mail-smtp/assets/css/vendor/flatpickr.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5500","static_file","/wp-content/plugins/wp-mail-smtp/assets/css/vendor/jquery-confirm.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5501","static_file","/wp-content/plugins/wp-mail-smtp/assets/css/vendor/lity.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5502","static_file","/wp-content/plugins/wp-mail-smtp/assets/css/admin-bar.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5503","static_file","/wp-content/plugins/wp-mail-smtp/assets/css/admin-notifications.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5504","static_file","/wp-content/plugins/wp-mail-smtp/assets/css/admin-site-health.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5505","static_file","/wp-content/plugins/wp-mail-smtp/assets/css/dashboard-widget.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5506","static_file","/wp-content/plugins/wp-mail-smtp/assets/css/smtp-about.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5507","static_file","/wp-content/plugins/wp-mail-smtp/assets/css/smtp-admin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5508","static_file","/wp-content/plugins/wp-mail-smtp/assets/css/smtp-smart-routing.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5509","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/affiliatewp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5510","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/duplicator-icon-large.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5511","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/edd.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5512","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-aioseo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5513","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-charitable.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5514","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-mi.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5515","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-om.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5516","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-pushengage.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5517","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-rp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:39");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5518","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-seedprod.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5519","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-smash-balloon-facebook-feeds.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5520","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-smash-balloon-instagram-feeds.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5521","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-smash-balloon-twitter-feeds.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5522","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-smash-balloon-youtube-feeds.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5523","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-trustpulse.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5524","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-wpcode.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5525","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/plugin-wpf.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5526","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/searchwp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5527","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/sugar-calendar.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5528","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/wp-simple-pay.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5529","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/team.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5530","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/icon-full.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5531","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/icon-none.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5532","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/about/icon-partial.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5533","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/additional-connections/screenshot-01.png","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5534","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/additional-connections/screenshot-02.png","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5535","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/additional-connections/thumbnail-01.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5536","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/additional-connections/thumbnail-02.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5537","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/dash-widget/smtp/delivered.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5538","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/dash-widget/smtp/sent.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5539","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/dash-widget/smtp/total.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5540","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/dash-widget/smtp/unsent.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5541","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/dash-widget/wp/delivered.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5542","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/dash-widget/wp/sent.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5543","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/dash-widget/wp/total.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5544","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/dash-widget/wp/unsent.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5545","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/dash-widget/error-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5546","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/dash-widget/yes-green.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5547","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/email-reports/screenshot-01.png","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5548","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/email-reports/screenshot-02.png","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5549","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/email-reports/screenshot-03.png","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5550","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/email-reports/thumbnail-01.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5551","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/email-reports/thumbnail-02.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5552","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/email-reports/thumbnail-03.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5553","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/email/icon-check.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5554","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/email/signature.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5555","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/email/wp-mail-smtp-whitelabel.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5556","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/email/wp-mail-smtp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5557","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/email/illustration-success.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5558","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/flyout-menu/facebook.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5559","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/flyout-menu/life-ring.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5560","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/flyout-menu/lightbulb.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5561","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/flyout-menu/mascot.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5562","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/flyout-menu/star.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5563","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/font-awesome/check-circle-solid-green.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5564","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/font-awesome/exclamation-circle-regular-red.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5565","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/font-awesome/exclamation-circle-solid-orange.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5566","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/font-awesome/exclamation-circle-solid-red.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5567","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/font-awesome/info-circle-blue.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5568","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/icons/dashicons/dashicons-pdf-grey.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5569","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/icons/dashicons/dashicons-yes-alt-green.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5570","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/icons/arrow-up.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5571","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/icons/check-solid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5572","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/icons/error.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5573","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/icons/exclamation-circle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5574","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/icons/lightbulb.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5575","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/icons/success.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5576","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/icons/warning.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5577","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/icons/zoom.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5578","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/loaders/loading-blue.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5579","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/loaders/loading-white.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5580","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/loaders/loading.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5581","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/logs/archive-thumbnail.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5582","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/logs/archive.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5583","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/logs/single-thumbnail.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5584","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/logs/single.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5585","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/pepipost-smtp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5586","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/pepipost.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5587","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/aws.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5588","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/brevo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5589","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/google.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5590","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/mailgun.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5591","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/microsoft.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5592","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/php.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5593","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/postmark.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5594","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/sendgrid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5595","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/sendlayer.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5596","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/smtp-com.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5597","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/smtp.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5598","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/sparkpost.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5599","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/providers/zoho.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5600","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/email/icon-arrow-down.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5601","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/email/icon-arrow-up.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5602","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/email/icon-check-gray.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5603","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/email/icon-check.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5604","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/email/icon-click.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5605","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/email/icon-email.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5606","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/email/icon-error.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5607","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/email/icon-open.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5608","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/email/wp-mail-smtp-logo-dark-whitelabel.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5609","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/email/wp-mail-smtp-logo-dark.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5610","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/email/wp-mail-smtp-logo-whitelabel.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5611","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/email/wp-mail-smtp-logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5612","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/reports/icon-note.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5613","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/wp-spinner.gif","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5614","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/logo-whitelabel.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5615","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5616","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/menu-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5617","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/pattie.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5618","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/pro-badge-small.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5619","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/pro-badge.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5620","static_file","/wp-content/plugins/wp-mail-smtp/assets/images/recommended.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5621","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/vendor/chart.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5622","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/vendor/flatpickr.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5623","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/vendor/jquery-confirm.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5624","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/vendor/jquery.matchHeight.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5625","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/vendor/jquery.matchHeight.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5626","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/vendor/lity.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5627","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/vendor/moment.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5628","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/connect.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5629","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/connect.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5630","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/smtp-about.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5631","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/smtp-about.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5632","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/smtp-admin.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5633","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/smtp-admin.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5634","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/smtp-dashboard-widget.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5635","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/smtp-dashboard-widget.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5636","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/smtp-notifications.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5637","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/smtp-notifications.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5638","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/smtp-tools-debug-events.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5639","static_file","/wp-content/plugins/wp-mail-smtp/assets/js/smtp-tools-debug-events.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5640","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/css/wizard.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5641","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/css/wizard.rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5642","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/amazonses.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5643","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/arrow.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5644","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/brevo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5645","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/check-circle-solid-white.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5646","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/check-circle-solid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5647","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/check-solid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5648","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/chevron-down-solid-grey.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5649","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/copy-solid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5650","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/exclamation-circle-solid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5651","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/gmail.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5652","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/info-circle-solid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5653","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/loading-blue.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5654","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/loading-pattie.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5655","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/loading-white.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5656","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/loading.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5657","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/lock-solid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5658","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5659","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/long-arrow-alt-left-regular-grey.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5660","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/long-arrow-alt-left-regular.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5661","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/long-arrow-alt-right-regular-white.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5662","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/long-arrow-alt-right-regular.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5663","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/mailgun.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5664","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/outlook.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5665","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/postmark.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5666","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/pro-badge.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5667","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/question-circle-solid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5668","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/sendgrid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5669","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/sendlayer.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5670","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/smtp.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5671","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/smtpcom.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5672","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/sparkpost.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5673","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/star-solid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5674","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/thumbs-down-hover.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5675","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/thumbs-down.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5676","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/thumbs-up-hover.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5677","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/thumbs-up.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5678","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/times-solid-grey.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5679","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/times-solid.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5680","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/working.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5681","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/img/zoho.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:17","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5682","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/js/chunk-vendors.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:18","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5683","static_file","/wp-content/plugins/wp-mail-smtp/assets/vue/js/wizard.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-31 02:27:18","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5684","static_file","/wp-content/plugins/wp-mail-smtp/vendor/woocommerce/action-scheduler/changelog.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:20","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5685","static_file","/wp-content/plugins/wp-mail-smtp/vendor/woocommerce/action-scheduler/license.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:20","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5686","static_file","/wp-content/plugins/wp-mail-smtp/vendor/woocommerce/action-scheduler/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:20","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5687","static_file","/wp-content/plugins/wp-mail-smtp/vendor_prefixed/paragonie/constant_time_encoding/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:20","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5688","static_file","/wp-content/plugins/wp-mail-smtp/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-31 02:27:18","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5689","static_file","/wp-content/plugins/wp-whatsapp-chat/assets/backend/img/box1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5690","static_file","/wp-content/plugins/wp-whatsapp-chat/assets/backend/img/box2.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5691","static_file","/wp-content/plugins/wp-whatsapp-chat/assets/backend/img/icon.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5692","static_file","/wp-content/plugins/wp-whatsapp-chat/assets/backend/img/logo.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5693","static_file","/wp-content/plugins/wp-whatsapp-chat/assets/backend/img/quadlayers.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5694","static_file","/wp-content/plugins/wp-whatsapp-chat/assets/select2/css/select2.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5695","static_file","/wp-content/plugins/wp-whatsapp-chat/assets/select2/js/select2.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5696","static_file","/wp-content/plugins/wp-whatsapp-chat/build/backend/css/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5697","static_file","/wp-content/plugins/wp-whatsapp-chat/build/backend/js/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5698","static_file","/wp-content/plugins/wp-whatsapp-chat/build/frontend/css/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5699","static_file","/wp-content/plugins/wp-whatsapp-chat/build/frontend/js/index.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5700","static_file","/wp-content/plugins/wp-whatsapp-chat/jetpack_vendor/automattic/jetpack-assets/build/i18n-loader.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5701","static_file","/wp-content/plugins/wp-whatsapp-chat/jetpack_vendor/automattic/jetpack-assets/src/js/i18n-loader.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5702","static_file","/wp-content/plugins/wp-whatsapp-chat/jetpack_vendor/automattic/jetpack-assets/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5703","static_file","/wp-content/plugins/wp-whatsapp-chat/jetpack_vendor/automattic/jetpack-constants/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5704","static_file","/wp-content/plugins/wp-whatsapp-chat/jetpack_vendor/quadlayers/wp-plugin-suggestions/assets/img/logo.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5705","static_file","/wp-content/plugins/wp-whatsapp-chat/vendor/automattic/jetpack-composer-plugin/LICENSE.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5706","static_file","/wp-content/plugins/wp-whatsapp-chat/readme.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5707","static_file","/wp-content/plugins/wp-whatsapp-chat/wpml-config.xml","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:13:28","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5708","static_file","/wp-content/plugins/wpforms-lite/assets/css/admin/admin-form-templates.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:55","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5709","static_file","/wp-content/plugins/wpforms-lite/assets/css/admin/admin-form-templates.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:55","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5710","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-alerts.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5711","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-alerts.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5712","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-basic.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5713","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-basic.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5714","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-fields-types.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5715","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-fields-types.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5716","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-fields.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5717","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-fields.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5718","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-ms-win.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5719","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-ms-win.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5720","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-overlay.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5721","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-overlay.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5722","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-panels.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5723","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-panels.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5724","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-subsystems.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5725","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-subsystems.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:56","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5726","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-third-party.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5727","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-third-party.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5728","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-ui-general.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5729","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/builder-ui-general.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5730","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/content-editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5731","static_file","/wp-content/plugins/wpforms-lite/assets/css/builder/content-editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5732","static_file","/wp-content/plugins/wpforms-lite/assets/css/emails/partials/media_queries.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5733","static_file","/wp-content/plugins/wpforms-lite/assets/css/emails/partials/media_queries.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5734","static_file","/wp-content/plugins/wpforms-lite/assets/css/emails/general.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5735","static_file","/wp-content/plugins/wpforms-lite/assets/css/emails/general.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5736","static_file","/wp-content/plugins/wpforms-lite/assets/css/emails/summary.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5737","static_file","/wp-content/plugins/wpforms-lite/assets/css/emails/summary.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5738","static_file","/wp-content/plugins/wpforms-lite/assets/css/frontend/classic/wpforms-base.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5739","static_file","/wp-content/plugins/wpforms-lite/assets/css/frontend/classic/wpforms-base.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5740","static_file","/wp-content/plugins/wpforms-lite/assets/css/frontend/classic/wpforms-full.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:58","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5741","static_file","/wp-content/plugins/wpforms-lite/assets/css/frontend/classic/wpforms-full.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:58","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5742","static_file","/wp-content/plugins/wpforms-lite/assets/css/frontend/modern/wpforms-base.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:58","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5743","static_file","/wp-content/plugins/wpforms-lite/assets/css/frontend/modern/wpforms-base.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:58","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5744","static_file","/wp-content/plugins/wpforms-lite/assets/css/frontend/modern/wpforms-full.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:58","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5745","static_file","/wp-content/plugins/wpforms-lite/assets/css/frontend/modern/wpforms-full.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:58","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5746","static_file","/wp-content/plugins/wpforms-lite/assets/css/frontend/wpforms-dashicons.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:58","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5747","static_file","/wp-content/plugins/wpforms-lite/assets/css/frontend/wpforms-dashicons.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:58","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5748","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/choices.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:58","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5749","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/choices.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:58","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5750","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/wpforms-base.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:59","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5751","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/wpforms-base.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:59","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5752","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/wpforms-classic-base.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:59","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5753","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/wpforms-classic-base.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:59","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5754","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/wpforms-classic-full.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:59","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5755","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/wpforms-classic-full.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:00","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5756","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/wpforms-full.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:00","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5757","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/wpforms-full.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:00","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5758","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/wpforms-modern-base.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:00","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5759","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/wpforms-modern-base.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:00","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5760","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/wpforms-modern-full.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:01","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5761","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/divi/wpforms-modern-full.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:01","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5762","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/stripe/admin-settings-stripe.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:01","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5763","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/stripe/admin-settings-stripe.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:01","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5764","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/stripe/builder-stripe.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:01","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5765","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/stripe/builder-stripe.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:01","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5766","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/stripe/wpforms-stripe.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:01","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5767","static_file","/wp-content/plugins/wpforms-lite/assets/css/integrations/stripe/wpforms-stripe.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:01","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5768","static_file","/wp-content/plugins/wpforms-lite/assets/css/admin-bar.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:55","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5769","static_file","/wp-content/plugins/wpforms-lite/assets/css/admin-bar.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:55","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5770","static_file","/wp-content/plugins/wpforms-lite/assets/css/admin-integrations.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:55","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5771","static_file","/wp-content/plugins/wpforms-lite/assets/css/admin-integrations.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:55","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5772","static_file","/wp-content/plugins/wpforms-lite/assets/css/admin-notifications.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:55","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5773","static_file","/wp-content/plugins/wpforms-lite/assets/css/admin-notifications.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:55","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5774","static_file","/wp-content/plugins/wpforms-lite/assets/css/admin-wp5.7-colors.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:55","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5775","static_file","/wp-content/plugins/wpforms-lite/assets/css/admin-wp5.7-colors.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:55","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5776","static_file","/wp-content/plugins/wpforms-lite/assets/css/admin.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:55","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5777","static_file","/wp-content/plugins/wpforms-lite/assets/css/admin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:55","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5778","static_file","/wp-content/plugins/wpforms-lite/assets/css/challenge.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5779","static_file","/wp-content/plugins/wpforms-lite/assets/css/challenge.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5780","static_file","/wp-content/plugins/wpforms-lite/assets/css/choices.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5781","static_file","/wp-content/plugins/wpforms-lite/assets/css/choices.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5782","static_file","/wp-content/plugins/wpforms-lite/assets/css/dashboard-widget.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5783","static_file","/wp-content/plugins/wpforms-lite/assets/css/dashboard-widget.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5784","static_file","/wp-content/plugins/wpforms-lite/assets/css/entry-print.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5785","static_file","/wp-content/plugins/wpforms-lite/assets/css/entry-print.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5786","static_file","/wp-content/plugins/wpforms-lite/assets/css/form-embed-wizard.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5787","static_file","/wp-content/plugins/wpforms-lite/assets/css/form-embed-wizard.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:32:57","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5788","static_file","/wp-content/plugins/wpforms-lite/assets/css/logger.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:01","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5789","static_file","/wp-content/plugins/wpforms-lite/assets/css/logger.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:01","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5790","static_file","/wp-content/plugins/wpforms-lite/assets/css/wpforms-base.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:01","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5791","static_file","/wp-content/plugins/wpforms-lite/assets/css/wpforms-base.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:01","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5792","static_file","/wp-content/plugins/wpforms-lite/assets/css/wpforms-full.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5793","static_file","/wp-content/plugins/wpforms-lite/assets/css/wpforms-full.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5794","static_file","/wp-content/plugins/wpforms-lite/assets/fonts/wpforms.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5795","static_file","/wp-content/plugins/wpforms-lite/assets/fonts/wpforms.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5796","static_file","/wp-content/plugins/wpforms-lite/assets/fonts/wpforms.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5797","static_file","/wp-content/plugins/wpforms-lite/assets/fonts/wpforms.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5798","static_file","/wp-content/plugins/wpforms-lite/assets/fonts/wpforms.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5799","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/complete-guide-to-wpforms-settings.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5800","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/how-choose-right-form-field.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5801","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/how-create-gdpr-compliant-forms.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5802","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/how-install-activate-wpforms-addons.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5803","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-affwp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5804","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-aioseo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5805","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-charitable.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5806","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-duplicator.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5807","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-edd.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5808","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-mi.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5809","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-om.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5810","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-pushengage.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5811","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-rp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5812","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-sb-fb.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5813","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-sb-instagram.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5814","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-sb-twitter.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5815","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-sb-youtube.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5816","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-searchwp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5817","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-seedprod.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5818","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-smtp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5819","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-sugarcalendar.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5820","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-trustpulse.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5821","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-wp-simple-pay.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5822","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/plugin-wpcode.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5823","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/team.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5824","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/icon-full.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5825","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/icon-none.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5826","static_file","/wp-content/plugins/wpforms-lite/assets/images/about/icon-partial.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5827","static_file","/wp-content/plugins/wpforms-lite/assets/images/admin-flyout-menu/sullie-active.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5828","static_file","/wp-content/plugins/wpforms-lite/assets/images/admin-flyout-menu/sullie-default.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5829","static_file","/wp-content/plugins/wpforms-lite/assets/images/analytics/wpforms-monsterinsights.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5830","static_file","/wp-content/plugins/wpforms-lite/assets/images/analytics/wpforms-monsterinsights@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5831","static_file","/wp-content/plugins/wpforms-lite/assets/images/analytics/screenshot-full.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5832","static_file","/wp-content/plugins/wpforms-lite/assets/images/analytics/screenshot-tnail.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5833","static_file","/wp-content/plugins/wpforms-lite/assets/images/analytics/arrow-right.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5834","static_file","/wp-content/plugins/wpforms-lite/assets/images/anti-spam/akismet.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5835","static_file","/wp-content/plugins/wpforms-lite/assets/images/anti-spam/cloudflare.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5836","static_file","/wp-content/plugins/wpforms-lite/assets/images/anti-spam/country-filter.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5837","static_file","/wp-content/plugins/wpforms-lite/assets/images/anti-spam/custom-captcha.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5838","static_file","/wp-content/plugins/wpforms-lite/assets/images/anti-spam/hcaptcha.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5839","static_file","/wp-content/plugins/wpforms-lite/assets/images/anti-spam/keyword-filter.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5840","static_file","/wp-content/plugins/wpforms-lite/assets/images/anti-spam/recaptcha.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5841","static_file","/wp-content/plugins/wpforms-lite/assets/images/builder/check-circle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5842","static_file","/wp-content/plugins/wpforms-lite/assets/images/builder/default-arrow.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5843","static_file","/wp-content/plugins/wpforms-lite/assets/images/builder/ie-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5844","static_file","/wp-content/plugins/wpforms-lite/assets/images/builder/illustration-marketing.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5845","static_file","/wp-content/plugins/wpforms-lite/assets/images/builder/illustration-payments.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5846","static_file","/wp-content/plugins/wpforms-lite/assets/images/builder/loading-avatar.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5847","static_file","/wp-content/plugins/wpforms-lite/assets/images/builder/loading-spinner.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5848","static_file","/wp-content/plugins/wpforms-lite/assets/images/builder/placeholder-200x125.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5849","static_file","/wp-content/plugins/wpforms-lite/assets/images/builder/toggle-tab-bg.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5850","static_file","/wp-content/plugins/wpforms-lite/assets/images/challenge/bar-bg.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5851","static_file","/wp-content/plugins/wpforms-lite/assets/images/challenge/getting-started.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5852","static_file","/wp-content/plugins/wpforms-lite/assets/images/challenge/party-popper.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5853","static_file","/wp-content/plugins/wpforms-lite/assets/images/challenge/popup-contact.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5854","static_file","/wp-content/plugins/wpforms-lite/assets/images/challenge/sullie-circle.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5855","static_file","/wp-content/plugins/wpforms-lite/assets/images/challenge/chevron-circle-down-regular.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5856","static_file","/wp-content/plugins/wpforms-lite/assets/images/challenge/confetti.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5857","static_file","/wp-content/plugins/wpforms-lite/assets/images/challenge/red-arrow.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5858","static_file","/wp-content/plugins/wpforms-lite/assets/images/challenge/times-circle-regular.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5859","static_file","/wp-content/plugins/wpforms-lite/assets/images/community/dev-docs.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5860","static_file","/wp-content/plugins/wpforms-lite/assets/images/community/dev-docs@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5861","static_file","/wp-content/plugins/wpforms-lite/assets/images/community/suggest.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5862","static_file","/wp-content/plugins/wpforms-lite/assets/images/community/suggest@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5863","static_file","/wp-content/plugins/wpforms-lite/assets/images/community/vip-circle.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5864","static_file","/wp-content/plugins/wpforms-lite/assets/images/community/vip-circle@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5865","static_file","/wp-content/plugins/wpforms-lite/assets/images/community/wpbeginner.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5866","static_file","/wp-content/plugins/wpforms-lite/assets/images/community/wpbeginner@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5867","static_file","/wp-content/plugins/wpforms-lite/assets/images/community/youtube.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5868","static_file","/wp-content/plugins/wpforms-lite/assets/images/community/youtube@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5869","static_file","/wp-content/plugins/wpforms-lite/assets/images/constant-contact/cc-about-logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5870","static_file","/wp-content/plugins/wpforms-lite/assets/images/constant-contact/cc-about-logo@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5871","static_file","/wp-content/plugins/wpforms-lite/assets/images/constant-contact/cc-about-step1.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5872","static_file","/wp-content/plugins/wpforms-lite/assets/images/constant-contact/cc-about-step2.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5873","static_file","/wp-content/plugins/wpforms-lite/assets/images/constant-contact/cc-about-step3.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5874","static_file","/wp-content/plugins/wpforms-lite/assets/images/constant-contact/cc-about-step4.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5875","static_file","/wp-content/plugins/wpforms-lite/assets/images/coupons-education/coupons-addon-screenshot-01.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5876","static_file","/wp-content/plugins/wpforms-lite/assets/images/coupons-education/coupons-addon-screenshot-02.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5877","static_file","/wp-content/plugins/wpforms-lite/assets/images/coupons-education/coupons-addon-thumbnail-01.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5878","static_file","/wp-content/plugins/wpforms-lite/assets/images/coupons-education/coupons-addon-thumbnail-02.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5879","static_file","/wp-content/plugins/wpforms-lite/assets/images/empty-states/payments/get-started-lite.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5880","static_file","/wp-content/plugins/wpforms-lite/assets/images/empty-states/payments/get-started-pro.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5881","static_file","/wp-content/plugins/wpforms-lite/assets/images/empty-states/payments/no-payments.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5882","static_file","/wp-content/plugins/wpforms-lite/assets/images/empty-states/waving-hand-emoji.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5883","static_file","/wp-content/plugins/wpforms-lite/assets/images/empty-states/no-entries.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5884","static_file","/wp-content/plugins/wpforms-lite/assets/images/empty-states/no-fields.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5885","static_file","/wp-content/plugins/wpforms-lite/assets/images/empty-states/no-form-elementor.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5886","static_file","/wp-content/plugins/wpforms-lite/assets/images/empty-states/no-forms.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5887","static_file","/wp-content/plugins/wpforms-lite/assets/images/geolocation-education/address-autocomplete.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5888","static_file","/wp-content/plugins/wpforms-lite/assets/images/geolocation-education/address-autocomplete@2x.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5889","static_file","/wp-content/plugins/wpforms-lite/assets/images/geolocation-education/entry-location.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5890","static_file","/wp-content/plugins/wpforms-lite/assets/images/geolocation-education/entry-location@2x.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5891","static_file","/wp-content/plugins/wpforms-lite/assets/images/geolocation-education/smart-address-field.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5892","static_file","/wp-content/plugins/wpforms-lite/assets/images/geolocation-education/smart-address-field@2x.jpg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5893","static_file","/wp-content/plugins/wpforms-lite/assets/images/integrations/divi/wpforms-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5894","static_file","/wp-content/plugins/wpforms-lite/assets/images/integrations/elementor/font/icon-wpforms.ttf","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5895","static_file","/wp-content/plugins/wpforms-lite/assets/images/integrations/elementor/font/icon-wpforms.woff","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5896","static_file","/wp-content/plugins/wpforms-lite/assets/images/integrations/elementor/font/icon-wpforms.woff2","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5897","static_file","/wp-content/plugins/wpforms-lite/assets/images/integrations/elementor/font/icon-wpforms.eot","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5898","static_file","/wp-content/plugins/wpforms-lite/assets/images/integrations/elementor/font/icon-wpforms.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5899","static_file","/wp-content/plugins/wpforms-lite/assets/images/integrations/elementor/wpforms-icon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5900","static_file","/wp-content/plugins/wpforms-lite/assets/images/integrations/elementor/wpforms-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5901","static_file","/wp-content/plugins/wpforms-lite/assets/images/integrations/gutenberg/block-preview.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5902","static_file","/wp-content/plugins/wpforms-lite/assets/images/integrations/stripe/cc-preview.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5903","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-connect/raised-hand.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5904","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-connect/check-circle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5905","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-connect/cloud.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5906","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-connect/envelope.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5907","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-connect/info-circle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5908","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-connect/lock-alt.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5909","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-connect/wait.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5910","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/screenshot-access-controls.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:05","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5911","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/screenshot-access-controls@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:05","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5912","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/screenshot-members.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:05","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5913","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/screenshot-members@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:05","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5914","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/screenshot-user-role-editor.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:05","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5915","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/screenshot-user-role-editor@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:05","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5916","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/thumbnail-access-controls.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:05","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5917","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/thumbnail-access-controls@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:05","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5918","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/thumbnail-members.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:05","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5919","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/thumbnail-members@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:05","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5920","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/thumbnail-user-role-editor.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5921","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/thumbnail-user-role-editor@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:05","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5922","static_file","/wp-content/plugins/wpforms-lite/assets/images/lite-settings-access/pro-plus.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5923","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/single/icon-coupon.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5924","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/single/icon-cycle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5925","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/single/icon-date.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5926","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/single/icon-lifetime-total.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5927","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/single/icon-method.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5928","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/single/icon-one-time.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5929","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/single/icon-subscription.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5930","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/single/icon-total.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5931","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/single/info-circle.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5932","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/status/icon-active.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5933","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/status/icon-cancelled.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5934","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/status/icon-completed.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5935","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/status/icon-failed.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5936","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/status/icon-n-a.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5937","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/status/icon-not-synced.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5938","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/status/icon-pending.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5939","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/status/icon-processed.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5940","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/status/icon-refunded.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5941","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/chevron.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5942","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/icon-exclamation.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5943","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/icon-total-coupons.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5944","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/icon-total-payments.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5945","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/icon-total-sales.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5946","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/icon-total-subscription.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5947","static_file","/wp-content/plugins/wpforms-lite/assets/images/payments/star.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5948","static_file","/wp-content/plugins/wpforms-lite/assets/images/smtp/screenshot-full.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5949","static_file","/wp-content/plugins/wpforms-lite/assets/images/smtp/screenshot-tnail.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5950","static_file","/wp-content/plugins/wpforms-lite/assets/images/smtp/wpforms-wpmailsmtp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5951","static_file","/wp-content/plugins/wpforms-lite/assets/images/smtp/wpforms-wpmailsmtp@2x.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5952","static_file","/wp-content/plugins/wpforms-lite/assets/images/smtp/arrow-right.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5953","static_file","/wp-content/plugins/wpforms-lite/assets/images/smtp/pattie-2.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5954","static_file","/wp-content/plugins/wpforms-lite/assets/images/smtp/pattie.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5955","static_file","/wp-content/plugins/wpforms-lite/assets/images/stripe/stripe-connect.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5956","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-activecampaign.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5957","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-authorize-net.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5958","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-aweber.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5959","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-campaign-monitor.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5960","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-captcha.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5961","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-conditional-logic.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5962","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-constant-contact.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5963","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-conversational-forms.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5964","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-coupons.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5965","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-drip.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5966","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-form-abandonment.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5967","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-form-locker.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5968","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-form-pages.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5969","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-form-templates-pack.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5970","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-geolocation.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5971","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-getresponse.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5972","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-google-sheets.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5973","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-hubspot.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5974","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-lead-forms.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5975","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-mailchimp.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5976","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-mailerlite.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5977","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-offline-forms.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5978","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-paypal-commerce.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5979","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-paypal-standard.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5980","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-post-submissions.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5981","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-salesforce.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5982","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-save-resume.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5983","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-sendinblue.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5984","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-signatures.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5985","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-square.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5986","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-stripe.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5987","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-surveys-polls.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5988","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-user-journey.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5989","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-user-registration.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5990","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-webhooks.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5991","static_file","/wp-content/plugins/wpforms-lite/assets/images/addon-icon-zapier.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:02","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5992","static_file","/wp-content/plugins/wpforms-lite/assets/images/builder-default-arrow.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:03","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5993","static_file","/wp-content/plugins/wpforms-lite/assets/images/icon-chart-smaller.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5994","static_file","/wp-content/plugins/wpforms-lite/assets/images/icon-chart.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5995","static_file","/wp-content/plugins/wpforms-lite/assets/images/icon-graph.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5996","static_file","/wp-content/plugins/wpforms-lite/assets/images/icon-provider-constant-contact.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5997","static_file","/wp-content/plugins/wpforms-lite/assets/images/icon-provider-uncanny-automator.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5998","static_file","/wp-content/plugins/wpforms-lite/assets/images/jquery.minicolors.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:04","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5999","static_file","/wp-content/plugins/wpforms-lite/assets/images/logo.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6000","static_file","/wp-content/plugins/wpforms-lite/assets/images/recaptcha-placeholder.png","","","0","1","1","","0000-00-00 00:00:00","","2023-08-15 05:33:06","0000-00-00 00:00:00","2023-09-07 12:54:40");/*END*/