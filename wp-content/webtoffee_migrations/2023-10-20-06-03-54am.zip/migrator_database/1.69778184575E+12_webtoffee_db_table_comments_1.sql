

DROP TABLE IF EXISTS `webtoffee_comments` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=MyISAM AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO `webtoffee_comments` VALUES
("1","1","A Commenter","admin@aryanvbw.tech","http://aryanshop.me","","2023-04-28 07:02:26","2023-04-28 07:02:26","Hi, this is a comment.
To get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.
Commenter avatars come from <a href=\"https://en.gravatar.com/\" rel=\"nofollow ugc\">Gravatar</a>.","0","1","","comment","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("70","1665","WooCommerce","woocommerce@aryanshop.me","","","2023-06-25 16:57:36","2023-06-25 16:57:36","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("69","1662","vivek","AryanVW@proton.me","","","2023-06-25 04:38:11","2023-06-25 04:38:11","Order status changed from Processing to Cancelled.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("4","1","vivek","AryanVW@proton.me","http://aryanshop.me","223.233.82.37","2023-04-30 12:20:29","2023-04-30 12:20:29","fedfaeewfdaw","0","1","Mozilla/5.0 (X11; Linux i686; rv:102.0) Gecko/20100101 Firefox/102.0","comment","1","1");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("68","1663","vivek","AryanVW@proton.me","","","2023-06-25 04:37:19","2023-06-25 04:37:19","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("67","1664","WooCommerce","woocommerce@aryanshop.me","","","2023-06-25 04:25:11","2023-06-25 04:25:11","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("66","1647","WooCommerce","woocommerce@aryanshop.me","","","2023-06-25 04:24:06","2023-06-25 04:24:06","This order was abandoned & subsequently recovered.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("8","223","Vinayak Deshmane","devilthe925@gmail.com","","152.57.208.197","2023-05-02 13:56:43","2023-05-02 13:56:43","Easy to use, intuitive experience, no complicated onboarding is required, and no expertise is required to understand the dashboard; a rookie can take this up without too many hassles.","0","1","Mozilla/5.0 (Linux; Android 10; M2006C3LII) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36","review","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("65","1647","vivek","AryanVW@proton.me","","","2023-06-25 04:24:06","2023-06-25 04:24:06","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("64","1663","WooCommerce","woocommerce@aryanshop.me","","","2023-06-25 04:20:17","2023-06-25 04:20:17","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("62","1661","vivek","AryanVW@proton.me","","","2023-06-24 14:46:07","2023-06-24 14:46:07","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("63","1662","WooCommerce","woocommerce@aryanshop.me","","","2023-06-25 04:16:15","2023-06-25 04:16:15","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("59","1659","vivek","AryanVW@proton.me","","","2023-06-23 16:15:31","2023-06-23 16:15:31","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("60","1658","WooCommerce","woocommerce@aryanshop.me","","","2023-06-24 04:17:27","2023-06-24 04:17:27","Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("61","1661","WooCommerce","woocommerce@aryanshop.me","","","2023-06-24 14:43:53","2023-06-24 14:43:53","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("55","1659","WooCommerce","woocommerce@aryanshop.me","","","2023-06-23 15:20:13","2023-06-23 15:20:13","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("56","1660","WooCommerce","woocommerce@aryanshop.me","","","2023-06-23 15:22:34","2023-06-23 15:22:34","Awaiting UPI Payment!","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("57","1660","vivek","AryanVW@proton.me","","","2023-06-23 16:14:41","2023-06-23 16:14:41","Order status changed from Pending payment to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("58","1660","WooCommerce","woocommerce@aryanshop.me","","","2023-06-23 16:14:42","2023-06-23 16:14:42","This order was abandoned & subsequently recovered.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("52","1630","Sham gupta","sham2002@outloock.com","","223.233.84.78","2023-06-22 19:14:23","2023-06-22 19:14:23","Working best and just add like in 10 to 20 second and it\'s stable","0","1","Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36","review","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("53","1630","vivek","AryanVW@proton.me","http://aryanshop.me","223.233.84.78","2023-06-22 19:16:08","2023-06-22 19:16:08","Developer choice","0","1","Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36","review","0","1");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("54","1658","WooCommerce","woocommerce@aryanshop.me","","","2023-06-23 15:18:02","2023-06-23 15:18:02","Awaiting UPI Payment!","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("51","1657","WooCommerce","woocommerce@aryanshop.me","","","2023-06-22 18:23:29","2023-06-22 18:23:29","Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("48","1651","vivek","AryanVW@proton.me","","","2023-06-22 15:31:43","2023-06-22 15:31:43","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("49","1652","WooCommerce","woocommerce@aryanshop.me","","","2023-06-22 16:06:37","2023-06-22 16:06:37","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("50","1657","WooCommerce","woocommerce@aryanshop.me","","","2023-06-22 17:01:23","2023-06-22 17:01:23","Awaiting UPI Payment!","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("46","1645","WooCommerce","woocommerce@aryanshop.me","","","2023-06-22 11:01:26","2023-06-22 11:01:26","Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("47","1651","WooCommerce","woocommerce@aryanshop.me","","","2023-06-22 15:30:34","2023-06-22 15:30:34","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("45","1650","vivek","AryanVW@proton.me","","","2023-06-22 10:00:45","2023-06-22 10:00:45","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("42","1649","WooCommerce","woocommerce@aryanshop.me","","","2023-06-22 09:39:15","2023-06-22 09:39:15","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("43","1649","vivek","AryanVW@proton.me","","","2023-06-22 09:43:17","2023-06-22 09:43:17","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("44","1650","WooCommerce","woocommerce@aryanshop.me","","","2023-06-22 09:56:09","2023-06-22 09:56:09","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("37","1645","WooCommerce","woocommerce@aryanshop.me","","","2023-06-22 08:38:40","2023-06-22 08:38:40","Awaiting UPI Payment!","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("38","1646","WooCommerce","woocommerce@aryanshop.me","","","2023-06-22 09:08:46","2023-06-22 09:08:46","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("39","1646","vivek","AryanVW@proton.me","","","2023-06-22 09:10:19","2023-06-22 09:10:19","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("40","1647","WooCommerce","woocommerce@aryanshop.me","","","2023-06-22 09:16:13","2023-06-22 09:16:13","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("41","1648","WooCommerce","woocommerce@aryanshop.me","","","2023-06-22 09:21:21","2023-06-22 09:21:21","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("71","1665","vivek","AryanVW@proton.me","","","2023-06-25 17:01:04","2023-06-25 17:01:04","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("72","1664","vivek","AryanVW@proton.me","","","2023-06-27 12:06:19","2023-06-27 12:06:19","Order status changed from Processing to Cancelled.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("73","1667","WooCommerce","woocommerce@aryanshop.me","","","2023-06-27 15:10:15","2023-06-27 15:10:15","Awaiting UPI Payment!","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("74","1667","WooCommerce","woocommerce@aryanshop.me","","","2023-06-27 16:50:59","2023-06-27 16:50:59","Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("75","1670","WooCommerce","woocommerce@aryanshop.me","","","2023-06-28 03:05:28","2023-06-28 03:05:28","Awaiting UPI Payment!","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("76","1670","WooCommerce","woocommerce@aryanshop.me","","","2023-06-28 03:06:48","2023-06-28 03:06:48","Order status changed from Pending payment to On hold.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("77","1670","WooCommerce","woocommerce@aryanshop.me","","","2023-06-28 03:06:49","2023-06-28 03:06:49","Payment primarily completed. Needs shop owner\'s verification.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("78","1671","WooCommerce","woocommerce@aryanshop.me","","","2023-06-28 03:10:58","2023-06-28 03:10:58","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("79","1672","WooCommerce","woocommerce@aryanshop.me","","","2023-06-28 03:42:43","2023-06-28 03:42:43","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("80","1672","vivek","AryanVW@proton.me","","","2023-06-28 03:44:36","2023-06-28 03:44:36","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("81","1671","vivek","AryanVW@proton.me","","","2023-06-28 03:45:40","2023-06-28 03:45:40","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("82","1648","vivek","AryanVW@proton.me","","","2023-06-28 03:46:05","2023-06-28 03:46:05","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("83","1673","WooCommerce","woocommerce@aryanshop.me","","","2023-06-30 05:57:27","2023-06-30 05:57:27","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("84","1673","vivek","AryanVW@proton.me","","","2023-06-30 06:04:59","2023-06-30 06:04:59","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("85","1675","WooCommerce","woocommerce@aryanshop.me","","","2023-08-01 08:09:07","2023-08-01 08:09:07","Awaiting UPI Payment!","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("86","1676","WooCommerce","woocommerce@aryanshop.me","","","2023-08-01 08:09:57","2023-08-01 08:09:57","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("87","1675","WooCommerce","woocommerce@aryanshop.me","","","2023-08-05 08:39:25","2023-08-05 08:39:25","Unpaid order cancelled - time limit reached. Order status changed from Pending payment to Cancelled.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("88","1678","WooCommerce","woocommerce@aryanshop.me","","","2023-08-05 08:43:52","2023-08-05 08:43:52","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("89","1678","vivek","AryanVW@proton.me","","","2023-08-05 08:48:56","2023-08-05 08:48:56","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("90","1679","WooCommerce","woocommerce@aryanshop.me","","","2023-08-15 11:51:27","2023-08-15 11:51:27","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("91","1679","vivek","AryanVW@proton.me","","","2023-08-15 11:55:36","2023-08-15 11:55:36","Order status changed from Processing to Completed.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("92","1683","WooCommerce","woocommerce@aryanshop.me","","","2023-08-17 03:20:24","2023-08-17 03:20:24","Awaiting UPI Payment!","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("93","1684","WooCommerce","woocommerce@aryanshop.me","","","2023-08-26 10:39:46","2023-08-26 10:39:46","Order status changed from Pending payment to Processing.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("94","1684","WooCommerce","woocommerce@aryanshop.me","","","2023-08-26 10:39:47","2023-08-26 10:39:47","This order was abandoned & subsequently recovered.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("95","1712","WooCommerce","woocommerce@aryanshop.me","","","2023-10-19 20:33:19","2023-10-19 20:33:19","Awaiting UPI Payment!","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("96","1713","WooCommerce","woocommerce@aryanshop.me","","","2023-10-19 21:23:41","2023-10-19 21:23:41","Awaiting UPI Payment!","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("97","1713","WooCommerce","woocommerce@aryanshop.me","","","2023-10-19 21:24:30","2023-10-19 21:24:30","Order status changed from Pending payment to On hold.","0","1","WooCommerce","order_note","0","0");/*END*/
INSERT INTO `webtoffee_comments` VALUES
("98","1713","WooCommerce","woocommerce@aryanshop.me","","","2023-10-19 21:24:30","2023-10-19 21:24:30","Payment primarily completed. Needs shop owner\'s verification.","0","1","WooCommerce","order_note","0","0");/*END*/