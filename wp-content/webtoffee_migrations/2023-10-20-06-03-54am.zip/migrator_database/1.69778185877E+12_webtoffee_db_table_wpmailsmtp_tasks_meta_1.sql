

DROP TABLE IF EXISTS `webtoffee_wpmailsmtp_tasks_meta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wpmailsmtp_tasks_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wpmailsmtp_tasks_meta` VALUES
("17","wp_mail_smtp_admin_notifications_update","W10=","2023-08-15 11:53:07");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_tasks_meta` VALUES
("18","wp_mail_smtp_admin_notifications_update","W10=","2023-09-02 14:23:45");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_tasks_meta` VALUES
("19","wp_mail_smtp_admin_notifications_update","W10=","2023-09-04 15:54:50");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_tasks_meta` VALUES
("20","wp_mail_smtp_admin_notifications_update","W10=","2023-09-07 12:01:12");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_tasks_meta` VALUES
("21","wp_mail_smtp_admin_notifications_update","W10=","2023-10-02 13:57:42");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_tasks_meta` VALUES
("22","wp_mail_smtp_admin_notifications_update","W10=","2023-10-19 22:04:37");/*END*/
INSERT INTO `webtoffee_wpmailsmtp_tasks_meta` VALUES
("23","wp_mail_smtp_admin_notifications_update","W10=","2023-10-19 22:06:17");/*END*/