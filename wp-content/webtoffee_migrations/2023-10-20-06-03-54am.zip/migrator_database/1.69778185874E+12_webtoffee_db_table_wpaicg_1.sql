

DROP TABLE IF EXISTS `webtoffee_wpaicg` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_wpaicg` (
  `ID` mediumint(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `temperature` float NOT NULL,
  `max_tokens` float NOT NULL,
  `top_p` float NOT NULL,
  `best_of` float NOT NULL,
  `frequency_penalty` float NOT NULL,
  `presence_penalty` float NOT NULL,
  `img_size` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `api_key` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `wpai_language` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `wpai_add_img` tinyint(1) NOT NULL,
  `wpai_add_intro` tinyint(1) NOT NULL,
  `wpai_add_conclusion` tinyint(1) NOT NULL,
  `wpai_add_tagline` tinyint(1) NOT NULL,
  `wpai_add_faq` tinyint(1) NOT NULL,
  `wpai_add_keywords_bold` tinyint(1) NOT NULL,
  `wpai_number_of_heading` int(11) NOT NULL,
  `wpai_modify_headings` tinyint(1) NOT NULL,
  `wpai_heading_tag` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `wpai_writing_style` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `wpai_writing_tone` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `wpai_target_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `wpai_target_url_cta` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `wpai_cta_pos` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `added_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;/*END*/


INSERT INTO `webtoffee_wpaicg` VALUES
("1","wpaicg_settings","0.7","1500","0.01","1","0.01","0.01","512x512","sk..","en","0","0","0","0","0","0","3","0","h1","infor","formal","","","beg","2023-04-29 21:07:29","2023-04-29 21:07:29");/*END*/