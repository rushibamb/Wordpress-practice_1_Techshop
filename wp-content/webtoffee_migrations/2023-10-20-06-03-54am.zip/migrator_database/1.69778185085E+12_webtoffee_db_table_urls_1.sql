

DROP TABLE IF EXISTS `webtoffee_urls` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `unaux_34393270_944`
--




CREATE TABLE `webtoffee_urls` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other_page',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_id` bigint(20) unsigned DEFAULT NULL,
  `object_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `pages` bigint(20) unsigned NOT NULL DEFAULT 1,
  `enable` int(1) unsigned NOT NULL DEFAULT 1,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `file_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_statuscode` int(20) DEFAULT NULL,
  `last_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_upload` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `create_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `type` (`type`(250)),
  KEY `url` (`url`(250)),
  KEY `file_name` (`file_name`(250)),
  KEY `file_date` (`file_date`),
  KEY `last_upload` (`last_upload`)
) ENGINE=MyISAM AUTO_INCREMENT=7468 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO `webtoffee_urls` VALUES
("1","single","/","25","page","0","1","1","","0000-00-00 00:00:00","404","2023-06-21 15:53:51","2023-09-07 12:54:47","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("2","single","/removebackground/","5","attachment","0","1","1","","0000-00-00 00:00:00","404","2023-04-28 07:14:18","2023-09-07 12:54:47","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("3","single","/woocommerce-placeholder/","7","attachment","0","1","1","","0000-00-00 00:00:00","404","2023-04-28 07:18:34","2023-09-07 12:54:47","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("4","single","/woocommerce-placeholder-2/","18","attachment","0","1","1","","0000-00-00 00:00:00","404","2021-08-17 07:47:52","2023-09-07 12:54:47","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("5","single","/plants-store-new-plants-section-img-bg/","19","attachment","0","1","1","","0000-00-00 00:00:00","404","2021-08-17 08:12:12","2023-09-07 12:54:47","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("6","single","/quote-icon/","20","attachment","0","1","1","","0000-00-00 00:00:00","","2021-08-17 08:12:13","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("7","single","/site-logo/","21","attachment","0","1","1","","0000-00-00 00:00:00","","2021-08-17 08:12:15","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("8","single","/site-logo-white/","22","attachment","0","1","1","","0000-00-00 00:00:00","","2021-08-17 08:12:17","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("9","single","/home/plants-store-testimonial-avatar-img/","45","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("10","single","/home/plants-ecommerce-product-featured-img-1/","46","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("11","single","/home/plants-ecommerce-product-featured-img-2/","47","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("12","single","/home/plants-ecommerce-product-featured-img-3/","48","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("13","single","/home/plants-ecommerce-product-featured-img-4/","49","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("14","single","/home/plants-ecommerce-product-featured-img-5/","50","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("15","single","/home/plants-ecommerce-product-featured-img-6/","51","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("16","single","/home/plants-ecommerce-product-featured-img-7/","52","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("17","single","/home/plants-ecommerce-product-featured-img-8/","53","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("18","single","/home/plants-ecommerce-product-featured-img-9/","54","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("19","single","/home/plants-ecommerce-product-featured-img-10/","55","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("20","single","/home/plants-ecommerce-product-featured-img-11/","56","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("21","single","/home/plants-ecommerce-product-featured-img-12/","57","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("22","single","/home/plants-ecommerce-product-featured-img-13/","58","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("23","single","/home/plants-ecommerce-product-featured-img-14/","59","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("24","single","/home/plants-ecommerce-product-featured-img-15/","60","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("25","single","/home/plants-ecommerce-product-featured-img-16/","61","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("26","single","/home/plants-ecommerce-product-featured-img-17/","62","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("27","single","/home/plants-ecommerce-product-featured-img-18/","63","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("28","single","/home/plants-ecommerce-product-featured-img-19/","64","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("29","single","/home/plants-ecommerce-product-featured-img-20/","65","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("30","single","/home/plants-store-blog-featured-img-1/","66","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("31","single","/home/plants-store-blog-featured-img-2/","67","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("32","single","/home/plants-store-new-plants-section-img-bg-2/","70","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("33","single","/plants-store-about-video-img-thumb/","269","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("34","single","/plants-store-owner-avatar-img/","276","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("35","single","/group-107/","298","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("36","single","/plants-store-gallery-img-6/","305","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("37","single","/plants-store-gallery-img-1/","306","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("38","single","/plants-store-gallery-img-2/","307","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("39","single","/plants-store-gallery-img-3/","308","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("40","single","/plants-store-gallery-img-4/","309","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("41","single","/plants-store-gallery-img-5/","310","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("42","single","/home/plants-store-hero-img/","434","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("43","single","/site-favicon/","438","attachment","0","1","1","","0000-00-00 00:00:00","","2021-08-18 08:55:30","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("44","single","/cropped-site-favicon-png/","439","attachment","0","1","1","","0000-00-00 00:00:00","","2021-08-18 08:55:38","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("45","single","/home/plants-store-testimonials-avatar-img-2/","492","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("46","single","/home/plants-store-testimonials-avatar-img-1/","493","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("47","single","/home/plants-store-gift-card-section-img/","544","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("48","single","/home/plants-store-story-section-img/","548","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("49","single","/plants-shop-product-gallery-img-4/","632","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("50","single","/plants-shop-product-gallery-img-5/","633","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("51","single","/plants-shop-product-gallery-img-6/","634","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("52","single","/plants-shop-product-gallery-img-7/","635","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("53","single","/plants-shop-product-gallery-img-8/","636","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("54","single","/plants-shop-product-gallery-img-9/","637","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("55","single","/plants-shop-product-gallery-img-10/","638","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("56","single","/plants-shop-product-gallery-img-12/","640","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("57","single","/plants-shop-product-gallery-img-13/","641","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("58","single","/plants-shop-product-gallery-img-14/","642","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("59","single","/plants-shop-product-gallery-img-15/","643","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("60","single","/plants-shop-product-gallery-img-16/","644","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("61","single","/plants-shop-product-gallery-img-17/","645","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("62","single","/plants-shop-product-gallery-img-18/","646","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("63","single","/plants-shop-product-gallery-img-19/","647","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("64","single","/plants-shop-product-gallery-img-20/","648","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("65","single","/plants-shop-product-gallery-img-1/","649","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("66","single","/plants-shop-product-gallery-img-2/","650","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("67","single","/plants-shop-product-gallery-img-3/","651","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("68","single","/plants-shop-product-gallery-img-011/","652","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("69","single","/plants-ecommerce-accessories-product-featured-img-2/","684","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("70","single","/plants-ecommerce-accessories-product-featured-img-3/","685","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("71","single","/plants-ecommerce-accessories-product-featured-img-4/","686","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("72","single","/plants-ecommerce-accessories-product-featured-img-1/","687","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("73","single","/plants-ecommerce-accessories-product-featured-img-5/","699","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("74","single","/plants-store-categories-img-2/","741","attachment","0","1","1","","0000-00-00 00:00:00","","2021-08-20 10:04:20","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("75","single","/plants-store-categories-img-4/","742","attachment","0","1","1","","0000-00-00 00:00:00","","2021-08-20 10:04:41","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("76","single","/plants-store-categories-img-3/","743","attachment","0","1","1","","0000-00-00 00:00:00","","2021-08-20 10:04:58","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("77","single","/plants-store-categories-img-1/","744","attachment","0","1","1","","0000-00-00 00:00:00","","2021-08-20 10:05:14","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("78","single","/home/plants-store-hero-section-img-bg/","748","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("79","single","/footer-bg/","840","attachment","0","1","1","","0000-00-00 00:00:00","","2021-09-01 05:41:59","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("80","single","/footer-background/","841","attachment","0","1","1","","0000-00-00 00:00:00","","2021-09-01 05:46:01","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("81","single","/home/hero-section-bg/","845","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("82","single","/plant-shop-social-img/","996","attachment","0","1","1","","0000-00-00 00:00:00","","2021-09-21 08:12:14","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("83","single","/produuct-description-bg/","1172","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:20:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("84","single","/global-checkout-template-logo-svg/","1264","attachment","0","1","1","","0000-00-00 00:00:00","","2022-09-01 09:14:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("85","single","/modern-checkout-two-columns-template-avatar-jpg/","1265","attachment","0","1","1","","0000-00-00 00:00:00","","2022-09-01 09:14:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("86","single","/digital-marketing-guide-avatar-image-2-jpg/","1266","attachment","0","1","1","","0000-00-00 00:00:00","","2022-09-01 09:14:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("87","single","/modern-checkout-two-columns-template-guarantee-badge-png/","1267","attachment","0","1","1","","0000-00-00 00:00:00","","2022-09-01 09:14:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("88","single","/global-checkout-template-logo-svg-2/","1269","attachment","0","1","1","","0000-00-00 00:00:00","","2022-09-01 09:14:43","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("89","single","/modern-checkout-two-columns-template-avatar-jpg-2/","1270","attachment","0","1","1","","0000-00-00 00:00:00","","2022-09-01 09:14:43","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("90","single","/digital-marketing-guide-avatar-image-2-jpg-2/","1271","attachment","0","1","1","","0000-00-00 00:00:00","","2022-09-01 09:14:43","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("91","single","/modern-checkout-two-columns-template-guarantee-badge-png-2/","1272","attachment","0","1","1","","0000-00-00 00:00:00","","2022-09-01 09:14:44","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("92","single","/modern-checkout-two-columns-template-avatar-1-jpg/","1299","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:26:34","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("93","single","/digital-marketing-guide-avatar-image-2-1-jpg/","1300","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:26:34","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("94","single","/modern-checkout-two-columns-template-guarantee-badge-1-png/","1301","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:26:34","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("95","single","/produuct-description-bg-jpg/","1306","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:28:03","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("96","single","/group-107-jpg/","1310","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("97","single","/plants-store-owner-avatar-img-jpg/","1311","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("98","single","/plants-store-gallery-img-6-jpg/","1312","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("99","single","/plants-store-gallery-img-1-jpg/","1313","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("100","single","/plants-store-gallery-img-2-jpg/","1314","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("101","single","/plants-store-gallery-img-3-jpg/","1315","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("102","single","/plants-store-gallery-img-4-jpg/","1316","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("103","single","/plants-store-gallery-img-5-jpg/","1317","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:32:20","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("104","single","/hero-section-bg-jpg/","1319","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:10","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("105","single","/plants-store-story-section-img-jpg/","1320","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:11","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("106","single","/plants-store-testimonial-avatar-img-jpg/","1321","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:11","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("107","single","/plants-store-testimonials-avatar-img-2-jpg/","1322","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:12","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("108","single","/plants-store-testimonials-avatar-img-1-jpg/","1323","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:12","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("109","single","/footer-background-jpg/","1324","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:12","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("110","single","/removebackground-png/","1328","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:12","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("111","single","/modern-checkout-two-columns-template-guarantee-badge-png-3/","1329","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:13","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("112","single","/modern-checkout-two-columns-template-avatar-jpg-3/","1330","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:13","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("113","single","/removebackground-1-png/","1331","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:14","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("114","single","/modern-checkout-two-columns-template-guarantee-badge-png-4/","1332","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:14","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("115","single","/modern-checkout-two-columns-template-avatar-jpg-4/","1333","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:14","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("116","single","/global-checkout-template-logo-svg-3/","1334","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:14","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("117","single","/?attachment_id=1336/","1336","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 09:19:16","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("118","single","/?attachment_id=1350/","1350","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 09:58:57","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("119","single","/?attachment_id=1352/","1352","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 10:08:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("120","single","/?attachment_id=1355/","1355","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 11:44:53","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("121","single","/?attachment_id=1356/","1356","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 11:44:58","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("122","single","/?attachment_id=1357/","1357","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 11:45:03","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("123","single","/?attachment_id=1372/","1372","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 12:38:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("124","single","/?attachment_id=1373/","1373","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 12:38:50","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("125","single","/?attachment_id=1374/","1374","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 12:38:57","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("126","single","/?attachment_id=1375/","1375","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 12:39:04","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("127","single","/?attachment_id=1376/","1376","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 12:39:12","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("128","single","/?attachment_id=1377/","1377","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 12:39:17","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("129","single","/?attachment_id=1378/","1378","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 12:39:23","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("130","single","/?attachment_id=1387/","1387","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 15:31:01","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("131","single","/?attachment_id=1388/","1388","attachment","0","1","0","","0000-00-00 00:00:00","","2023-04-28 15:32:16","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("132","single","/cropped-removebackground-png/","1393","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 14:31:02","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("133","single","/home/attachment/42796435/","1414","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 17:13:26","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("134","single","/home/chuck_keith/","1419","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 17:16:33","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("135","single","/home/davidsir/","1423","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 17:19:25","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("136","single","/home/at-3/","1441","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 18:08:10","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("137","single","/home/alibaba-launches-11-qubit-quantum-computing-cloud-service/","1470","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 19:29:33","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("138","single","/home/kali-cubism-16x9/","1471","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 19:30:28","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("139","single","/home/premium-vector-circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic/","1472","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 19:32:30","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("140","single","/home/premium-vector-circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-2/","1473","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 19:32:34","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("141","single","/home/premium-vector-circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-3/","1489","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 19:50:23","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("142","single","/home/premium-vector-circuit-board-technology-background-with-hi-tech-digital-data-connection-system-and-computer-electronic-4/","1490","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 19:51:17","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("143","single","/home/web-300_fill/","1496","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 19:57:11","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("144","single","/home/l1/","1503","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 19:59:38","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("145","single","/home/pen-200_fill/","1504","attachment","0","1","1","","0000-00-00 00:00:00","","2023-04-29 19:59:57","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("146","single","/?attachment_id=1555/","1555","attachment","0","1","0","","0000-00-00 00:00:00","","2023-05-22 17:27:19","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("147","single","/home/quatam-comp/","1562","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:25:01","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("148","single","/home/alibaba-launches-11-qubit-quantum-computing-cloud-service-2/","1566","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-11 05:27:26","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("149","single","/home/icons8-instagram-48/","1574","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-11 06:45:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("150","single","/home/icons8-instagram-96/","1575","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-11 06:46:57","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("151","single","/home/icons8-instagram-240/","1576","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-11 06:51:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("152","single","/web3-crash-course-logo-svg/","1604","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:43","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("153","single","/web3-crash-course-hero-image-bg-jpg/","1605","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:44","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("154","single","/web3-crash-course-benefits-1-png/","1606","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:45","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("155","single","/web3-crash-course-benefits-2-png/","1607","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:46","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("156","single","/web3-crash-course-benefits-3-png/","1608","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:46","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("157","single","/web3-crash-course-instructor-jpg/","1609","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:47","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("158","single","/web3-crash-course-avatar-1-jpg/","1610","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:47","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("159","single","/web3-crash-course-avatar-4-jpg/","1611","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:48","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("160","single","/web3-crash-course-avatar-2-jpg/","1612","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:48","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("161","single","/web3-crash-course-avatar-5-jpg/","1613","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:49","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("162","single","/web3-crash-course-avatar-3-jpg/","1614","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:49","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("163","single","/web3-crash-course-avatar-6-jpg/","1615","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:50","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("164","single","/website-parts-social-media-2084779/","1633","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-21 15:38:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("165","single","/social-social-network-social-network-service-1206610/","1634","attachment","0","1","1","","0000-00-00 00:00:00","","2023-06-21 15:39:06","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("166","single","/step/store-checkout-04/","9","cartflows_step","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:26:45","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("167","single","/step/store-checkout-thank-you-04/","10","cartflows_step","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:27:34","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("168","single","/step/store-checkout-01/","1326","cartflows_step","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:08","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("169","single","/step/store-checkout-thank-you-01/","1327","cartflows_step","0","1","1","","0000-00-00 00:00:00","","2023-04-28 09:01:10","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("170","single","/step/web3-crash-course-checkout/","1602","cartflows_step","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:38","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("171","single","/step/web3-crash-course-thank-you/","1603","cartflows_step","0","1","1","","0000-00-00 00:00:00","","2023-06-12 16:08:40","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("172","single","/?elementor_library=default-kit/","6","elementor_library","0","1","0","","0000-00-00 00:00:00","","2023-04-28 07:17:20","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("173","single","/?elementor_library=default-kit-2/","1173","elementor_library","0","1","0","","0000-00-00 00:00:00","","2023-06-11 06:34:45","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("174","single","/sample-page/","2","page","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:02:26","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("175","single","/contact/","357","page","0","1","1","","0000-00-00 00:00:00","","2023-06-22 16:27:00","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("176","single","/shop/","1174","page","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:46:47","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("177","single","/cart/","1175","page","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:25:56","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("178","single","/checkout/","1176","page","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:26:01","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("179","single","/my-account/","1177","page","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:26:07","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("180","single","/myai-account/","1533","page","0","1","1","","0000-00-00 00:00:00","","2023-04-29 21:07:31","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("181","single","/2023/04/28/hello-world/","1","post","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:02:26","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("182","single","/product/andro/","208","product","0","1","1","","0000-00-00 00:00:00","","2023-04-30 08:58:25","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("183","single","/product/exif/","220","product","0","1","1","","0000-00-00 00:00:00","","2023-04-30 09:10:55","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("184","single","/product/beef-cloud_setup/","223","product","0","1","1","","0000-00-00 00:00:00","","2023-05-02 13:56:43","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("185","single","/product/5050-permanent-instagram-follower/","1554","product","0","1","1","","0000-00-00 00:00:00","","2023-08-16 06:35:16","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("186","single","/product/premium-instagram-followers/","1620","product","0","1","1","","0000-00-00 00:00:00","","2023-08-16 06:33:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("187","single","/product/instagram-likes-female-100/","1626","product","0","1","1","","0000-00-00 00:00:00","","2023-06-21 15:55:21","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("188","single","/product/instagram-indian-likes/","1630","product","0","1","1","","0000-00-00 00:00:00","","2023-09-02 12:17:28","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("189","single","/product/regular-instagram-followers-indian-%f0%9f%87%ae%f0%9f%87%b3/","1632","product","0","1","1","","0000-00-00 00:00:00","","2023-06-21 15:39:25","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("190","single","/product/instagram-reel-views-1000views/","1637","product","0","1","1","","0000-00-00 00:00:00","","2023-06-21 15:44:01","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("191","term_archive","/category/uncategorized/","1","category","0","1","1","","0000-00-00 00:00:00","","2023-04-28 07:02:26","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("192","term_archive","/product-category/exploitation-tools/","38","product_cat","0","1","1","","0000-00-00 00:00:00","","2023-05-02 13:56:43","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("193","term_archive","/product-category/information-gathering/","36","product_cat","0","1","1","","0000-00-00 00:00:00","","2023-05-02 13:56:43","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("194","term_archive","/product-category/powerhouse-of-influencer/","48","product_cat","0","1","1","","0000-00-00 00:00:00","","2023-09-02 12:17:28","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("195","term_archive","/product-category/reverse-engineering/","41","product_cat","0","1","1","","0000-00-00 00:00:00","","2023-04-30 08:58:25","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("196","term_archive","/product-category/skyrocket-your-instagram/","47","product_cat","0","1","1","","0000-00-00 00:00:00","","2023-09-02 12:17:28","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("197","term_archive","/product-category/social-engineering/","42","product_cat","0","1","1","","0000-00-00 00:00:00","","2023-05-02 13:56:43","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("198","term_archive","/product-category/vulnerability-analysis/","37","product_cat","0","1","1","","0000-00-00 00:00:00","","2023-05-02 13:56:43","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("199","term_archive","/product-tag/skyrocket-your-instagram/","49","product_tag","0","1","1","","0000-00-00 00:00:00","","2023-06-21 15:39:25","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("200","author_archive","/author/vivek/","1","","0","3","1","","0000-00-00 00:00:00","","2023-09-02 12:17:28","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("201","static_file","/index2.html","","","0","1","1","","0000-00-00 00:00:00","","2023-06-09 08:54:12","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("202","static_file","/readme.html","","","0","1","0","","0000-00-00 00:00:00","","2023-09-02 11:08:22","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("203","static_file","/dup-installer-bootlog__86ffff4-09204134.txt","","","0","1","1","","0000-00-00 00:00:00","","2023-06-10 08:02:25","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("204","static_file","/license.txt","","","0","1","0","","0000-00-00 00:00:00","","2023-08-24 06:12:00","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("205","static_file","/speed-kit-sw.js","","","0","1","1","","0000-00-00 00:00:00","","2023-06-17 05:38:35","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("206","static_file","/wp-admin/css/colors/blue/colors-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("207","static_file","/wp-admin/css/colors/blue/colors-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("208","static_file","/wp-admin/css/colors/blue/colors.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("209","static_file","/wp-admin/css/colors/blue/colors.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("210","static_file","/wp-admin/css/colors/coffee/colors-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("211","static_file","/wp-admin/css/colors/coffee/colors-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("212","static_file","/wp-admin/css/colors/coffee/colors.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("213","static_file","/wp-admin/css/colors/coffee/colors.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("214","static_file","/wp-admin/css/colors/ectoplasm/colors-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("215","static_file","/wp-admin/css/colors/ectoplasm/colors-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("216","static_file","/wp-admin/css/colors/ectoplasm/colors.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("217","static_file","/wp-admin/css/colors/ectoplasm/colors.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("218","static_file","/wp-admin/css/colors/light/colors-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("219","static_file","/wp-admin/css/colors/light/colors-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("220","static_file","/wp-admin/css/colors/light/colors.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("221","static_file","/wp-admin/css/colors/light/colors.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("222","static_file","/wp-admin/css/colors/midnight/colors-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("223","static_file","/wp-admin/css/colors/midnight/colors-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("224","static_file","/wp-admin/css/colors/midnight/colors.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("225","static_file","/wp-admin/css/colors/midnight/colors.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("226","static_file","/wp-admin/css/colors/modern/colors-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("227","static_file","/wp-admin/css/colors/modern/colors-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("228","static_file","/wp-admin/css/colors/modern/colors.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("229","static_file","/wp-admin/css/colors/modern/colors.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("230","static_file","/wp-admin/css/colors/ocean/colors-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("231","static_file","/wp-admin/css/colors/ocean/colors-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("232","static_file","/wp-admin/css/colors/ocean/colors.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("233","static_file","/wp-admin/css/colors/ocean/colors.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("234","static_file","/wp-admin/css/colors/sunrise/colors-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("235","static_file","/wp-admin/css/colors/sunrise/colors-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("236","static_file","/wp-admin/css/colors/sunrise/colors.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("237","static_file","/wp-admin/css/colors/sunrise/colors.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("238","static_file","/wp-admin/css/about-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("239","static_file","/wp-admin/css/about-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("240","static_file","/wp-admin/css/about.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:29");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("241","static_file","/wp-admin/css/about.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("242","static_file","/wp-admin/css/admin-menu-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2022-09-14 09:14:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("243","static_file","/wp-admin/css/admin-menu-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2022-09-14 09:14:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("244","static_file","/wp-admin/css/admin-menu.css","","","0","1","1","","0000-00-00 00:00:00","","2022-09-14 09:14:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("245","static_file","/wp-admin/css/admin-menu.min.css","","","0","1","1","","0000-00-00 00:00:00","","2022-09-14 09:14:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("246","static_file","/wp-admin/css/code-editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2021-01-26 06:55:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("247","static_file","/wp-admin/css/code-editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-01-26 06:55:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("248","static_file","/wp-admin/css/code-editor.css","","","0","1","1","","0000-00-00 00:00:00","","2021-01-26 06:55:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("249","static_file","/wp-admin/css/code-editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-01-26 06:55:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("250","static_file","/wp-admin/css/color-picker-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("251","static_file","/wp-admin/css/color-picker-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-03-24 04:41:08","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("252","static_file","/wp-admin/css/color-picker.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("253","static_file","/wp-admin/css/color-picker.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-03-24 04:41:08","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("254","static_file","/wp-admin/css/common-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("255","static_file","/wp-admin/css/common-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("256","static_file","/wp-admin/css/common.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("257","static_file","/wp-admin/css/common.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("258","static_file","/wp-admin/css/customize-controls-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-01-27 03:56:28","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("259","static_file","/wp-admin/css/customize-controls-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-01-27 03:56:28","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("260","static_file","/wp-admin/css/customize-controls.css","","","0","1","1","","0000-00-00 00:00:00","","2023-01-27 03:56:28","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("261","static_file","/wp-admin/css/customize-controls.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-01-27 03:56:28","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("262","static_file","/wp-admin/css/customize-nav-menus-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("263","static_file","/wp-admin/css/customize-nav-menus-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("264","static_file","/wp-admin/css/customize-nav-menus.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("265","static_file","/wp-admin/css/customize-nav-menus.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("266","static_file","/wp-admin/css/customize-widgets-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("267","static_file","/wp-admin/css/customize-widgets-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("268","static_file","/wp-admin/css/customize-widgets.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("269","static_file","/wp-admin/css/customize-widgets.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-09-02 10:18:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("270","static_file","/wp-admin/css/dashboard-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("271","static_file","/wp-admin/css/dashboard-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("272","static_file","/wp-admin/css/dashboard.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("273","static_file","/wp-admin/css/dashboard.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("274","static_file","/wp-admin/css/deprecated-media-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("275","static_file","/wp-admin/css/deprecated-media-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("276","static_file","/wp-admin/css/deprecated-media.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("277","static_file","/wp-admin/css/deprecated-media.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("278","static_file","/wp-admin/css/edit-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("279","static_file","/wp-admin/css/edit-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("280","static_file","/wp-admin/css/edit.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("281","static_file","/wp-admin/css/edit.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("282","static_file","/wp-admin/css/farbtastic-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2019-10-26 12:17:08","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("283","static_file","/wp-admin/css/farbtastic-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2019-09-23 04:21:58","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("284","static_file","/wp-admin/css/farbtastic.css","","","0","1","1","","0000-00-00 00:00:00","","2013-11-17 04:18:12","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("285","static_file","/wp-admin/css/farbtastic.min.css","","","0","1","1","","0000-00-00 00:00:00","","2017-08-19 08:10:48","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("286","static_file","/wp-admin/css/forms-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("287","static_file","/wp-admin/css/forms-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("288","static_file","/wp-admin/css/forms.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("289","static_file","/wp-admin/css/forms.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("290","static_file","/wp-admin/css/install-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("291","static_file","/wp-admin/css/install-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("292","static_file","/wp-admin/css/install.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("293","static_file","/wp-admin/css/install.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("294","static_file","/wp-admin/css/l10n-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2019-10-26 12:17:08","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("295","static_file","/wp-admin/css/l10n-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2019-09-23 04:21:58","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("296","static_file","/wp-admin/css/l10n.css","","","0","1","1","","0000-00-00 00:00:00","","2016-06-17 06:37:28","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("297","static_file","/wp-admin/css/l10n.min.css","","","0","1","1","","0000-00-00 00:00:00","","2018-12-11 04:13:26","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("298","static_file","/wp-admin/css/list-tables-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("299","static_file","/wp-admin/css/list-tables-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("300","static_file","/wp-admin/css/list-tables.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("301","static_file","/wp-admin/css/list-tables.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("302","static_file","/wp-admin/css/login-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("303","static_file","/wp-admin/css/login-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("304","static_file","/wp-admin/css/login.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("305","static_file","/wp-admin/css/login.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("306","static_file","/wp-admin/css/media-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("307","static_file","/wp-admin/css/media-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("308","static_file","/wp-admin/css/media.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("309","static_file","/wp-admin/css/media.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("310","static_file","/wp-admin/css/nav-menus-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-01-20 10:06:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("311","static_file","/wp-admin/css/nav-menus-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-01-20 10:06:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("312","static_file","/wp-admin/css/nav-menus.css","","","0","1","1","","0000-00-00 00:00:00","","2023-01-20 10:06:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("313","static_file","/wp-admin/css/nav-menus.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-01-20 10:06:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("314","static_file","/wp-admin/css/revisions-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("315","static_file","/wp-admin/css/revisions-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("316","static_file","/wp-admin/css/revisions.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("317","static_file","/wp-admin/css/revisions.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("318","static_file","/wp-admin/css/site-health-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 09:51:12","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("319","static_file","/wp-admin/css/site-health-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 09:51:12","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("320","static_file","/wp-admin/css/site-health.css","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 09:51:12","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("321","static_file","/wp-admin/css/site-health.min.css","","","0","1","1","","0000-00-00 00:00:00","","2022-09-19 09:51:12","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("322","static_file","/wp-admin/css/site-icon-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2019-10-26 12:17:08","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("323","static_file","/wp-admin/css/site-icon-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2019-09-23 04:21:58","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("324","static_file","/wp-admin/css/site-icon.css","","","0","1","1","","0000-00-00 00:00:00","","2017-07-16 01:15:46","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("325","static_file","/wp-admin/css/site-icon.min.css","","","0","1","1","","0000-00-00 00:00:00","","2017-08-19 08:10:48","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("326","static_file","/wp-admin/css/themes-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("327","static_file","/wp-admin/css/themes-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("328","static_file","/wp-admin/css/themes.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("329","static_file","/wp-admin/css/themes.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("330","static_file","/wp-admin/css/widgets-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 03:17:58","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("331","static_file","/wp-admin/css/widgets-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 03:17:58","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("332","static_file","/wp-admin/css/widgets.css","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 03:17:58","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("333","static_file","/wp-admin/css/widgets.min.css","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 03:17:58","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("334","static_file","/wp-admin/css/wp-admin-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2019-10-26 12:17:08","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("335","static_file","/wp-admin/css/wp-admin-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2019-03-23 03:55:54","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("336","static_file","/wp-admin/css/wp-admin.css","","","0","1","1","","0000-00-00 00:00:00","","2019-03-23 03:55:54","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("337","static_file","/wp-admin/css/wp-admin.min.css","","","0","1","1","","0000-00-00 00:00:00","","2019-03-23 03:55:54","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("338","static_file","/wp-admin/images/bubble_bg-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("339","static_file","/wp-admin/images/bubble_bg.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("340","static_file","/wp-admin/images/date-button-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("341","static_file","/wp-admin/images/date-button.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("342","static_file","/wp-admin/images/loading.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("343","static_file","/wp-admin/images/media-button-image.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("344","static_file","/wp-admin/images/media-button-music.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("345","static_file","/wp-admin/images/media-button-other.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("346","static_file","/wp-admin/images/media-button-video.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("347","static_file","/wp-admin/images/resize-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("348","static_file","/wp-admin/images/resize-rtl-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("349","static_file","/wp-admin/images/resize-rtl.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("350","static_file","/wp-admin/images/resize.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("351","static_file","/wp-admin/images/sort-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("352","static_file","/wp-admin/images/sort.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("353","static_file","/wp-admin/images/spinner-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("354","static_file","/wp-admin/images/spinner.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("355","static_file","/wp-admin/images/wpspin_light-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("356","static_file","/wp-admin/images/wpspin_light.gif","","","0","1","1","","0000-00-00 00:00:00","","2021-11-16 12:04:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("357","static_file","/wp-admin/images/xit-2x.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("358","static_file","/wp-admin/images/xit.gif","","","0","1","1","","0000-00-00 00:00:00","","2019-10-05 02:21:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("359","static_file","/wp-admin/images/about-texture.png","","","0","1","1","","0000-00-00 00:00:00","","2022-04-27 05:37:08","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("360","static_file","/wp-admin/images/align-center-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2012-09-27 02:12:54","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("361","static_file","/wp-admin/images/align-center.png","","","0","1","1","","0000-00-00 00:00:00","","2012-09-24 07:44:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("362","static_file","/wp-admin/images/align-left-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2012-09-27 02:12:54","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("363","static_file","/wp-admin/images/align-left.png","","","0","1","1","","0000-00-00 00:00:00","","2012-09-24 07:44:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("364","static_file","/wp-admin/images/align-none-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2012-09-27 02:12:54","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("365","static_file","/wp-admin/images/align-none.png","","","0","1","1","","0000-00-00 00:00:00","","2012-09-24 07:44:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("366","static_file","/wp-admin/images/align-right-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2012-09-27 02:12:54","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("367","static_file","/wp-admin/images/align-right.png","","","0","1","1","","0000-00-00 00:00:00","","2012-09-24 07:44:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("368","static_file","/wp-admin/images/arrows-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2012-09-27 02:12:54","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("369","static_file","/wp-admin/images/arrows.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("370","static_file","/wp-admin/images/browser-rtl.png","","","0","1","1","","0000-00-00 00:00:00","","2016-07-05 11:32:30","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("371","static_file","/wp-admin/images/browser.png","","","0","1","1","","0000-00-00 00:00:00","","2015-06-30 10:04:26","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("372","static_file","/wp-admin/images/comment-grey-bubble-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-02-13 08:03:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("373","static_file","/wp-admin/images/comment-grey-bubble.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("374","static_file","/wp-admin/images/generic.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("375","static_file","/wp-admin/images/icons32-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("376","static_file","/wp-admin/images/icons32-vs-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-11-25 06:12:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("377","static_file","/wp-admin/images/icons32-vs.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("378","static_file","/wp-admin/images/icons32.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("379","static_file","/wp-admin/images/imgedit-icons-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("380","static_file","/wp-admin/images/imgedit-icons.png","","","0","1","1","","0000-00-00 00:00:00","","2014-11-25 06:12:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("381","static_file","/wp-admin/images/list-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("382","static_file","/wp-admin/images/list.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("383","static_file","/wp-admin/images/marker.png","","","0","1","1","","0000-00-00 00:00:00","","2014-02-13 08:03:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("384","static_file","/wp-admin/images/mask.png","","","0","1","1","","0000-00-00 00:00:00","","2012-09-24 07:44:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("385","static_file","/wp-admin/images/media-button-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("386","static_file","/wp-admin/images/media-button.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("387","static_file","/wp-admin/images/menu-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("388","static_file","/wp-admin/images/menu-vs-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("389","static_file","/wp-admin/images/menu-vs.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("390","static_file","/wp-admin/images/menu.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("391","static_file","/wp-admin/images/no.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("392","static_file","/wp-admin/images/post-formats-vs.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("393","static_file","/wp-admin/images/post-formats.png","","","0","1","1","","0000-00-00 00:00:00","","2014-02-13 08:03:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("394","static_file","/wp-admin/images/post-formats32-vs.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("395","static_file","/wp-admin/images/post-formats32.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("396","static_file","/wp-admin/images/se.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("397","static_file","/wp-admin/images/stars-2x.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-09 01:34:48","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("398","static_file","/wp-admin/images/stars.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("399","static_file","/wp-admin/images/w-logo-blue.png","","","0","1","1","","0000-00-00 00:00:00","","2020-05-21 09:10:12","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("400","static_file","/wp-admin/images/w-logo-white.png","","","0","1","1","","0000-00-00 00:00:00","","2016-03-10 05:16:26","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("401","static_file","/wp-admin/images/wheel.png","","","0","1","1","","0000-00-00 00:00:00","","2014-10-28 10:02:22","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("402","static_file","/wp-admin/images/wordpress-logo.png","","","0","1","1","","0000-00-00 00:00:00","","2012-11-07 06:49:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("403","static_file","/wp-admin/images/yes.png","","","0","1","1","","0000-00-00 00:00:00","","2012-09-24 07:44:42","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("404","static_file","/wp-admin/images/about-header-about.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("405","static_file","/wp-admin/images/about-header-contribute.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("406","static_file","/wp-admin/images/about-header-credits.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("407","static_file","/wp-admin/images/about-header-freedoms.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("408","static_file","/wp-admin/images/about-header-privacy.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("409","static_file","/wp-admin/images/about-release-badge.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("410","static_file","/wp-admin/images/contribute-code.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("411","static_file","/wp-admin/images/contribute-main.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("412","static_file","/wp-admin/images/contribute-no-code.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("413","static_file","/wp-admin/images/dashboard-background.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("414","static_file","/wp-admin/images/freedom-1.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("415","static_file","/wp-admin/images/freedom-2.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("416","static_file","/wp-admin/images/freedom-3.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("417","static_file","/wp-admin/images/freedom-4.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("418","static_file","/wp-admin/images/privacy.svg","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:43","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("419","static_file","/wp-admin/images/wordpress-logo-white.svg","","","0","1","1","","0000-00-00 00:00:00","","2016-03-09 09:53:26","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("420","static_file","/wp-admin/images/wordpress-logo.svg","","","0","1","1","","0000-00-00 00:00:00","","2015-04-05 09:20:28","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("421","static_file","/wp-admin/js/widgets/custom-html-widgets.js","","","0","1","1","","0000-00-00 00:00:00","","2021-08-31 01:51:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("422","static_file","/wp-admin/js/widgets/custom-html-widgets.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("423","static_file","/wp-admin/js/widgets/media-audio-widget.js","","","0","1","1","","0000-00-00 00:00:00","","2019-11-29 06:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("424","static_file","/wp-admin/js/widgets/media-audio-widget.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("425","static_file","/wp-admin/js/widgets/media-gallery-widget.js","","","0","1","1","","0000-00-00 00:00:00","","2019-11-29 06:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("426","static_file","/wp-admin/js/widgets/media-gallery-widget.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("427","static_file","/wp-admin/js/widgets/media-image-widget.js","","","0","1","1","","0000-00-00 00:00:00","","2019-11-29 06:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("428","static_file","/wp-admin/js/widgets/media-image-widget.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-01-06 03:29:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("429","static_file","/wp-admin/js/widgets/media-video-widget.js","","","0","1","1","","0000-00-00 00:00:00","","2019-11-29 06:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("430","static_file","/wp-admin/js/widgets/media-video-widget.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("431","static_file","/wp-admin/js/widgets/media-widgets.js","","","0","1","1","","0000-00-00 00:00:00","","2021-08-31 01:51:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("432","static_file","/wp-admin/js/widgets/media-widgets.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("433","static_file","/wp-admin/js/widgets/text-widgets.js","","","0","1","1","","0000-00-00 00:00:00","","2021-07-12 11:57:58","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("434","static_file","/wp-admin/js/widgets/text-widgets.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("435","static_file","/wp-admin/js/accordion.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("436","static_file","/wp-admin/js/accordion.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("437","static_file","/wp-admin/js/application-passwords.js","","","0","1","1","","0000-00-00 00:00:00","","2021-06-07 11:49:58","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("438","static_file","/wp-admin/js/application-passwords.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("439","static_file","/wp-admin/js/auth-app.js","","","0","1","1","","0000-00-00 00:00:00","","2021-02-23 07:45:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("440","static_file","/wp-admin/js/auth-app.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("441","static_file","/wp-admin/js/code-editor.js","","","0","1","1","","0000-00-00 00:00:00","","2020-07-27 11:35:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("442","static_file","/wp-admin/js/code-editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("443","static_file","/wp-admin/js/color-picker.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("444","static_file","/wp-admin/js/color-picker.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("445","static_file","/wp-admin/js/comment.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("446","static_file","/wp-admin/js/comment.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("447","static_file","/wp-admin/js/common.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("448","static_file","/wp-admin/js/common.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("449","static_file","/wp-admin/js/custom-background.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("450","static_file","/wp-admin/js/custom-background.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("451","static_file","/wp-admin/js/custom-header.js","","","0","1","1","","0000-00-00 00:00:00","","2021-02-23 07:45:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("452","static_file","/wp-admin/js/customize-controls.js","","","0","1","1","","0000-00-00 00:00:00","","2022-03-29 07:10:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("453","static_file","/wp-admin/js/customize-controls.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("454","static_file","/wp-admin/js/customize-nav-menus.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("455","static_file","/wp-admin/js/customize-nav-menus.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("456","static_file","/wp-admin/js/customize-widgets.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-26 06:54:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("457","static_file","/wp-admin/js/customize-widgets.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("458","static_file","/wp-admin/js/dashboard.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("459","static_file","/wp-admin/js/dashboard.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("460","static_file","/wp-admin/js/edit-comments.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-27 05:06:10","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("461","static_file","/wp-admin/js/edit-comments.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("462","static_file","/wp-admin/js/editor-expand.js","","","0","1","1","","0000-00-00 00:00:00","","2021-09-08 11:29:58","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("463","static_file","/wp-admin/js/editor-expand.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("464","static_file","/wp-admin/js/editor.js","","","0","1","1","","0000-00-00 00:00:00","","2021-09-08 11:29:58","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("465","static_file","/wp-admin/js/editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("466","static_file","/wp-admin/js/farbtastic.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("467","static_file","/wp-admin/js/gallery.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("468","static_file","/wp-admin/js/gallery.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("469","static_file","/wp-admin/js/image-edit.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("470","static_file","/wp-admin/js/image-edit.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("471","static_file","/wp-admin/js/inline-edit-post.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("472","static_file","/wp-admin/js/inline-edit-post.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("473","static_file","/wp-admin/js/inline-edit-tax.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("474","static_file","/wp-admin/js/inline-edit-tax.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("475","static_file","/wp-admin/js/iris.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-11-03 07:40:00","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("476","static_file","/wp-admin/js/language-chooser.js","","","0","1","1","","0000-00-00 00:00:00","","2021-02-23 07:45:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("477","static_file","/wp-admin/js/language-chooser.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-02-23 07:45:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("478","static_file","/wp-admin/js/link.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("479","static_file","/wp-admin/js/link.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("480","static_file","/wp-admin/js/media-gallery.js","","","0","1","1","","0000-00-00 00:00:00","","2021-02-23 07:45:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("481","static_file","/wp-admin/js/media-gallery.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("482","static_file","/wp-admin/js/media-upload.js","","","0","1","1","","0000-00-00 00:00:00","","2021-01-22 12:32:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("483","static_file","/wp-admin/js/media-upload.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("484","static_file","/wp-admin/js/media.js","","","0","1","1","","0000-00-00 00:00:00","","2022-03-10 06:43:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("485","static_file","/wp-admin/js/media.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("486","static_file","/wp-admin/js/nav-menu.js","","","0","1","1","","0000-00-00 00:00:00","","2022-11-17 06:15:20","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("487","static_file","/wp-admin/js/nav-menu.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("488","static_file","/wp-admin/js/password-strength-meter.js","","","0","1","1","","0000-00-00 00:00:00","","2021-01-22 12:32:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("489","static_file","/wp-admin/js/password-strength-meter.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-01-22 12:32:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("490","static_file","/wp-admin/js/password-toggle.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("491","static_file","/wp-admin/js/password-toggle.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("492","static_file","/wp-admin/js/plugin-install.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("493","static_file","/wp-admin/js/plugin-install.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("494","static_file","/wp-admin/js/post.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("495","static_file","/wp-admin/js/post.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("496","static_file","/wp-admin/js/postbox.js","","","0","1","1","","0000-00-00 00:00:00","","2023-01-10 09:30:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("497","static_file","/wp-admin/js/postbox.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("498","static_file","/wp-admin/js/privacy-tools.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("499","static_file","/wp-admin/js/privacy-tools.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("500","static_file","/wp-admin/js/revisions.js","","","0","1","1","","0000-00-00 00:00:00","","2020-01-29 12:37:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("501","static_file","/wp-admin/js/revisions.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("502","static_file","/wp-admin/js/set-post-thumbnail.js","","","0","1","1","","0000-00-00 00:00:00","","2020-07-07 06:55:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("503","static_file","/wp-admin/js/set-post-thumbnail.min.js","","","0","1","1","","0000-00-00 00:00:00","","2020-07-07 06:55:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("504","static_file","/wp-admin/js/site-health.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-14 09:14:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("505","static_file","/wp-admin/js/site-health.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("506","static_file","/wp-admin/js/svg-painter.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("507","static_file","/wp-admin/js/svg-painter.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-08 08:07:18","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("508","static_file","/wp-admin/js/tags-box.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("509","static_file","/wp-admin/js/tags-box.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("510","static_file","/wp-admin/js/tags-suggest.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-07 04:06:06","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("511","static_file","/wp-admin/js/tags-suggest.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("512","static_file","/wp-admin/js/tags.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-12 07:37:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("513","static_file","/wp-admin/js/tags.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-04-12 07:37:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("514","static_file","/wp-admin/js/theme-plugin-editor.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("515","static_file","/wp-admin/js/theme-plugin-editor.min.js","","","0","1","1","","0000-00-00 00:00:00","","2022-09-23 07:55:30","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("516","static_file","/wp-admin/js/theme.js","","","0","1","1","","0000-00-00 00:00:00","","2022-08-19 01:11:14","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("517","static_file","/wp-admin/js/theme.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("518","static_file","/wp-admin/js/updates.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("519","static_file","/wp-admin/js/updates.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("520","static_file","/wp-admin/js/user-profile.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("521","static_file","/wp-admin/js/user-profile.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:44","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("522","static_file","/wp-admin/js/user-suggest.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("523","static_file","/wp-admin/js/user-suggest.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("524","static_file","/wp-admin/js/widgets.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("525","static_file","/wp-admin/js/widgets.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("526","static_file","/wp-admin/js/word-count.js","","","0","1","1","","0000-00-00 00:00:00","","2020-07-27 11:35:02","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("527","static_file","/wp-admin/js/word-count.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-02-02 04:36:32","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("528","static_file","/wp-admin/js/xfn.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("529","static_file","/wp-admin/js/xfn.min.js","","","0","1","1","","0000-00-00 00:00:00","","2021-03-18 07:01:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("530","static_file","/wp-includes/ID3/license.commercial.txt","","","0","1","1","","0000-00-00 00:00:00","","2015-06-28 12:17:26","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("531","static_file","/wp-includes/ID3/license.txt","","","0","1","1","","0000-00-00 00:00:00","","2019-09-14 07:07:58","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("532","static_file","/wp-includes/ID3/readme.txt","","","0","1","1","","0000-00-00 00:00:00","","2021-11-26 03:06:04","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("533","static_file","/wp-includes/blocks/archives/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("534","static_file","/wp-includes/blocks/archives/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("535","static_file","/wp-includes/blocks/archives/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("536","static_file","/wp-includes/blocks/archives/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("537","static_file","/wp-includes/blocks/archives/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("538","static_file","/wp-includes/blocks/archives/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("539","static_file","/wp-includes/blocks/archives/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("540","static_file","/wp-includes/blocks/archives/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("541","static_file","/wp-includes/blocks/audio/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("542","static_file","/wp-includes/blocks/audio/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("543","static_file","/wp-includes/blocks/audio/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("544","static_file","/wp-includes/blocks/audio/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("545","static_file","/wp-includes/blocks/audio/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("546","static_file","/wp-includes/blocks/audio/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("547","static_file","/wp-includes/blocks/audio/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("548","static_file","/wp-includes/blocks/audio/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("549","static_file","/wp-includes/blocks/audio/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("550","static_file","/wp-includes/blocks/audio/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("551","static_file","/wp-includes/blocks/audio/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("552","static_file","/wp-includes/blocks/audio/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("553","static_file","/wp-includes/blocks/avatar/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("554","static_file","/wp-includes/blocks/avatar/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("555","static_file","/wp-includes/blocks/avatar/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("556","static_file","/wp-includes/blocks/avatar/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("557","static_file","/wp-includes/blocks/avatar/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("558","static_file","/wp-includes/blocks/avatar/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("559","static_file","/wp-includes/blocks/avatar/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("560","static_file","/wp-includes/blocks/avatar/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("561","static_file","/wp-includes/blocks/block/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("562","static_file","/wp-includes/blocks/block/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("563","static_file","/wp-includes/blocks/block/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("564","static_file","/wp-includes/blocks/block/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("565","static_file","/wp-includes/blocks/button/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("566","static_file","/wp-includes/blocks/button/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("567","static_file","/wp-includes/blocks/button/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("568","static_file","/wp-includes/blocks/button/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("569","static_file","/wp-includes/blocks/button/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("570","static_file","/wp-includes/blocks/button/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("571","static_file","/wp-includes/blocks/button/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("572","static_file","/wp-includes/blocks/button/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("573","static_file","/wp-includes/blocks/buttons/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("574","static_file","/wp-includes/blocks/buttons/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("575","static_file","/wp-includes/blocks/buttons/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("576","static_file","/wp-includes/blocks/buttons/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("577","static_file","/wp-includes/blocks/buttons/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("578","static_file","/wp-includes/blocks/buttons/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("579","static_file","/wp-includes/blocks/buttons/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("580","static_file","/wp-includes/blocks/buttons/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("581","static_file","/wp-includes/blocks/calendar/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("582","static_file","/wp-includes/blocks/calendar/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("583","static_file","/wp-includes/blocks/calendar/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("584","static_file","/wp-includes/blocks/calendar/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("585","static_file","/wp-includes/blocks/categories/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("586","static_file","/wp-includes/blocks/categories/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("587","static_file","/wp-includes/blocks/categories/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("588","static_file","/wp-includes/blocks/categories/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("589","static_file","/wp-includes/blocks/categories/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("590","static_file","/wp-includes/blocks/categories/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("591","static_file","/wp-includes/blocks/categories/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("592","static_file","/wp-includes/blocks/categories/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("593","static_file","/wp-includes/blocks/code/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("594","static_file","/wp-includes/blocks/code/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("595","static_file","/wp-includes/blocks/code/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("596","static_file","/wp-includes/blocks/code/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("597","static_file","/wp-includes/blocks/code/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("598","static_file","/wp-includes/blocks/code/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("599","static_file","/wp-includes/blocks/code/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("600","static_file","/wp-includes/blocks/code/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("601","static_file","/wp-includes/blocks/code/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("602","static_file","/wp-includes/blocks/code/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("603","static_file","/wp-includes/blocks/code/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("604","static_file","/wp-includes/blocks/code/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("605","static_file","/wp-includes/blocks/columns/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("606","static_file","/wp-includes/blocks/columns/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("607","static_file","/wp-includes/blocks/columns/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("608","static_file","/wp-includes/blocks/columns/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("609","static_file","/wp-includes/blocks/columns/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("610","static_file","/wp-includes/blocks/columns/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("611","static_file","/wp-includes/blocks/columns/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("612","static_file","/wp-includes/blocks/columns/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("613","static_file","/wp-includes/blocks/comment-content/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("614","static_file","/wp-includes/blocks/comment-content/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("615","static_file","/wp-includes/blocks/comment-content/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("616","static_file","/wp-includes/blocks/comment-content/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("617","static_file","/wp-includes/blocks/comment-template/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("618","static_file","/wp-includes/blocks/comment-template/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("619","static_file","/wp-includes/blocks/comment-template/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("620","static_file","/wp-includes/blocks/comment-template/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("621","static_file","/wp-includes/blocks/comments-pagination-numbers/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("622","static_file","/wp-includes/blocks/comments-pagination-numbers/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("623","static_file","/wp-includes/blocks/comments-pagination-numbers/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("624","static_file","/wp-includes/blocks/comments-pagination-numbers/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("625","static_file","/wp-includes/blocks/comments-pagination/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("626","static_file","/wp-includes/blocks/comments-pagination/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("627","static_file","/wp-includes/blocks/comments-pagination/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("628","static_file","/wp-includes/blocks/comments-pagination/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("629","static_file","/wp-includes/blocks/comments-pagination/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("630","static_file","/wp-includes/blocks/comments-pagination/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("631","static_file","/wp-includes/blocks/comments-pagination/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("632","static_file","/wp-includes/blocks/comments-pagination/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("633","static_file","/wp-includes/blocks/comments-title/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("634","static_file","/wp-includes/blocks/comments-title/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("635","static_file","/wp-includes/blocks/comments-title/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("636","static_file","/wp-includes/blocks/comments-title/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("637","static_file","/wp-includes/blocks/comments/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("638","static_file","/wp-includes/blocks/comments/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("639","static_file","/wp-includes/blocks/comments/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("640","static_file","/wp-includes/blocks/comments/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("641","static_file","/wp-includes/blocks/comments/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("642","static_file","/wp-includes/blocks/comments/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("643","static_file","/wp-includes/blocks/comments/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("644","static_file","/wp-includes/blocks/comments/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("645","static_file","/wp-includes/blocks/cover/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("646","static_file","/wp-includes/blocks/cover/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("647","static_file","/wp-includes/blocks/cover/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("648","static_file","/wp-includes/blocks/cover/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("649","static_file","/wp-includes/blocks/cover/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("650","static_file","/wp-includes/blocks/cover/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("651","static_file","/wp-includes/blocks/cover/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("652","static_file","/wp-includes/blocks/cover/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("653","static_file","/wp-includes/blocks/details/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("654","static_file","/wp-includes/blocks/details/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("655","static_file","/wp-includes/blocks/details/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("656","static_file","/wp-includes/blocks/details/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("657","static_file","/wp-includes/blocks/details/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("658","static_file","/wp-includes/blocks/details/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("659","static_file","/wp-includes/blocks/details/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("660","static_file","/wp-includes/blocks/details/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("661","static_file","/wp-includes/blocks/embed/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("662","static_file","/wp-includes/blocks/embed/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("663","static_file","/wp-includes/blocks/embed/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("664","static_file","/wp-includes/blocks/embed/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("665","static_file","/wp-includes/blocks/embed/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("666","static_file","/wp-includes/blocks/embed/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("667","static_file","/wp-includes/blocks/embed/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("668","static_file","/wp-includes/blocks/embed/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("669","static_file","/wp-includes/blocks/embed/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("670","static_file","/wp-includes/blocks/embed/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("671","static_file","/wp-includes/blocks/embed/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("672","static_file","/wp-includes/blocks/embed/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("673","static_file","/wp-includes/blocks/file/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("674","static_file","/wp-includes/blocks/file/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("675","static_file","/wp-includes/blocks/file/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("676","static_file","/wp-includes/blocks/file/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("677","static_file","/wp-includes/blocks/file/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("678","static_file","/wp-includes/blocks/file/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("679","static_file","/wp-includes/blocks/file/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("680","static_file","/wp-includes/blocks/file/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("681","static_file","/wp-includes/blocks/file/view.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("682","static_file","/wp-includes/blocks/file/view.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("683","static_file","/wp-includes/blocks/footnotes/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("684","static_file","/wp-includes/blocks/footnotes/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("685","static_file","/wp-includes/blocks/footnotes/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("686","static_file","/wp-includes/blocks/footnotes/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("687","static_file","/wp-includes/blocks/freeform/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("688","static_file","/wp-includes/blocks/freeform/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("689","static_file","/wp-includes/blocks/freeform/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("690","static_file","/wp-includes/blocks/freeform/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("691","static_file","/wp-includes/blocks/gallery/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("692","static_file","/wp-includes/blocks/gallery/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("693","static_file","/wp-includes/blocks/gallery/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("694","static_file","/wp-includes/blocks/gallery/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("695","static_file","/wp-includes/blocks/gallery/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("696","static_file","/wp-includes/blocks/gallery/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("697","static_file","/wp-includes/blocks/gallery/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("698","static_file","/wp-includes/blocks/gallery/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("699","static_file","/wp-includes/blocks/gallery/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("700","static_file","/wp-includes/blocks/gallery/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("701","static_file","/wp-includes/blocks/gallery/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("702","static_file","/wp-includes/blocks/gallery/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("703","static_file","/wp-includes/blocks/group/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("704","static_file","/wp-includes/blocks/group/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("705","static_file","/wp-includes/blocks/group/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("706","static_file","/wp-includes/blocks/group/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("707","static_file","/wp-includes/blocks/group/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("708","static_file","/wp-includes/blocks/group/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("709","static_file","/wp-includes/blocks/group/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("710","static_file","/wp-includes/blocks/group/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("711","static_file","/wp-includes/blocks/group/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("712","static_file","/wp-includes/blocks/group/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("713","static_file","/wp-includes/blocks/group/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("714","static_file","/wp-includes/blocks/group/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("715","static_file","/wp-includes/blocks/heading/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("716","static_file","/wp-includes/blocks/heading/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("717","static_file","/wp-includes/blocks/heading/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("718","static_file","/wp-includes/blocks/heading/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("719","static_file","/wp-includes/blocks/html/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("720","static_file","/wp-includes/blocks/html/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("721","static_file","/wp-includes/blocks/html/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("722","static_file","/wp-includes/blocks/html/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("723","static_file","/wp-includes/blocks/image/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("724","static_file","/wp-includes/blocks/image/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("725","static_file","/wp-includes/blocks/image/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("726","static_file","/wp-includes/blocks/image/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("727","static_file","/wp-includes/blocks/image/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("728","static_file","/wp-includes/blocks/image/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("729","static_file","/wp-includes/blocks/image/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("730","static_file","/wp-includes/blocks/image/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("731","static_file","/wp-includes/blocks/image/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("732","static_file","/wp-includes/blocks/image/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("733","static_file","/wp-includes/blocks/image/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("734","static_file","/wp-includes/blocks/image/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("735","static_file","/wp-includes/blocks/latest-comments/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("736","static_file","/wp-includes/blocks/latest-comments/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("737","static_file","/wp-includes/blocks/latest-comments/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("738","static_file","/wp-includes/blocks/latest-comments/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("739","static_file","/wp-includes/blocks/latest-posts/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("740","static_file","/wp-includes/blocks/latest-posts/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("741","static_file","/wp-includes/blocks/latest-posts/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("742","static_file","/wp-includes/blocks/latest-posts/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("743","static_file","/wp-includes/blocks/latest-posts/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("744","static_file","/wp-includes/blocks/latest-posts/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("745","static_file","/wp-includes/blocks/latest-posts/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("746","static_file","/wp-includes/blocks/latest-posts/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("747","static_file","/wp-includes/blocks/list/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("748","static_file","/wp-includes/blocks/list/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("749","static_file","/wp-includes/blocks/list/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("750","static_file","/wp-includes/blocks/list/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("751","static_file","/wp-includes/blocks/media-text/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("752","static_file","/wp-includes/blocks/media-text/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("753","static_file","/wp-includes/blocks/media-text/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("754","static_file","/wp-includes/blocks/media-text/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("755","static_file","/wp-includes/blocks/media-text/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("756","static_file","/wp-includes/blocks/media-text/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("757","static_file","/wp-includes/blocks/media-text/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("758","static_file","/wp-includes/blocks/media-text/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("759","static_file","/wp-includes/blocks/more/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("760","static_file","/wp-includes/blocks/more/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("761","static_file","/wp-includes/blocks/more/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("762","static_file","/wp-includes/blocks/more/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("763","static_file","/wp-includes/blocks/navigation-link/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("764","static_file","/wp-includes/blocks/navigation-link/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("765","static_file","/wp-includes/blocks/navigation-link/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("766","static_file","/wp-includes/blocks/navigation-link/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("767","static_file","/wp-includes/blocks/navigation-link/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("768","static_file","/wp-includes/blocks/navigation-link/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("769","static_file","/wp-includes/blocks/navigation-link/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("770","static_file","/wp-includes/blocks/navigation-link/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("771","static_file","/wp-includes/blocks/navigation-submenu/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("772","static_file","/wp-includes/blocks/navigation-submenu/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("773","static_file","/wp-includes/blocks/navigation-submenu/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("774","static_file","/wp-includes/blocks/navigation-submenu/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("775","static_file","/wp-includes/blocks/navigation/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("776","static_file","/wp-includes/blocks/navigation/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("777","static_file","/wp-includes/blocks/navigation/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("778","static_file","/wp-includes/blocks/navigation/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("779","static_file","/wp-includes/blocks/navigation/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("780","static_file","/wp-includes/blocks/navigation/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("781","static_file","/wp-includes/blocks/navigation/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("782","static_file","/wp-includes/blocks/navigation/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("783","static_file","/wp-includes/blocks/navigation/view-modal.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("784","static_file","/wp-includes/blocks/navigation/view-modal.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("785","static_file","/wp-includes/blocks/navigation/view.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("786","static_file","/wp-includes/blocks/navigation/view.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("787","static_file","/wp-includes/blocks/nextpage/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("788","static_file","/wp-includes/blocks/nextpage/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("789","static_file","/wp-includes/blocks/nextpage/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("790","static_file","/wp-includes/blocks/nextpage/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("791","static_file","/wp-includes/blocks/page-list/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("792","static_file","/wp-includes/blocks/page-list/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("793","static_file","/wp-includes/blocks/page-list/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("794","static_file","/wp-includes/blocks/page-list/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("795","static_file","/wp-includes/blocks/page-list/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("796","static_file","/wp-includes/blocks/page-list/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("797","static_file","/wp-includes/blocks/page-list/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("798","static_file","/wp-includes/blocks/page-list/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("799","static_file","/wp-includes/blocks/paragraph/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("800","static_file","/wp-includes/blocks/paragraph/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("801","static_file","/wp-includes/blocks/paragraph/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("802","static_file","/wp-includes/blocks/paragraph/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("803","static_file","/wp-includes/blocks/paragraph/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("804","static_file","/wp-includes/blocks/paragraph/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("805","static_file","/wp-includes/blocks/paragraph/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("806","static_file","/wp-includes/blocks/paragraph/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("807","static_file","/wp-includes/blocks/post-author/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("808","static_file","/wp-includes/blocks/post-author/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("809","static_file","/wp-includes/blocks/post-author/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("810","static_file","/wp-includes/blocks/post-author/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("811","static_file","/wp-includes/blocks/post-comments-form/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("812","static_file","/wp-includes/blocks/post-comments-form/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("813","static_file","/wp-includes/blocks/post-comments-form/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("814","static_file","/wp-includes/blocks/post-comments-form/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("815","static_file","/wp-includes/blocks/post-comments-form/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("816","static_file","/wp-includes/blocks/post-comments-form/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("817","static_file","/wp-includes/blocks/post-comments-form/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("818","static_file","/wp-includes/blocks/post-comments-form/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("819","static_file","/wp-includes/blocks/post-date/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("820","static_file","/wp-includes/blocks/post-date/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("821","static_file","/wp-includes/blocks/post-date/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("822","static_file","/wp-includes/blocks/post-date/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("823","static_file","/wp-includes/blocks/post-excerpt/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("824","static_file","/wp-includes/blocks/post-excerpt/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("825","static_file","/wp-includes/blocks/post-excerpt/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("826","static_file","/wp-includes/blocks/post-excerpt/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("827","static_file","/wp-includes/blocks/post-excerpt/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("828","static_file","/wp-includes/blocks/post-excerpt/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("829","static_file","/wp-includes/blocks/post-excerpt/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("830","static_file","/wp-includes/blocks/post-excerpt/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("831","static_file","/wp-includes/blocks/post-featured-image/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("832","static_file","/wp-includes/blocks/post-featured-image/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("833","static_file","/wp-includes/blocks/post-featured-image/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("834","static_file","/wp-includes/blocks/post-featured-image/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("835","static_file","/wp-includes/blocks/post-featured-image/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("836","static_file","/wp-includes/blocks/post-featured-image/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("837","static_file","/wp-includes/blocks/post-featured-image/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("838","static_file","/wp-includes/blocks/post-featured-image/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("839","static_file","/wp-includes/blocks/post-navigation-link/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("840","static_file","/wp-includes/blocks/post-navigation-link/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("841","static_file","/wp-includes/blocks/post-navigation-link/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("842","static_file","/wp-includes/blocks/post-navigation-link/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("843","static_file","/wp-includes/blocks/post-template/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("844","static_file","/wp-includes/blocks/post-template/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("845","static_file","/wp-includes/blocks/post-template/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("846","static_file","/wp-includes/blocks/post-template/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("847","static_file","/wp-includes/blocks/post-template/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("848","static_file","/wp-includes/blocks/post-template/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("849","static_file","/wp-includes/blocks/post-template/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("850","static_file","/wp-includes/blocks/post-template/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("851","static_file","/wp-includes/blocks/post-terms/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("852","static_file","/wp-includes/blocks/post-terms/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("853","static_file","/wp-includes/blocks/post-terms/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("854","static_file","/wp-includes/blocks/post-terms/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("855","static_file","/wp-includes/blocks/post-title/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("856","static_file","/wp-includes/blocks/post-title/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("857","static_file","/wp-includes/blocks/post-title/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("858","static_file","/wp-includes/blocks/post-title/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("859","static_file","/wp-includes/blocks/preformatted/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("860","static_file","/wp-includes/blocks/preformatted/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("861","static_file","/wp-includes/blocks/preformatted/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("862","static_file","/wp-includes/blocks/preformatted/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("863","static_file","/wp-includes/blocks/pullquote/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("864","static_file","/wp-includes/blocks/pullquote/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("865","static_file","/wp-includes/blocks/pullquote/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("866","static_file","/wp-includes/blocks/pullquote/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("867","static_file","/wp-includes/blocks/pullquote/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("868","static_file","/wp-includes/blocks/pullquote/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("869","static_file","/wp-includes/blocks/pullquote/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("870","static_file","/wp-includes/blocks/pullquote/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("871","static_file","/wp-includes/blocks/pullquote/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("872","static_file","/wp-includes/blocks/pullquote/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("873","static_file","/wp-includes/blocks/pullquote/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("874","static_file","/wp-includes/blocks/pullquote/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("875","static_file","/wp-includes/blocks/query-pagination-numbers/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:30");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("876","static_file","/wp-includes/blocks/query-pagination-numbers/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("877","static_file","/wp-includes/blocks/query-pagination-numbers/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("878","static_file","/wp-includes/blocks/query-pagination-numbers/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("879","static_file","/wp-includes/blocks/query-pagination/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("880","static_file","/wp-includes/blocks/query-pagination/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("881","static_file","/wp-includes/blocks/query-pagination/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("882","static_file","/wp-includes/blocks/query-pagination/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("883","static_file","/wp-includes/blocks/query-pagination/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("884","static_file","/wp-includes/blocks/query-pagination/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("885","static_file","/wp-includes/blocks/query-pagination/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("886","static_file","/wp-includes/blocks/query-pagination/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("887","static_file","/wp-includes/blocks/query-title/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("888","static_file","/wp-includes/blocks/query-title/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("889","static_file","/wp-includes/blocks/query-title/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("890","static_file","/wp-includes/blocks/query-title/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("891","static_file","/wp-includes/blocks/query/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("892","static_file","/wp-includes/blocks/query/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("893","static_file","/wp-includes/blocks/query/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("894","static_file","/wp-includes/blocks/query/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("895","static_file","/wp-includes/blocks/quote/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("896","static_file","/wp-includes/blocks/quote/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("897","static_file","/wp-includes/blocks/quote/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("898","static_file","/wp-includes/blocks/quote/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("899","static_file","/wp-includes/blocks/quote/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("900","static_file","/wp-includes/blocks/quote/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("901","static_file","/wp-includes/blocks/quote/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("902","static_file","/wp-includes/blocks/quote/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("903","static_file","/wp-includes/blocks/read-more/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("904","static_file","/wp-includes/blocks/read-more/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("905","static_file","/wp-includes/blocks/read-more/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("906","static_file","/wp-includes/blocks/read-more/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("907","static_file","/wp-includes/blocks/rss/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("908","static_file","/wp-includes/blocks/rss/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("909","static_file","/wp-includes/blocks/rss/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("910","static_file","/wp-includes/blocks/rss/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("911","static_file","/wp-includes/blocks/rss/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("912","static_file","/wp-includes/blocks/rss/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("913","static_file","/wp-includes/blocks/rss/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("914","static_file","/wp-includes/blocks/rss/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("915","static_file","/wp-includes/blocks/search/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("916","static_file","/wp-includes/blocks/search/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("917","static_file","/wp-includes/blocks/search/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("918","static_file","/wp-includes/blocks/search/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("919","static_file","/wp-includes/blocks/search/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("920","static_file","/wp-includes/blocks/search/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:45","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("921","static_file","/wp-includes/blocks/search/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("922","static_file","/wp-includes/blocks/search/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("923","static_file","/wp-includes/blocks/search/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("924","static_file","/wp-includes/blocks/search/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("925","static_file","/wp-includes/blocks/search/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("926","static_file","/wp-includes/blocks/search/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("927","static_file","/wp-includes/blocks/search/view.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("928","static_file","/wp-includes/blocks/search/view.min.js","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("929","static_file","/wp-includes/blocks/separator/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("930","static_file","/wp-includes/blocks/separator/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("931","static_file","/wp-includes/blocks/separator/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("932","static_file","/wp-includes/blocks/separator/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("933","static_file","/wp-includes/blocks/separator/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("934","static_file","/wp-includes/blocks/separator/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("935","static_file","/wp-includes/blocks/separator/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("936","static_file","/wp-includes/blocks/separator/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("937","static_file","/wp-includes/blocks/separator/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("938","static_file","/wp-includes/blocks/separator/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("939","static_file","/wp-includes/blocks/separator/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("940","static_file","/wp-includes/blocks/separator/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("941","static_file","/wp-includes/blocks/shortcode/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("942","static_file","/wp-includes/blocks/shortcode/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("943","static_file","/wp-includes/blocks/shortcode/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("944","static_file","/wp-includes/blocks/shortcode/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("945","static_file","/wp-includes/blocks/site-logo/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("946","static_file","/wp-includes/blocks/site-logo/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("947","static_file","/wp-includes/blocks/site-logo/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("948","static_file","/wp-includes/blocks/site-logo/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("949","static_file","/wp-includes/blocks/site-logo/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("950","static_file","/wp-includes/blocks/site-logo/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("951","static_file","/wp-includes/blocks/site-logo/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("952","static_file","/wp-includes/blocks/site-logo/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("953","static_file","/wp-includes/blocks/site-tagline/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("954","static_file","/wp-includes/blocks/site-tagline/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("955","static_file","/wp-includes/blocks/site-tagline/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("956","static_file","/wp-includes/blocks/site-tagline/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("957","static_file","/wp-includes/blocks/site-title/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("958","static_file","/wp-includes/blocks/site-title/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("959","static_file","/wp-includes/blocks/site-title/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("960","static_file","/wp-includes/blocks/site-title/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("961","static_file","/wp-includes/blocks/site-title/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("962","static_file","/wp-includes/blocks/site-title/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("963","static_file","/wp-includes/blocks/site-title/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("964","static_file","/wp-includes/blocks/site-title/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("965","static_file","/wp-includes/blocks/social-link/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("966","static_file","/wp-includes/blocks/social-link/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("967","static_file","/wp-includes/blocks/social-link/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("968","static_file","/wp-includes/blocks/social-link/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("969","static_file","/wp-includes/blocks/social-links/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("970","static_file","/wp-includes/blocks/social-links/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("971","static_file","/wp-includes/blocks/social-links/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("972","static_file","/wp-includes/blocks/social-links/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("973","static_file","/wp-includes/blocks/social-links/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("974","static_file","/wp-includes/blocks/social-links/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("975","static_file","/wp-includes/blocks/social-links/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("976","static_file","/wp-includes/blocks/social-links/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("977","static_file","/wp-includes/blocks/spacer/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("978","static_file","/wp-includes/blocks/spacer/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("979","static_file","/wp-includes/blocks/spacer/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("980","static_file","/wp-includes/blocks/spacer/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-08-24 06:11:46","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("981","static_file","/wp-includes/blocks/spacer/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("982","static_file","/wp-includes/blocks/spacer/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("983","static_file","/wp-includes/blocks/spacer/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("984","static_file","/wp-includes/blocks/spacer/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("985","static_file","/wp-includes/blocks/table/editor-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("986","static_file","/wp-includes/blocks/table/editor-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("987","static_file","/wp-includes/blocks/table/editor.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("988","static_file","/wp-includes/blocks/table/editor.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("989","static_file","/wp-includes/blocks/table/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-10 12:22:38","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("990","static_file","/wp-includes/blocks/table/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-10 12:22:38","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("991","static_file","/wp-includes/blocks/table/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-10 12:22:38","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("992","static_file","/wp-includes/blocks/table/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-10 12:22:38","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("993","static_file","/wp-includes/blocks/table/theme-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("994","static_file","/wp-includes/blocks/table/theme-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("995","static_file","/wp-includes/blocks/table/theme.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("996","static_file","/wp-includes/blocks/table/theme.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("997","static_file","/wp-includes/blocks/tag-cloud/style-rtl.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("998","static_file","/wp-includes/blocks/tag-cloud/style-rtl.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("999","static_file","/wp-includes/blocks/tag-cloud/style.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/
INSERT INTO `webtoffee_urls` VALUES
("1000","static_file","/wp-includes/blocks/tag-cloud/style.min.css","","","0","1","1","","0000-00-00 00:00:00","","2023-03-09 12:05:24","0000-00-00 00:00:00","2023-09-07 12:54:31");/*END*/